insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1","4","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314060346","58.46.172.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("2","4","realname","9990.00","10.00","9990.00","0.00","0.00","0","ʵ����֤�۳�����","1314060660","58.46.172.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("3","4","vip","9990.00","0.00","9990.00","0.00","0.00","0","�۳�VIP��Ա��","1314060765","58.46.172.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("4","5","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314097333","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("5","5","tender","10000.00","1000.00","9000.00","1000.00","0.00","4","Ͷ�궳���ʽ�","1314097403","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("6","6","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314097985","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("7","7","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314098016","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("8","7","tender","10000.00","1000.00","9000.00","1000.00","0.00","4","Ͷ�궳���ʽ�","1314098111","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("9","6","tender","10000.00","1000.00","9000.00","1000.00","0.00","4","Ͷ�궳���ʽ�","1314098179","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("10","5","invest","9000.00","1000.00","9000.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314098801","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("11","5","collection","10015.00","1015.00","9000.00","0.00","1015.00","4","���ս��","1314098801","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("12","7","invest","9000.00","1000.00","9000.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314098801","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("13","7","collection","10015.00","1015.00","9000.00","0.00","1015.00","4","���ս��","1314098801","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("14","6","invest","9000.00","1000.00","9000.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314098801","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("15","6","collection","10015.00","1015.00","9000.00","0.00","1015.00","4","���ս��","1314098801","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("16","4","borrow_success","12990.00","3000.00","12990.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a1.html\' target=_blank>�뻻  �����¹���</a>]�赽�Ŀ�","1314098801","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("17","4","margin","12990.00","300.00","12690.00","300.00","0.00","0","��������[<a href=\'/invest/a1.html\' target=_blank>�뻻  �����¹���</a>]�ı�֤��","1314098801","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("18","4","borrow_fee","12870.00","120.00","12570.00","300.00","0.00","0","���[<a href=\'/invest/a1.html\' target=_blank>�뻻  �����¹���</a>]��������","1314098801","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("19","4","repayment","9825.00","3045.00","9525.00","300.00","0.00","0","��[<a href=\'/invest/a1.html\' target=_blank>�뻻  �����¹���</a>]����","1314098900","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("20","4","borrow_frost","9825.00","300.00","9825.00","0.00","0.00","0","��[<a href=\'/invest/a1.html\' target=_blank>�뻻  �����¹���</a>]���Ľⶳ","1314098900","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("21","5","invest_repayment","10015.00","1015.00","10015.00","0.00","0.00","4","�ͻ���[<a href=\'/invest/a1.html\' target=_blank>�뻻  �����¹���</a>]���Ļ���","1314098900","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("22","5","tender_mange","10013.50","1.50","10013.50","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314098900","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("23","7","invest_repayment","10015.00","1015.00","10015.00","0.00","0.00","4","�ͻ���[<a href=\'/invest/a1.html\' target=_blank>�뻻  �����¹���</a>]���Ļ���","1314098900","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("24","7","tender_mange","10013.50","1.50","10013.50","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314098900","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("25","6","invest_repayment","10015.00","1015.00","10015.00","0.00","0.00","4","�ͻ���[<a href=\'/invest/a1.html\' target=_blank>�뻻  �����¹���</a>]���Ļ���","1314098900","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("26","6","tender_mange","10013.50","1.50","10013.50","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314098900","118.253.4.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("27","6","tender","10013.50","1000.00","9013.50","1000.00","0.00","4","Ͷ�궳���ʽ�","1314176561","58.46.172.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("28","5","tender","10013.50","1000.00","9013.50","1000.00","0.00","4","Ͷ�궳���ʽ�","1314188171","222.243.13.108");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("29","11","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314245137","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("30","11","tender","10000.00","1000.00","9000.00","1000.00","0.00","4","Ͷ�궳���ʽ�","1314245199","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("31","12","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314245367","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("32","12","tender","10000.00","45.00","9955.00","45.00","0.00","4","Ͷ�궳���ʽ�","1314249273","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("33","12","realname","9990.00","10.00","9945.00","45.00","0.00","0","ʵ����֤�۳�����","1314249464","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("34","12","vip","9810.00","180.00","9765.00","45.00","0.00","0","�۳�VIP��Ա��","1314249565","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("35","5","tender","10013.50","200.00","8813.50","1200.00","0.00","12","Ͷ�궳���ʽ�","1314251721","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("36","13","recharge","10.00","10.00","10.00","0.00","0.00","0","�˺ų�ֵ","1314254962","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("37","13","realname","0.00","10.00","0.00","0.00","0.00","0","ʵ����֤�۳�����","1314255086","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("38","15","recharge","20.00","20.00","20.00","0.00","0.00","0","�˺ų�ֵ","1314256577","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("39","15","realname","10.00","10.00","10.00","0.00","0.00","0","ʵ����֤�۳�����","1314256707","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("40","6","tender","10013.50","100.00","8913.50","1100.00","0.00","15","Ͷ�궳���ʽ�","1314257328","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("41","6","tender","10013.50","500.00","8413.50","1600.00","0.00","13","Ͷ�궳���ʽ�","1314257358","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("42","6","tender","10013.50","200.00","8213.50","1800.00","0.00","12","Ͷ�궳���ʽ�","1314257822","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("43","14","recharge","1000.00","1000.00","1000.00","0.00","0.00","0","�˺ų�ֵ","1314258303","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("44","14","tender","1000.00","488.00","512.00","488.00","0.00","12","Ͷ�궳���ʽ�","1314258383","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("45","14","tender","1000.00","500.00","12.00","988.00","0.00","13","Ͷ�궳���ʽ�","1314258415","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("46","14","recharge","2388.00","1388.00","1400.00","988.00","0.00","0","�˺ų�ֵ","1314259382","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("47","14","tender","2388.00","1000.00","400.00","1988.00","0.00","13","Ͷ�궳���ʽ�","1314259420","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("48","14","tender","2388.00","100.00","300.00","2088.00","0.00","15","Ͷ�궳���ʽ�","1314259440","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("49","16","recharge","100.00","100.00","100.00","0.00","0.00","0","�˺ų�ֵ","1314261385","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("50","16","tender","100.00","100.00","0.00","100.00","0.00","15","Ͷ�궳���ʽ�","1314261504","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("51","18","recharge","100.00","100.00","100.00","0.00","0.00","0","�˺ų�ֵ","1314262533","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("52","6","invest","9013.50","1000.00","8213.50","800.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("53","6","collection","10020.90","1007.40","8213.50","800.00","1007.40","4","���ս��","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("54","5","invest","9013.50","1000.00","8813.50","200.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("55","5","collection","10020.90","1007.40","8813.50","200.00","1007.40","4","���ս��","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("56","11","invest","9000.00","1000.00","9000.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("57","11","collection","10007.40","1007.40","9000.00","0.00","1007.40","4","���ս��","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("58","12","invest","9765.00","45.00","9765.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("59","12","collection","9810.33","45.33","9765.00","0.00","45.33","4","���ս��","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("60","4","borrow_success","12870.00","3045.00","12870.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a2.html\' target=_blank>��������</a>]�赽�Ŀ�","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("61","4","margin","12870.00","304.50","12565.50","304.50","0.00","0","��������[<a href=\'/invest/a2.html\' target=_blank>��������</a>]�ı�֤��","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("62","4","borrow_fee","12809.10","60.90","12504.60","304.50","0.00","0","���[<a href=\'/invest/a2.html\' target=_blank>��������</a>]��������","1314262691","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("63","4","repayment","9741.57","3067.53","9437.07","304.50","0.00","0","��[<a href=\'/invest/a2.html\' target=_blank>��������</a>]����","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("64","4","borrow_frost","9741.57","304.50","9741.57","0.00","0.00","0","��[<a href=\'/invest/a2.html\' target=_blank>��������</a>]���Ľⶳ","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("65","6","invest_repayment","10020.90","1007.40","9220.90","800.00","0.00","4","�ͻ���[<a href=\'/invest/a2.html\' target=_blank>��������</a>]���Ļ���","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("66","6","tender_mange","10020.16","0.74","9220.16","800.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("67","5","invest_repayment","10020.90","1007.40","9820.90","200.00","0.00","4","�ͻ���[<a href=\'/invest/a2.html\' target=_blank>��������</a>]���Ļ���","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("68","5","tender_mange","10020.16","0.74","9820.16","200.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("69","11","invest_repayment","10007.40","1007.40","10007.40","0.00","0.00","4","�ͻ���[<a href=\'/invest/a2.html\' target=_blank>��������</a>]���Ļ���","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("70","11","tender_mange","10006.66","0.74","10006.66","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("71","12","invest_repayment","9810.33","45.33","9810.33","0.00","0.00","4","�ͻ���[<a href=\'/invest/a2.html\' target=_blank>��������</a>]���Ļ���","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("72","12","tender_mange","9810.30","0.03","9810.30","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314262797","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("73","6","invest","9520.16","500.00","9220.16","300.00","0.00","13","Ͷ��ɹ����ÿ۳�","1314262949","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("74","6","collection","10025.16","505.00","9220.16","300.00","505.00","13","���ս��","1314262949","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("75","14","invest","1888.00","500.00","300.00","1588.00","0.00","13","Ͷ��ɹ����ÿ۳�","1314262949","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("76","14","collection","2393.00","505.00","300.00","1588.00","505.00","13","���ս��","1314262949","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("77","14","invest","1393.00","1000.00","300.00","588.00","505.00","13","Ͷ��ɹ����ÿ۳�","1314262951","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("78","14","collection","2403.00","1010.00","300.00","588.00","1515.00","13","���ս��","1314262951","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("79","13","borrow_success","2000.00","2000.00","2000.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a4.html\' target=_blank>��������  �뻹</a>]�赽�Ŀ�","1314262953","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("80","13","margin","2000.00","200.00","1800.00","200.00","0.00","0","��������[<a href=\'/invest/a4.html\' target=_blank>��������  �뻹</a>]�ı�֤��","1314262953","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("81","13","borrow_fee","1960.00","40.00","1760.00","200.00","0.00","0","���[<a href=\'/invest/a4.html\' target=_blank>��������  �뻹</a>]��������","1314262953","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("82","13","vip","1780.00","180.00","1580.00","200.00","0.00","0","�۳�VIP��Ա��","1314262953","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("83","19","recharge","100.00","100.00","100.00","0.00","0.00","0","�˺ų�ֵ","1314263353","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("84","19","tender","100.00","100.00","0.00","100.00","0.00","15","Ͷ�궳���ʽ�","1314263481","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("85","18","tender","100.00","100.00","0.00","100.00","0.00","15","Ͷ�궳���ʽ�","1314263522","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("86","14","tender","2403.00","300.00","0.00","888.00","1515.00","4","Ͷ�궳���ʽ�","1314263594","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("87","20","recharge","100.00","100.00","100.00","0.00","0.00","0","�˺ų�ֵ","1314264750","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("88","20","recharge","200.00","100.00","200.00","0.00","0.00","0","�˺ų�ֵ","1314264769","58.46.193.18");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("89","22","recharge","1000.00","1000.00","1000.00","0.00","0.00","0","�˺ų�ֵ","1314268566","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("90","20","realname","190.00","10.00","190.00","0.00","0.00","0","ʵ����֤�۳�����","1314268814","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("91","20","vip","10.00","180.00","10.00","0.00","0.00","0","�۳�VIP��Ա��","1314268838","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("92","22","tender","1000.00","1000.00","0.00","1000.00","0.00","4","Ͷ�궳���ʽ�","1314268849","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("93","6","tender","10025.16","500.00","8720.16","800.00","505.00","20","Ͷ�궳���ʽ�","1314269144","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("94","6","tender","10025.16","500.00","8220.16","1300.00","505.00","13","Ͷ�궳���ʽ�","1314269170","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("95","6","tender","10025.16","1000.00","7220.16","2300.00","505.00","4","Ͷ�궳���ʽ�","1314269201","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("96","23","recharge","1000.00","1000.00","1000.00","0.00","0.00","0","�˺ų�ֵ","1314269596","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("97","24","recharge","1000.00","1000.00","1000.00","0.00","0.00","0","�˺ų�ֵ","1314270132","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("98","24","tender","1000.00","1000.00","0.00","1000.00","0.00","4","Ͷ�궳���ʽ�","1314270173","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("99","23","tender","1000.00","1000.00","0.00","1000.00","0.00","4","Ͷ�궳���ʽ�","1314270219","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("100","25","recharge","20.00","20.00","20.00","0.00","0.00","0","���߳�ֵ","1314270418","58.251.61.177");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("101","25","fee","19.80","0.20","19.80","0.00","0.00","0","���߳�ֵ������","1314270419","58.251.61.177");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("102","26","recharge","1000.00","1000.00","1000.00","0.00","0.00","0","�˺ų�ֵ","1314270717","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("103","26","tender","1000.00","1000.00","0.00","1000.00","0.00","4","Ͷ�궳���ʽ�","1314270755","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("104","25","realname","9.80","10.00","9.80","0.00","0.00","0","ʵ����֤�۳�����","1314270769","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("105","25","recharge","14.80","5.00","14.80","0.00","0.00","0","���߳�ֵ","1314271566","125.39.123.75");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("106","25","fee","14.75","0.05","14.75","0.00","0.00","0","���߳�ֵ������","1314271566","125.39.123.75");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("107","18","recharge","1100.00","1000.00","1000.00","100.00","0.00","0","�˺ų�ֵ","1314271670","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("108","18","tender","1100.00","1000.00","0.00","1100.00","0.00","4","Ͷ�궳���ʽ�","1314271764","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("109","12","tender","9810.30","1000.00","8810.30","1000.00","0.00","20","Ͷ�궳���ʽ�","1314272031","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("110","12","tender","9810.30","500.00","8310.30","1500.00","0.00","13","Ͷ�궳���ʽ�","1314272062","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("111","12","tender","9810.30","1000.00","7310.30","2500.00","0.00","4","Ͷ�궳���ʽ�","1314272092","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("112","5","invest","9820.16","200.00","9820.16","0.00","0.00","12","Ͷ��ɹ����ÿ۳�","1314272138","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("113","5","collection","10023.16","203.00","9820.16","0.00","203.00","12","���ս��","1314272138","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("114","6","invest","9825.16","200.00","7220.16","2100.00","505.00","12","Ͷ��ɹ����ÿ۳�","1314272138","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("115","6","collection","10028.16","203.00","7220.16","2100.00","708.00","12","���ս��","1314272138","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("116","14","invest","1915.00","488.00","0.00","400.00","1515.00","12","Ͷ��ɹ����ÿ۳�","1314272138","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("117","14","collection","2410.32","495.32","0.00","400.00","2010.32","12","���ս��","1314272138","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("118","12","borrow_success","10698.30","888.00","8198.30","2500.00","0.00","0","ͨ��[<a href=\'/invest/a3.html\' target=_blank>�뻹  ��������</a>]�赽�Ŀ�","1314272139","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("119","12","margin","10698.30","88.80","8109.50","2588.80","0.00","0","��������[<a href=\'/invest/a3.html\' target=_blank>�뻹  ��������</a>]�ı�֤��","1314272139","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("120","12","borrow_fee","10680.54","17.76","8091.74","2588.80","0.00","0","���[<a href=\'/invest/a3.html\' target=_blank>�뻹  ��������</a>]��������","1314272139","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("121","19","recharge","1100.00","1000.00","1000.00","100.00","0.00","0","�˺ų�ֵ","1314272342","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("122","12","repayment","9779.22","901.32","7190.42","2588.80","0.00","0","��[<a href=\'/invest/a3.html\' target=_blank>�뻹  ��������</a>]����","1314272399","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("123","12","borrow_frost","9779.22","88.80","7279.22","2500.00","0.00","0","��[<a href=\'/invest/a3.html\' target=_blank>�뻹  ��������</a>]���Ľⶳ","1314272399","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("124","5","invest_repayment","10023.16","203.00","10023.16","0.00","0.00","12","�ͻ���[<a href=\'/invest/a3.html\' target=_blank>�뻹  ��������</a>]���Ļ���","1314272399","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("125","5","tender_mange","10022.86","0.30","10022.86","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314272399","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("126","6","invest_repayment","10028.16","203.00","7423.16","2100.00","505.00","12","�ͻ���[<a href=\'/invest/a3.html\' target=_blank>�뻹  ��������</a>]���Ļ���","1314272399","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("127","6","tender_mange","10027.86","0.30","7422.86","2100.00","505.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314272399","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("128","14","invest_repayment","2410.32","495.32","495.32","400.00","1515.00","12","�ͻ���[<a href=\'/invest/a3.html\' target=_blank>�뻹  ��������</a>]���Ļ���","1314272399","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("129","14","tender_mange","2409.59","0.73","494.59","400.00","1515.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314272399","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("130","19","tender","1100.00","1000.00","0.00","1100.00","0.00","4","Ͷ�궳���ʽ�","1314272449","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("131","16","recharge","1100.00","1000.00","1000.00","100.00","0.00","0","�˺ų�ֵ","1314272951","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("132","16","tender","1100.00","588.00","412.00","688.00","0.00","4","Ͷ�궳���ʽ�","1314273004","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("133","16","recharge","2205.63","1105.63","1517.63","688.00","0.00","0","�˺ų�ֵ","1314273590","118.253.11.171");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("134","16","tender","2205.63","1517.63","0.00","2205.63","0.00","12","Ͷ�궳���ʽ�","1314273899","113.65.155.250");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("135","5","tender","10022.86","1000.00","9022.86","1000.00","0.00","20","Ͷ�궳���ʽ�","1314275439","58.46.219.35");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("136","5","tender","10022.86","1000.00","8022.86","2000.00","0.00","12","Ͷ�궳���ʽ�","1314275464","58.46.219.35");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("137","14","cash_frost","2409.59","494.59","0.00","894.59","1515.00","0","�û���������","1314295580","113.65.152.212");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("138","6","invest","9927.86","100.00","7422.86","2000.00","505.00","15","Ͷ��ɹ����ÿ۳�","1314325744","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("139","6","collection","10028.86","101.00","7422.86","2000.00","606.00","15","���ս��","1314325744","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("140","14","invest","2309.59","100.00","0.00","794.59","1515.00","15","Ͷ��ɹ����ÿ۳�","1314325744","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("141","14","collection","2410.59","101.00","0.00","794.59","1616.00","15","���ս��","1314325744","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("142","16","invest","2105.63","100.00","0.00","2105.63","0.00","15","Ͷ��ɹ����ÿ۳�","1314325745","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("143","16","collection","2206.63","101.00","0.00","2105.63","101.00","15","���ս��","1314325745","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("144","19","invest","1000.00","100.00","0.00","1000.00","0.00","15","Ͷ��ɹ����ÿ۳�","1314325746","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("145","19","collection","1101.00","101.00","0.00","1000.00","101.00","15","���ս��","1314325746","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("146","18","invest","1000.00","100.00","0.00","1000.00","0.00","15","Ͷ��ɹ����ÿ۳�","1314325746","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("147","18","collection","1101.00","101.00","0.00","1000.00","101.00","15","���ս��","1314325746","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("148","15","borrow_success","510.00","500.00","510.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]�赽�Ŀ�","1314325747","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("149","15","margin","510.00","50.00","460.00","50.00","0.00","0","��������[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]�ı�֤��","1314325747","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("150","15","borrow_fee","500.00","10.00","450.00","50.00","0.00","0","���[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]��������","1314325747","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("151","15","vip","320.00","180.00","270.00","50.00","0.00","0","�۳�VIP��Ա��","1314325747","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("152","14","invest","2110.59","300.00","0.00","494.59","1616.00","4","Ͷ��ɹ����ÿ۳�","1314325765","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("153","14","collection","2415.09","304.50","0.00","494.59","1920.50","4","���ս��","1314325765","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("154","22","invest","0.00","1000.00","0.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314325766","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("155","22","collection","1015.00","1015.00","0.00","0.00","1015.00","4","���ս��","1314325766","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("156","6","invest","9028.86","1000.00","7422.86","1000.00","606.00","4","Ͷ��ɹ����ÿ۳�","1314325766","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("157","6","collection","10043.86","1015.00","7422.86","1000.00","1621.00","4","���ս��","1314325766","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("158","24","invest","0.00","1000.00","0.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314325766","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("159","24","collection","1015.00","1015.00","0.00","0.00","1015.00","4","���ս��","1314325766","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("160","23","invest","0.00","1000.00","0.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314325767","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("161","23","collection","1015.00","1015.00","0.00","0.00","1015.00","4","���ս��","1314325767","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("162","26","invest","0.00","1000.00","0.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314325767","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("163","26","collection","1015.00","1015.00","0.00","0.00","1015.00","4","���ս��","1314325767","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("164","18","invest","101.00","1000.00","0.00","0.00","101.00","4","Ͷ��ɹ����ÿ۳�","1314325768","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("165","18","collection","1116.00","1015.00","0.00","0.00","1116.00","4","���ս��","1314325768","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("166","12","invest","8779.22","1000.00","7279.22","1500.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314325768","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("167","12","collection","9794.22","1015.00","7279.22","1500.00","1015.00","4","���ս��","1314325768","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("168","19","invest","101.00","1000.00","0.00","0.00","101.00","4","Ͷ��ɹ����ÿ۳�","1314325768","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("169","19","collection","1116.00","1015.00","0.00","0.00","1116.00","4","���ս��","1314325768","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("170","16","invest","1618.63","588.00","0.00","1517.63","101.00","4","Ͷ��ɹ����ÿ۳�","1314325769","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("171","16","collection","2215.45","596.82","0.00","1517.63","697.82","4","���ս��","1314325769","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("172","4","borrow_success","18629.57","8888.00","18629.57","0.00","0.00","0","ͨ��[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]�赽�Ŀ�","1314325769","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("173","4","margin","18629.57","888.80","17740.77","888.80","0.00","0","��������[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]�ı�֤��","1314325769","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("174","4","borrow_fee","18451.81","177.76","17563.01","888.80","0.00","0","���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]��������","1314325769","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("175","4","repayment","9430.49","9021.32","8541.69","888.80","0.00","0","��[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]����","1314325819","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("176","4","borrow_frost","9430.49","888.80","9430.49","0.00","0.00","0","��[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ľⶳ","1314325819","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("177","14","invest_repayment","2415.09","304.50","304.50","494.59","1616.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325819","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("178","14","tender_mange","2414.64","0.45","304.05","494.59","1616.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325819","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("179","22","invest_repayment","1015.00","1015.00","1015.00","0.00","0.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325820","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("180","22","tender_mange","1013.50","1.50","1013.50","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325820","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("181","6","invest_repayment","10043.86","1015.00","8437.86","1000.00","606.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325820","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("182","6","tender_mange","10042.36","1.50","8436.36","1000.00","606.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325820","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("183","24","invest_repayment","1015.00","1015.00","1015.00","0.00","0.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325820","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("184","24","tender_mange","1013.50","1.50","1013.50","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325820","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("185","23","invest_repayment","1015.00","1015.00","1015.00","0.00","0.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325821","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("186","23","tender_mange","1013.50","1.50","1013.50","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325821","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("187","26","invest_repayment","1015.00","1015.00","1015.00","0.00","0.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325821","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("188","26","tender_mange","1013.50","1.50","1013.50","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325821","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("189","18","invest_repayment","1116.00","1015.00","1015.00","0.00","101.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325822","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("190","18","tender_mange","1114.50","1.50","1013.50","0.00","101.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325822","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("191","12","invest_repayment","9794.22","1015.00","8294.22","1500.00","0.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325822","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("192","12","tender_mange","9792.72","1.50","8292.72","1500.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325822","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("193","19","invest_repayment","1116.00","1015.00","1015.00","0.00","101.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325822","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("194","19","tender_mange","1114.50","1.50","1013.50","0.00","101.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325822","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("195","16","invest_repayment","2215.45","596.82","596.82","1517.63","101.00","4","�ͻ���[<a href=\'/invest/a6.html\' target=_blank>��л�������Ѷ���վ��֧�� ��������</a>]���Ļ���","1314325823","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("196","16","tender_mange","2214.57","0.88","595.94","1517.63","101.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314325823","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("197","13","recharge","2280.00","500.00","2080.00","200.00","0.00","0","�˺ų�ֵ","1314326130","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("198","13","repayment","260.00","2020.00","60.00","200.00","0.00","0","��[<a href=\'/invest/a4.html\' target=_blank>��������  �뻹</a>]����","1314326175","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("199","13","borrow_frost","260.00","200.00","260.00","0.00","0.00","0","��[<a href=\'/invest/a4.html\' target=_blank>��������  �뻹</a>]���Ľⶳ","1314326175","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("200","6","invest_repayment","10042.36","505.00","8941.36","1000.00","101.00","13","�ͻ���[<a href=\'/invest/a4.html\' target=_blank>��������  �뻹</a>]���Ļ���","1314326175","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("201","6","tender_mange","10041.86","0.50","8940.86","1000.00","101.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314326175","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("202","14","invest_repayment","2414.64","505.00","809.05","494.59","1111.00","13","�ͻ���[<a href=\'/invest/a4.html\' target=_blank>��������  �뻹</a>]���Ļ���","1314326175","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("203","14","tender_mange","2414.14","0.50","808.55","494.59","1111.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314326175","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("204","14","invest_repayment","2414.14","1010.00","1818.55","494.59","101.00","13","�ͻ���[<a href=\'/invest/a4.html\' target=_blank>��������  �뻹</a>]���Ļ���","1314326176","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("205","14","tender_mange","2413.14","1.00","1817.55","494.59","101.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314326176","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("206","5","tender","10022.86","2000.00","6022.86","4000.00","0.00","4","Ͷ�궳���ʽ�","1314326556","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("207","12","tender","9792.72","2000.00","6292.72","3500.00","0.00","4","Ͷ�궳���ʽ�","1314327761","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("208","22","cash_frost","1013.50","1013.50","0.00","1013.50","0.00","0","�û���������","1314375663","113.65.175.155");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("209","6","tender","10041.86","2000.00","6940.86","3000.00","101.00","4","Ͷ�궳���ʽ�","1314409789","58.46.179.32");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("210","10","recharge","11.00","11.00","11.00","0.00","0.00","0","���߳�ֵ","1314418300","183.60.58.229");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("211","10","fee","10.89","0.11","10.89","0.00","0.00","0","���߳�ֵ������","1314418300","183.60.58.229");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("212","10","realname","0.89","10.00","0.89","0.00","0.00","0","ʵ����֤�۳�����","1314515148","113.218.57.207");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("213","11","tender","10006.66","2000.00","8006.66","2000.00","0.00","4","Ͷ�궳���ʽ�","1314527473","113.219.24.38");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("214","11","tender","10006.66","1500.00","6506.66","3500.00","0.00","12","Ͷ�궳���ʽ�","1314527512","113.219.24.38");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("215","11","tender","10006.66","500.00","6006.66","4000.00","0.00","13","Ͷ�궳���ʽ�","1314527533","113.219.24.38");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("216","11","tender","10006.66","1000.00","5006.66","5000.00","0.00","20","Ͷ�궳���ʽ�","1314527606","113.219.24.38");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("217","22","cash_cancel","1013.50","1014.00","1014.00","-0.50","0.00","0","ȡ�����ֽⶳ","1314538693","113.65.172.88");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("218","22","tender","1013.50","982.37","31.63","981.87","0.00","12","Ͷ�궳���ʽ�","1314538735","113.65.172.88");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("219","14","tender","2413.14","1000.00","817.55","1494.59","101.00","20","Ͷ�궳���ʽ�","1314538839","113.65.172.88");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("220","18","tender","1114.50","500.00","513.50","500.00","101.00","20","Ͷ�궳���ʽ�","1314538916","113.65.172.88");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("221","18","tender","1114.50","500.00","13.50","1000.00","101.00","13","Ͷ�궳���ʽ�","1314538946","113.65.172.88");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("222","14","tender","2413.14","500.00","317.55","1994.59","101.00","13","Ͷ�궳���ʽ�","1314539024","113.65.172.88");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("223","16","tender","2214.57","500.00","95.94","2017.63","101.00","13","Ͷ�궳���ʽ�","1314539094","113.65.172.88");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("224","34","recharge","5000.00","5000.00","5000.00","0.00","0.00","0","�˺ų�ֵ","1314542761","113.219.77.148");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("225","34","vip","4820.00","180.00","4820.00","0.00","0.00","0","�۳�VIP��Ա��","1314543047","113.219.77.148");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("226","34","tender","4820.00","2000.00","2820.00","2000.00","0.00","4","Ͷ�궳���ʽ�","1314543711","113.219.77.148");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("227","15","recharge","620.00","300.00","570.00","50.00","0.00","0","�˺ų�ֵ","1314596228","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("228","15","repayment","115.00","505.00","65.00","50.00","0.00","0","��[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]����","1314596258","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("229","15","borrow_frost","115.00","50.00","115.00","0.00","0.00","0","��[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]���Ľⶳ","1314596258","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("230","6","invest_repayment","10041.86","101.00","7041.86","3000.00","0.00","15","�ͻ���[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]���Ļ���","1314596258","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("231","6","tender_mange","10041.76","0.10","7041.76","3000.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314596258","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("232","14","invest_repayment","2413.14","101.00","418.55","1994.59","0.00","15","�ͻ���[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]���Ļ���","1314596258","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("233","14","tender_mange","2413.04","0.10","418.45","1994.59","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314596258","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("234","16","invest_repayment","2214.57","101.00","196.94","2017.63","0.00","15","�ͻ���[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]���Ļ���","1314596260","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("235","16","tender_mange","2214.47","0.10","196.84","2017.63","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314596260","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("236","19","invest_repayment","1114.50","101.00","1114.50","0.00","0.00","15","�ͻ���[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]���Ļ���","1314596260","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("237","19","tender_mange","1114.40","0.10","1114.40","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314596260","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("238","18","invest_repayment","1114.50","101.00","114.50","1000.00","0.00","15","�ͻ���[<a href=\'/invest/a5.html\' target=_blank>������ ����  ����ͨ�� �ͻ�</a>]���Ļ���","1314596261","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("239","18","tender_mange","1114.40","0.10","114.40","1000.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314596261","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("240","6","tender","10041.76","1000.00","6041.76","4000.00","0.00","15","Ͷ�궳���ʽ�","1314596550","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("241","6","tender","10041.76","200.00","5841.76","4200.00","0.00","25","Ͷ�궳���ʽ�","1314597188","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("242","5","tender","10022.86","800.00","5222.86","4800.00","0.00","15","Ͷ�궳���ʽ�","1314597741","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("243","5","tender","10022.86","200.00","5022.86","5000.00","0.00","25","Ͷ�궳���ʽ�","1314597766","58.46.162.87");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("244","35","recharge","11.00","11.00","11.00","0.00","0.00","0","���߳�ֵ","1314600367","125.39.123.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("245","35","fee","10.89","0.11","10.89","0.00","0.00","0","���߳�ֵ������","1314600367","125.39.123.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("246","24","cash_frost","1013.50","1013.50","0.00","1013.50","0.00","0","�û���������","1314614261","113.65.186.192");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("247","26","cash_frost","1013.50","1013.50","0.00","1013.50","0.00","0","�û���������","1314614425","113.65.186.192");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("248","12","tender","9792.72","600.00","5692.72","4100.00","0.00","25","Ͷ�궳���ʽ�","1314617566","113.219.1.152");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("249","12","tender","9792.72","1200.00","4492.72","5300.00","0.00","15","Ͷ�궳���ʽ�","1314617618","113.219.1.152");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("250","28","recharge","6.00","6.00","6.00","0.00","0.00","0","���߳�ֵ","1314632563","58.251.61.214");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("251","28","fee","5.94","0.06","5.94","0.00","0.00","0","���߳�ֵ������","1314632563","58.251.61.214");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("252","28","recharge","35.94","30.00","35.94","0.00","0.00","0","���߳�ֵ","1314632725","58.251.61.214");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("253","28","fee","35.64","0.30","35.64","0.00","0.00","0","���߳�ֵ������","1314632725","58.251.61.214");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("254","6","invest","9541.76","500.00","5841.76","3700.00","0.00","13","Ͷ��ɹ����ÿ۳�","1314665236","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("255","6","collection","10048.43","506.67","5841.76","3700.00","506.67","13","���ս��","1314665236","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("256","12","invest","9292.72","500.00","4492.72","4800.00","0.00","13","Ͷ��ɹ����ÿ۳�","1314665236","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("257","12","collection","9799.39","506.67","4492.72","4800.00","506.67","13","���ս��","1314665236","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("258","11","invest","9506.66","500.00","5006.66","4500.00","0.00","13","Ͷ��ɹ����ÿ۳�","1314665236","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("259","11","collection","10013.33","506.67","5006.66","4500.00","506.67","13","���ս��","1314665236","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("260","18","invest","614.40","500.00","114.40","500.00","0.00","13","Ͷ��ɹ����ÿ۳�","1314665236","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("261","18","collection","1121.07","506.67","114.40","500.00","506.67","13","���ս��","1314665236","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("262","14","invest","1913.04","500.00","418.45","1494.59","0.00","13","Ͷ��ɹ����ÿ۳�","1314665242","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("263","14","collection","2419.71","506.67","418.45","1494.59","506.67","13","���ս��","1314665242","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("264","16","invest","1714.47","500.00","196.84","1517.63","0.00","13","Ͷ��ɹ����ÿ۳�","1314665243","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("265","16","collection","2221.14","506.67","196.84","1517.63","506.67","13","���ս��","1314665243","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("266","13","borrow_success","3260.00","3000.00","3260.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]�赽�Ŀ�","1314665243","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("267","13","margin","3260.00","300.00","2960.00","300.00","0.00","0","��������[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]�ı�֤��","1314665243","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("268","13","borrow_fee","3200.00","60.00","2900.00","300.00","0.00","0","���[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]��������","1314665243","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("269","16","invest","703.51","1517.63","196.84","0.00","506.67","12","Ͷ��ɹ����ÿ۳�","1314665271","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("270","16","collection","2243.90","1540.39","196.84","0.00","2047.06","12","���ս��","1314665271","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("271","5","invest","9022.86","1000.00","5022.86","4000.00","0.00","12","Ͷ��ɹ����ÿ۳�","1314665271","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("272","5","collection","10037.86","1015.00","5022.86","4000.00","1015.00","12","���ս��","1314665271","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("273","11","invest","8513.33","1500.00","5006.66","3000.00","506.67","12","Ͷ��ɹ����ÿ۳�","1314665271","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("274","11","collection","10035.83","1522.50","5006.66","3000.00","2029.17","12","���ս��","1314665271","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("275","22","invest","31.13","982.37","31.63","-0.50","0.00","12","Ͷ��ɹ����ÿ۳�","1314665271","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("276","22","collection","1028.24","997.11","31.63","-0.50","997.11","12","���ս��","1314665271","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("277","12","borrow_success","14799.39","5000.00","9492.72","4800.00","506.67","0","ͨ��[<a href=\'/invest/a9.html\' target=_blank>������ô���Ͷ���˸�����������</a>]�赽�Ŀ�","1314665273","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("278","12","margin","14799.39","500.00","8992.72","5300.00","506.67","0","��������[<a href=\'/invest/a9.html\' target=_blank>������ô���Ͷ���˸�����������</a>]�ı�֤��","1314665273","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("279","12","borrow_fee","14699.39","100.00","8892.72","5300.00","506.67","0","���[<a href=\'/invest/a9.html\' target=_blank>������ô���Ͷ���˸�����������</a>]��������","1314665273","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("280","6","invest","9548.43","500.00","5841.76","3200.00","506.67","20","Ͷ��ɹ����ÿ۳�","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("281","6","collection","10052.13","503.70","5841.76","3200.00","1010.37","20","���ս��","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("282","12","invest","13699.39","1000.00","8892.72","4300.00","506.67","20","Ͷ��ɹ����ÿ۳�","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("283","12","collection","14706.79","1007.40","8892.72","4300.00","1514.07","20","���ս��","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("284","5","invest","9037.86","1000.00","5022.86","3000.00","1015.00","20","Ͷ��ɹ����ÿ۳�","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("285","5","collection","10045.26","1007.40","5022.86","3000.00","2022.40","20","���ս��","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("286","11","invest","9035.83","1000.00","5006.66","2000.00","2029.17","20","Ͷ��ɹ����ÿ۳�","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("287","11","collection","10043.23","1007.40","5006.66","2000.00","3036.57","20","���ս��","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("288","14","invest","1419.71","1000.00","418.45","494.59","506.67","20","Ͷ��ɹ����ÿ۳�","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("289","14","collection","2427.11","1007.40","418.45","494.59","1514.07","20","���ս��","1314665293","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("290","18","invest","621.07","500.00","114.40","0.00","506.67","20","Ͷ��ɹ����ÿ۳�","1314665294","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("291","18","collection","1124.77","503.70","114.40","0.00","1010.37","20","���ս��","1314665294","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("292","20","borrow_success","5010.00","5000.00","5010.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]�赽�Ŀ�","1314665294","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("293","20","margin","5010.00","500.00","4510.00","500.00","0.00","0","��������[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]�ı�֤��","1314665294","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("294","20","borrow_fee","4910.00","100.00","4410.00","500.00","0.00","0","���[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]��������","1314665294","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("295","6","invest","9852.13","200.00","5841.76","3000.00","1010.37","25","Ͷ��ɹ����ÿ۳�","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("296","6","collection","10055.17","203.04","5841.76","3000.00","1213.41","25","���ս��","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("297","5","invest","9845.26","200.00","5022.86","2800.00","2022.40","25","Ͷ��ɹ����ÿ۳�","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("298","5","collection","10048.30","203.04","5022.86","2800.00","2225.44","25","���ս��","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("299","12","invest","14106.79","600.00","8892.72","3700.00","1514.07","25","Ͷ��ɹ����ÿ۳�","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("300","12","collection","14715.90","609.11","8892.72","3700.00","2123.18","25","���ս��","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("301","25","borrow_success","1014.75","1000.00","1014.75","0.00","0.00","0","ͨ��[<a href=\'/invest/a14.html\' target=_blank>��һ�ν�������ö�ȣ�лл֧��</a>]�赽�Ŀ�","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("302","25","margin","1014.75","100.00","914.75","100.00","0.00","0","��������[<a href=\'/invest/a14.html\' target=_blank>��һ�ν�������ö�ȣ�лл֧��</a>]�ı�֤��","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("303","25","borrow_fee","994.75","20.00","894.75","100.00","0.00","0","���[<a href=\'/invest/a14.html\' target=_blank>��һ�ν�������ö�ȣ�лл֧��</a>]��������","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("304","25","vip","814.75","180.00","714.75","100.00","0.00","0","�۳�VIP��Ա��","1314665320","113.219.225.103");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("305","28","realname","25.64","10.00","25.64","0.00","0.00","0","ʵ����֤�۳�����","1314676972","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("306","23","realname","1003.50","10.00","1003.50","0.00","0.00","0","ʵ����֤�۳�����","1314676995","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("307","16","realname","2233.90","10.00","186.84","0.00","2047.06","0","ʵ����֤�۳�����","1314677019","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("308","14","realname","2417.11","10.00","408.45","494.59","1514.07","0","ʵ����֤�۳�����","1314677047","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("309","14","recharge_false","2417.11","495.00","903.45","-0.41","1514.07","0","����ʧ��","1314677086","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("310","12","repayment","9640.90","5075.00","3817.72","3700.00","2123.18","0","��[<a href=\'/invest/a9.html\' target=_blank>������ô���Ͷ���˸�����������</a>]����","1314677262","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("311","12","borrow_frost","9640.90","500.00","4317.72","3200.00","2123.18","0","��[<a href=\'/invest/a9.html\' target=_blank>������ô���Ͷ���˸�����������</a>]���Ľⶳ","1314677262","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("312","16","invest_repayment","2233.90","1540.39","1727.23","0.00","506.67","12","�ͻ���[<a href=\'/invest/a9.html\' target=_blank>������ô���Ͷ���˸�����������</a>]���Ļ���","1314677262","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("313","16","tender_mange","2231.62","2.28","1724.95","0.00","506.67","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314677262","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("314","5","invest_repayment","10048.30","1015.00","6037.86","2800.00","1210.44","12","�ͻ���[<a href=\'/invest/a9.html\' target=_blank>������ô���Ͷ���˸�����������</a>]���Ļ���","1314677263","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("315","5","tender_mange","10046.80","1.50","6036.36","2800.00","1210.44","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314677263","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("316","11","invest_repayment","10043.23","1522.50","6529.16","2000.00","1514.07","12","�ͻ���[<a href=\'/invest/a9.html\' target=_blank>������ô���Ͷ���˸�����������</a>]���Ļ���","1314677263","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("317","11","tender_mange","10040.98","2.25","6526.91","2000.00","1514.07","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314677263","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("318","22","invest_repayment","1028.24","997.11","1028.74","-0.50","0.00","12","�ͻ���[<a href=\'/invest/a9.html\' target=_blank>������ô���Ͷ���˸�����������</a>]���Ļ���","1314677263","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("319","22","tender_mange","1026.77","1.47","1027.27","-0.50","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314677263","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("320","12","tender","9640.90","3000.00","1317.72","6200.00","2123.18","4","Ͷ�궳���ʽ�","1314677371","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("321","33","recharge","11.00","11.00","11.00","0.00","0.00","0","���߳�ֵ","1314678943","183.60.58.227");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("322","33","fee","10.89","0.11","10.89","0.00","0.00","0","���߳�ֵ������","1314678943","183.60.58.227");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("323","38","recharge","16.00","16.00","16.00","0.00","0.00","0","���߳�ֵ","1314680477","125.39.123.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("324","38","fee","15.84","0.16","15.84","0.00","0.00","0","���߳�ֵ������","1314680477","125.39.123.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("325","13","recharge","3400.00","200.00","3100.00","300.00","0.00","0","�˺ų�ֵ","1314680911","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("326","13","repayment","360.00","3040.00","60.00","300.00","0.00","0","��[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]����","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("327","13","borrow_frost","360.00","300.00","360.00","0.00","0.00","0","��[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]���Ľⶳ","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("328","6","invest_repayment","10055.17","506.67","6348.43","3000.00","706.74","13","�ͻ���[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]���Ļ���","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("329","6","tender_mange","10054.50","0.67","6347.76","3000.00","706.74","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("330","12","invest_repayment","9640.90","506.67","1824.39","6200.00","1616.51","13","�ͻ���[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]���Ļ���","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("331","12","tender_mange","9640.23","0.67","1823.72","6200.00","1616.51","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("332","11","invest_repayment","10040.98","506.67","7033.58","2000.00","1007.40","13","�ͻ���[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]���Ļ���","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("333","11","tender_mange","10040.31","0.67","7032.91","2000.00","1007.40","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("334","18","invest_repayment","1124.77","506.67","621.07","0.00","503.70","13","�ͻ���[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]���Ļ���","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("335","18","tender_mange","1124.10","0.67","620.40","0.00","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314680942","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("336","14","invest_repayment","2417.11","506.67","1410.12","-0.41","1007.40","13","�ͻ���[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]���Ļ���","1314680943","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("337","14","tender_mange","2416.44","0.67","1409.45","-0.41","1007.40","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314680943","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("338","16","invest_repayment","2231.62","506.67","2231.62","0.00","0.00","13","�ͻ���[<a href=\'/invest/a7.html\' target=_blank>��վ������ٶȿ찡  �������� ���������</a>]���Ļ���","1314680943","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("339","16","tender_mange","2230.95","0.67","2230.95","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314680943","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("340","38","realname","5.84","10.00","5.84","0.00","0.00","0","ʵ����֤�۳�����","1314681029","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("341","34","tender","4820.00","1000.00","1820.00","3000.00","0.00","13","Ͷ�궳���ʽ�","1314682959","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("342","34","tender","4820.00","820.00","1000.00","3820.00","0.00","15","Ͷ�궳���ʽ�","1314682981","58.46.184.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("343","23","tender","1003.50","500.00","503.50","500.00","0.00","38","Ͷ�궳���ʽ�","1314685711","113.65.154.14");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("344","22","realname","1016.77","10.00","1017.27","-0.50","0.00","0","ʵ����֤�۳�����","1314713559","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("345","39","recharge","100.00","100.00","100.00","0.00","0.00","0","�˺ų�ֵ","1314716436","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("346","39","realname","90.00","10.00","90.00","0.00","0.00","0","ʵ����֤�۳�����","1314716749","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("347","39","vip","90.00","0.00","90.00","0.00","0.00","0","�۳�VIP��Ա��","1314716801","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("348","20","recharge","5410.00","500.00","4910.00","500.00","0.00","0","�˺ų�ֵ","1314717297","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("349","16","tender","2230.95","500.00","1730.95","500.00","0.00","39","Ͷ�궳���ʽ�","1314717349","113.65.174.11");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("350","20","recharge","5910.00","500.00","5410.00","500.00","0.00","0","�˺ų�ֵ","1314717479","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("351","20","repayment","873.00","5037.00","373.00","500.00","0.00","0","��[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]����","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("352","20","borrow_frost","873.00","500.00","873.00","0.00","0.00","0","��[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]���Ľⶳ","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("353","6","invest_repayment","10054.50","503.70","6851.46","3000.00","203.04","20","�ͻ���[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]���Ļ���","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("354","6","tender_mange","10054.13","0.37","6851.09","3000.00","203.04","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("355","12","invest_repayment","9640.23","1007.40","2831.12","6200.00","609.11","20","�ͻ���[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]���Ļ���","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("356","12","tender_mange","9639.49","0.74","2830.38","6200.00","609.11","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("357","5","invest_repayment","10046.80","1007.40","7043.76","2800.00","203.04","20","�ͻ���[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]���Ļ���","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("358","5","tender_mange","10046.06","0.74","7043.02","2800.00","203.04","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("359","11","invest_repayment","10040.31","1007.40","8040.31","2000.00","0.00","20","�ͻ���[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]���Ļ���","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("360","11","tender_mange","10039.57","0.74","8039.57","2000.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("361","14","invest_repayment","2416.44","1007.40","2416.85","-0.41","0.00","20","�ͻ���[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]���Ļ���","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("362","14","tender_mange","2415.70","0.74","2416.11","-0.41","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314717525","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("363","18","invest_repayment","1124.10","503.70","1124.10","0.00","0.00","20","�ͻ���[<a href=\'/invest/a8.html\' target=_blank>������վ�����ٶȡ����ͨ���ͻ�</a>]���Ļ���","1314717526","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("364","18","tender_mange","1123.73","0.37","1123.73","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314717526","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("365","23","tender","1003.50","500.00","3.50","1000.00","0.00","39","Ͷ�궳���ʽ�","1314717828","113.65.154.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("366","24","cash_cancel","1013.50","1014.00","1014.00","-0.50","0.00","0","ȡ�����ֽⶳ","1314718610","113.65.152.6");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("367","24","tender","1013.50","500.00","514.00","499.50","0.00","39","Ͷ�궳���ʽ�","1314718630","113.65.152.6");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("368","40","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314720165","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("369","40","tender","10000.00","5000.00","5000.00","5000.00","0.00","4","Ͷ�궳���ʽ�","1314720224","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("370","40","tender","10000.00","2000.00","3000.00","7000.00","0.00","13","Ͷ�궳���ʽ�","1314720332","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("371","40","tender","10000.00","1180.00","1820.00","8180.00","0.00","15","Ͷ�궳���ʽ�","1314720377","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("372","41","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314720733","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("373","41","tender","10000.00","5000.00","5000.00","5000.00","0.00","4","Ͷ�궳���ʽ�","1314720801","113.219.166.91");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("374","26","cash_cancel","1013.50","1014.00","1014.00","-0.50","0.00","0","ȡ�����ֽⶳ","1314722209","113.65.154.201");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("375","26","tender","1013.50","500.00","514.00","499.50","0.00","39","Ͷ�궳���ʽ�","1314722232","113.65.154.201");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("376","19","tender","1114.40","500.00","614.40","500.00","0.00","39","Ͷ�궳���ʽ�","1314722957","113.65.153.161");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("377","22","tender","1016.77","388.00","629.27","387.50","0.00","39","Ͷ�궳���ʽ�","1314723420","113.65.154.174");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("378","42","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314753194","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("379","42","tender","10000.00","5000.00","5000.00","5000.00","0.00","4","Ͷ�궳���ʽ�","1314753254","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("380","23","invest","503.50","500.00","3.50","500.00","0.00","38","Ͷ��ɹ����ÿ۳�","1314753325","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("381","23","collection","1009.75","506.25","3.50","500.00","506.25","38","���ս��","1314753325","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("382","38","borrow_success","505.84","500.00","505.84","0.00","0.00","0","ͨ��[<a href=\'/invest/a16.html\' target=_blank>����꣬������Ϥ��Ϥ</a>]�赽�Ŀ�","1314753325","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("383","38","margin","505.84","50.00","455.84","50.00","0.00","0","��������[<a href=\'/invest/a16.html\' target=_blank>����꣬������Ϥ��Ϥ</a>]�ı�֤��","1314753325","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("384","38","borrow_fee","495.84","10.00","445.84","50.00","0.00","0","���[<a href=\'/invest/a16.html\' target=_blank>����꣬������Ϥ��Ϥ</a>]��������","1314753325","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("385","38","vip","495.84","0.00","445.84","50.00","0.00","0","�۳�VIP��Ա��","1314753325","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("386","26","realname","1003.50","10.00","504.00","499.50","0.00","0","ʵ����֤�۳�����","1314753478","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("387","24","realname","1003.50","10.00","504.00","499.50","0.00","0","ʵ����֤�۳�����","1314753500","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("388","19","realname","1104.40","10.00","604.40","500.00","0.00","0","ʵ����֤�۳�����","1314753522","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("389","18","realname","1113.73","10.00","1113.73","0.00","0.00","0","ʵ����֤�۳�����","1314753557","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("390","28","vip","25.64","0.00","25.64","0.00","0.00","0","�۳�VIP��Ա��","1314754101","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("391","28","account_other","25.64","0.00","25.64","0.00","0.00","0","180","1314754228","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("392","43","recharge","10000.00","10000.00","10000.00","0.00","0.00","0","�˺ų�ֵ","1314754503","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("393","43","tender","10000.00","5000.00","5000.00","5000.00","0.00","4","Ͷ�궳���ʽ�","1314754545","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("394","33","realname","0.89","10.00","0.89","0.00","0.00","0","ʵ����֤�۳�����","1314755033","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("395","43","tender","10000.00","800.00","4200.00","5800.00","0.00","13","Ͷ�궳���ʽ�","1314757224","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("396","44","recharge","30.00","30.00","30.00","0.00","0.00","0","�˺ų�ֵ","1314758637","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("397","22","tender","1016.77","629.27","0.00","1016.77","0.00","33","Ͷ�궳���ʽ�","1314758800","113.65.187.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("398","16","tender","2230.95","370.73","1360.22","870.73","0.00","33","Ͷ�궳���ʽ�","1314758929","113.65.186.215");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("399","44","realname","20.00","10.00","20.00","0.00","0.00","0","ʵ����֤�۳�����","1314758942","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("400","44","vip","20.00","0.00","20.00","0.00","0.00","0","�۳�VIP��Ա��","1314758974","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("401","43","tender","10000.00","500.00","3700.00","6300.00","0.00","44","Ͷ�궳���ʽ�","1314759796","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("402","5","tender","10046.06","3000.00","4043.02","5800.00","203.04","4","Ͷ�궳���ʽ�","1314760544","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("403","27","recharge","5030.00","5030.00","5030.00","0.00","0.00","0","�˺ų�ֵ","1314761004","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("404","27","tender","5030.00","5000.00","30.00","5000.00","0.00","4","Ͷ�궳���ʽ�","1314761098","180.110.4.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("405","16","tender","2230.95","1360.22","0.00","2230.95","0.00","4","Ͷ�궳���ʽ�","1314761421","113.65.186.215");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("406","45","recharge","5010.00","5010.00","5010.00","0.00","0.00","0","�˺ų�ֵ","1314761562","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("407","45","tender","5010.00","5000.00","10.00","5000.00","0.00","4","Ͷ�궳���ʽ�","1314761747","180.110.4.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("408","46","recharge","5010.00","5010.00","5010.00","0.00","0.00","0","�˺ų�ֵ","1314763864","58.46.178.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("409","14","tender","2415.70","1916.11","500.00","1915.70","0.00","4","Ͷ�궳���ʽ�","1314764015","113.65.172.7");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("410","18","tender","1113.73","723.67","390.06","723.67","0.00","4","Ͷ�궳���ʽ�","1314764066","113.65.185.211");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("411","18","tender","1113.73","390.06","0.00","1113.73","0.00","44","Ͷ�궳���ʽ�","1314764093","113.65.185.211");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("412","19","tender","1104.40","500.00","104.40","1000.00","0.00","44","Ͷ�궳���ʽ�","1314764693","113.66.243.41");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("413","24","tender","1003.50","500.00","4.00","999.50","0.00","44","Ͷ�궳���ʽ�","1314764810","113.65.186.224");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("414","26","tender","1003.50","500.00","4.00","999.50","0.00","44","Ͷ�궳���ʽ�","1314764863","113.65.187.184");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("415","14","tender","2415.70","500.00","0.00","2415.70","0.00","44","Ͷ�궳���ʽ�","1314764941","113.65.185.61");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("416","46","tender","5010.00","500.00","4510.00","500.00","0.00","44","Ͷ�궳���ʽ�","1314767105","222.94.41.7");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("417","27","recharge","10190.00","5160.00","5190.00","5000.00","0.00","0","�˺ų�ֵ","1314782232","118.253.15.116");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("418","27","tender","10190.00","500.00","4690.00","5500.00","0.00","44","Ͷ�궳���ʽ�","1314782310","180.110.4.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("419","45","recharge","10190.00","5180.00","5190.00","5000.00","0.00","0","�˺ų�ֵ","1314782906","118.253.15.116");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("420","45","tender","10190.00","500.00","4690.00","5500.00","0.00","44","Ͷ�궳���ʽ�","1314783047","180.110.4.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("421","46","recharge","10190.00","5180.00","9690.00","500.00","0.00","0","�˺ų�ֵ","1314783245","113.219.8.170");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("422","27","vip","10010.00","180.00","4510.00","5500.00","0.00","0","�۳�VIP��Ա��","1314789355","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("423","45","vip","10010.00","180.00","4510.00","5500.00","0.00","0","�۳�VIP��Ա��","1314789392","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("424","46","vip","10010.00","180.00","9510.00","500.00","0.00","0","�۳�VIP��Ա��","1314789424","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("425","22","invest","387.50","629.27","0.00","387.50","0.00","33","Ͷ��ɹ����ÿ۳�","1314789581","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("426","22","collection","1028.31","640.81","0.00","387.50","640.81","33","���ս��","1314789581","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("427","16","invest","1860.22","370.73","0.00","1860.22","0.00","33","Ͷ��ɹ����ÿ۳�","1314789582","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("428","16","collection","2237.75","377.53","0.00","1860.22","377.53","33","���ս��","1314789582","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("429","33","borrow_success","1000.89","1000.00","1000.89","0.00","0.00","0","ͨ��[<a href=\'/invest/a20.html\' target=_blank>��һ�� лл </a>]�赽�Ŀ�","1314789582","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("430","33","margin","1000.89","100.00","900.89","100.00","0.00","0","��������[<a href=\'/invest/a20.html\' target=_blank>��һ�� лл </a>]�ı�֤��","1314789582","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("431","33","borrow_fee","980.89","20.00","880.89","100.00","0.00","0","���[<a href=\'/invest/a20.html\' target=_blank>��һ�� лл </a>]��������","1314789582","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("432","33","vip","800.89","180.00","700.89","100.00","0.00","0","�۳�VIP��Ա��","1314789582","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("433","5","invest","8046.06","2000.00","4043.02","3800.00","203.04","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("434","5","collection","10076.06","2030.00","4043.02","3800.00","2233.04","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("435","12","invest","7639.49","2000.00","2830.38","4200.00","609.11","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("436","12","collection","9669.49","2030.00","2830.38","4200.00","2639.11","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("437","6","invest","8054.13","2000.00","6851.09","1000.00","203.04","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("438","6","collection","10084.13","2030.00","6851.09","1000.00","2233.04","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("439","11","invest","8039.57","2000.00","8039.57","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("440","11","collection","10069.57","2030.00","8039.57","0.00","2030.00","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("441","34","invest","2820.00","2000.00","1000.00","1820.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("442","34","collection","4850.00","2030.00","1000.00","1820.00","2030.00","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("443","12","invest","6669.49","3000.00","2830.38","1200.00","2639.11","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("444","12","collection","9714.49","3045.00","2830.38","1200.00","5684.11","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("445","40","invest","5000.00","5000.00","1820.00","3180.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("446","40","collection","10075.00","5075.00","1820.00","3180.00","5075.00","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("447","41","invest","5000.00","5000.00","5000.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("448","41","collection","10075.00","5075.00","5000.00","0.00","5075.00","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("449","42","invest","5000.00","5000.00","5000.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("450","42","collection","10075.00","5075.00","5000.00","0.00","5075.00","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("451","43","invest","5000.00","5000.00","3700.00","1300.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("452","43","collection","10075.00","5075.00","3700.00","1300.00","5075.00","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("453","5","invest","7076.06","3000.00","4043.02","800.00","2233.04","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("454","5","collection","10121.06","3045.00","4043.02","800.00","5278.04","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("455","27","invest","5010.00","5000.00","4510.00","500.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("456","27","collection","10085.00","5075.00","4510.00","500.00","5075.00","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("457","16","invest","877.53","1360.22","0.00","500.00","377.53","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("458","16","collection","2258.15","1380.62","0.00","500.00","1758.15","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("459","45","invest","5010.00","5000.00","4510.00","500.00","0.00","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("460","45","collection","10085.00","5075.00","4510.00","500.00","5075.00","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("461","14","invest","499.59","1916.11","0.00","499.59","0.00","4","Ͷ��ɹ����ÿ۳�","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("462","14","collection","2444.44","1944.85","0.00","499.59","1944.85","4","���ս��","1314789682","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("463","18","invest","390.06","723.67","0.00","390.06","0.00","4","Ͷ��ɹ����ÿ۳�","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("464","18","collection","1124.59","734.53","0.00","390.06","734.53","4","���ս��","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("465","4","borrow_success","59430.49","50000.00","59430.49","0.00","0.00","0","ͨ��[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�赽�Ŀ�","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("466","4","margin","59430.49","5000.00","54430.49","5000.00","0.00","0","��������[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�ı�֤��","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("467","4","borrow_fee","58430.49","1000.00","53430.49","5000.00","0.00","0","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]��������","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("468","5","award_add","10141.06","20.00","4063.02","800.00","5278.04","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("469","4","award_lower","58410.49","20.00","53410.49","5000.00","0.00","5","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("470","12","award_add","9734.49","20.00","2850.38","1200.00","5684.11","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("471","4","award_lower","58390.49","20.00","53390.49","5000.00","0.00","12","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("472","6","award_add","10104.13","20.00","6871.09","1000.00","2233.04","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("473","4","award_lower","58370.49","20.00","53370.49","5000.00","0.00","6","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("474","11","award_add","10089.57","20.00","8059.57","0.00","2030.00","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("475","4","award_lower","58350.49","20.00","53350.49","5000.00","0.00","11","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("476","34","award_add","4870.00","20.00","1020.00","1820.00","2030.00","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("477","4","award_lower","58330.49","20.00","53330.49","5000.00","0.00","34","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("478","12","award_add","9764.49","30.00","2880.38","1200.00","5684.11","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("479","4","award_lower","58300.49","30.00","53300.49","5000.00","0.00","12","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("480","40","award_add","10125.00","50.00","1870.00","3180.00","5075.00","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("481","4","award_lower","58250.49","50.00","53250.49","5000.00","0.00","40","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("482","41","award_add","10125.00","50.00","5050.00","0.00","5075.00","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("483","4","award_lower","58200.49","50.00","53200.49","5000.00","0.00","41","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("484","42","award_add","10125.00","50.00","5050.00","0.00","5075.00","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("485","4","award_lower","58150.49","50.00","53150.49","5000.00","0.00","42","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("486","43","award_add","10125.00","50.00","3750.00","1300.00","5075.00","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("487","4","award_lower","58100.49","50.00","53100.49","5000.00","0.00","43","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("488","5","award_add","10171.06","30.00","4093.02","800.00","5278.04","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("489","4","award_lower","58070.49","30.00","53070.49","5000.00","0.00","5","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("490","27","award_add","10135.00","50.00","4560.00","500.00","5075.00","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("491","4","award_lower","58020.49","50.00","53020.49","5000.00","0.00","27","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("492","16","award_add","2271.75","13.60","13.60","500.00","1758.15","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("493","4","award_lower","58006.89","13.60","53006.89","5000.00","0.00","16","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("494","45","award_add","10135.00","50.00","4560.00","500.00","5075.00","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("495","4","award_lower","57956.89","50.00","52956.89","5000.00","0.00","45","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("496","14","award_add","2463.60","19.16","19.16","499.59","1944.85","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("497","4","award_lower","57937.73","19.16","52937.73","5000.00","0.00","14","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("498","18","award_add","1131.83","7.24","7.24","390.06","734.53","4","���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("499","4","award_lower","57930.49","7.24","52930.49","5000.00","0.00","18","�۳����[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]�Ľ���","1314789683","113.219.34.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("500","4","repayment","7180.49","50750.00","2180.49","5000.00","0.00","0","��[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]����","1314798827","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("501","4","borrow_frost","7180.49","5000.00","7180.49","0.00","0.00","0","��[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ľⶳ","1314798827","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("502","5","invest_repayment","10171.06","2030.00","6123.02","800.00","3248.04","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798827","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("503","5","tender_mange","10168.06","3.00","6120.02","800.00","3248.04","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798827","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("504","12","invest_repayment","9764.49","2030.00","4910.38","1200.00","3654.11","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798827","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("505","12","tender_mange","9761.49","3.00","4907.38","1200.00","3654.11","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("506","6","invest_repayment","10104.13","2030.00","8901.09","1000.00","203.04","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("507","6","tender_mange","10101.13","3.00","8898.09","1000.00","203.04","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("508","11","invest_repayment","10089.57","2030.00","10089.57","0.00","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("509","11","tender_mange","10086.57","3.00","10086.57","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("510","34","invest_repayment","4870.00","2030.00","3050.00","1820.00","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("511","34","tender_mange","4867.00","3.00","3047.00","1820.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("512","12","invest_repayment","9761.49","3045.00","7952.38","1200.00","609.11","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("513","12","tender_mange","9756.99","4.50","7947.88","1200.00","609.11","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("514","40","invest_repayment","10125.00","5075.00","6945.00","3180.00","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("515","40","tender_mange","10117.50","7.50","6937.50","3180.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("516","41","invest_repayment","10125.00","5075.00","10125.00","0.00","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("517","41","tender_mange","10117.50","7.50","10117.50","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("518","42","invest_repayment","10125.00","5075.00","10125.00","0.00","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("519","42","tender_mange","10117.50","7.50","10117.50","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("520","43","invest_repayment","10125.00","5075.00","8825.00","1300.00","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("521","43","tender_mange","10117.50","7.50","8817.50","1300.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("522","5","invest_repayment","10168.06","3045.00","9165.02","800.00","203.04","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("523","5","tender_mange","10163.56","4.50","9160.52","800.00","203.04","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("524","27","invest_repayment","10135.00","5075.00","9635.00","500.00","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("525","27","tender_mange","10127.50","7.50","9627.50","500.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("526","16","invest_repayment","2271.75","1380.62","1394.22","500.00","377.53","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("527","16","tender_mange","2269.71","2.04","1392.18","500.00","377.53","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798828","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("528","45","invest_repayment","10135.00","5075.00","9635.00","500.00","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798829","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("529","45","tender_mange","10127.50","7.50","9627.50","500.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798829","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("530","14","invest_repayment","2463.60","1944.85","1964.01","499.59","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798829","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("531","14","tender_mange","2460.73","2.87","1961.14","499.59","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798829","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("532","18","invest_repayment","1131.83","734.53","741.77","390.06","0.00","4","�ͻ���[<a href=\'/invest/a10.html\' target=_blank>��л����Ͷ�����ѵ�֧�� �������һ��</a>]���Ļ���","1314798829","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("533","18","tender_mange","1130.74","1.09","740.68","390.06","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314798829","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("534","46","realname","10000.00","10.00","9500.00","500.00","0.00","0","ʵ����֤�۳�����","1314799064","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("535","45","realname","10117.50","10.00","9617.50","500.00","0.00","0","ʵ����֤�۳�����","1314799083","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("536","27","realname","10117.50","10.00","9617.50","500.00","0.00","0","ʵ����֤�۳�����","1314799101","113.219.199.111");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("537","18","tender","1130.74","109.94","630.74","500.00","0.00","44","Ͷ�궳���ʽ�","1314801230","113.65.172.148");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("538","16","tender","2269.71","500.00","892.18","1000.00","377.53","44","Ͷ�궳���ʽ�","1314801427","113.65.153.33");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("539","38","recharge","555.84","60.00","505.84","50.00","0.00","0","���߳�ֵ","1314826080","61.152.88.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("540","38","fee","555.24","0.60","505.24","50.00","0.00","0","���߳�ֵ������","1314826080","61.152.88.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("541","38","recharge","565.24","10.00","515.24","50.00","0.00","0","���߳�ֵ","1314826240","61.152.88.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("542","38","fee","565.14","0.10","515.14","50.00","0.00","0","���߳�ֵ������","1314826240","61.152.88.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("543","38","repayment","58.89","506.25","8.89","50.00","0.00","0","��[<a href=\'/invest/a16.html\' target=_blank>����꣬������Ϥ��Ϥ</a>]����","1314826284","113.117.117.22");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("544","38","borrow_frost","58.89","50.00","58.89","0.00","0.00","0","��[<a href=\'/invest/a16.html\' target=_blank>����꣬������Ϥ��Ϥ</a>]���Ľⶳ","1314826284","113.117.117.22");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("545","23","invest_repayment","1009.75","506.25","509.75","500.00","0.00","38","�ͻ���[<a href=\'/invest/a16.html\' target=_blank>����꣬������Ϥ��Ϥ</a>]���Ļ���","1314826284","113.117.117.22");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("546","23","tender_mange","1009.13","0.63","509.13","500.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314826284","113.117.117.22");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("547","38","account_other","-121.11","180.00","-121.11","0.00","0.00","0","��ȡvip","1314840330","113.219.169.177");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("548","27","tender","10117.50","2000.00","7617.50","2500.00","0.00","38","Ͷ�궳���ʽ�","1314841482","180.110.4.119");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("549","33","recharge","920.89","120.00","820.89","100.00","0.00","0","�˺ų�ֵ","1314849119","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("550","16","invest","1769.71","500.00","892.18","500.00","377.53","39","Ͷ��ɹ����ÿ۳�","1314849364","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("551","16","collection","2274.71","505.00","892.18","500.00","882.53","39","���ս��","1314849364","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("552","23","invest","509.13","500.00","509.13","0.00","0.00","39","Ͷ��ɹ����ÿ۳�","1314849365","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("553","23","collection","1014.13","505.00","509.13","0.00","505.00","39","���ս��","1314849365","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("554","24","invest","503.50","500.00","4.00","499.50","0.00","39","Ͷ��ɹ����ÿ۳�","1314849366","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("555","24","collection","1008.50","505.00","4.00","499.50","505.00","39","���ս��","1314849366","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("556","26","invest","503.50","500.00","4.00","499.50","0.00","39","Ͷ��ɹ����ÿ۳�","1314849366","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("557","26","collection","1008.50","505.00","4.00","499.50","505.00","39","���ս��","1314849366","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("558","19","invest","604.40","500.00","104.40","500.00","0.00","39","Ͷ��ɹ����ÿ۳�","1314849366","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("559","19","collection","1109.40","505.00","104.40","500.00","505.00","39","���ս��","1314849366","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("560","22","invest","640.31","388.00","0.00","-0.50","640.81","39","Ͷ��ɹ����ÿ۳�","1314849367","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("561","22","collection","1032.19","391.88","0.00","-0.50","1032.69","39","���ս��","1314849367","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("562","39","borrow_success","2978.00","2888.00","2978.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]�赽�Ŀ�","1314849367","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("563","39","margin","2978.00","288.80","2689.20","288.80","0.00","0","��������[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]�ı�֤��","1314849367","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("564","39","borrow_fee","2920.24","57.76","2631.44","288.80","0.00","0","���[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]��������","1314849367","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("565","33","recharge","1020.89","100.00","920.89","100.00","0.00","0","�˺ų�ֵ","1314851415","58.46.183.83");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("566","50","recharge","100.00","100.00","100.00","0.00","0.00","0","�˺ų�ֵ","1314866580","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("567","49","recharge","50.00","50.00","50.00","0.00","0.00","0","�˺ų�ֵ","1314866591","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("568","50","realname","90.00","10.00","90.00","0.00","0.00","0","ʵ����֤�۳�����","1314867167","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("569","49","realname","40.00","10.00","40.00","0.00","0.00","0","ʵ����֤�۳�����","1314867208","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("570","50","vip","90.00","0.00","90.00","0.00","0.00","0","�۳�VIP��Ա��","1314867241","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("571","49","vip","40.00","0.00","40.00","0.00","0.00","0","�۳�VIP��Ա��","1314867257","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("572","6","tender","10101.13","500.00","8398.09","1500.00","203.04","50","Ͷ�궳���ʽ�","1314868128","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("573","6","tender","10101.13","2000.00","6398.09","3500.00","203.04","4","Ͷ�궳���ʽ�","1314868169","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("574","6","tender","10101.13","500.00","5898.09","4000.00","203.04","49","Ͷ�궳���ʽ�","1314868189","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("575","6","tender","10101.13","3000.00","2898.09","7000.00","203.04","20","Ͷ�궳���ʽ�","1314868215","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("576","33","recharge","1120.89","100.00","1020.89","100.00","0.00","0","�˺ų�ֵ","1314871842","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("577","5","tender","10163.56","2000.00","7160.52","2800.00","203.04","4","Ͷ�궳���ʽ�","1314872031","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("578","5","tender","10163.56","2000.00","5160.52","4800.00","203.04","20","Ͷ�궳���ʽ�","1314872131","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("579","5","tender","10163.56","500.00","4660.52","5300.00","203.04","50","Ͷ�궳���ʽ�","1314872177","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("580","5","tender","10163.56","500.00","4160.52","5800.00","203.04","49","Ͷ�궳���ʽ�","1314872238","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("581","39","recharge","3270.24","350.00","2981.44","288.80","0.00","0","�˺ų�ֵ","1314872376","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("582","5","tender","10163.56","1160.00","3000.52","6960.00","203.04","13","Ͷ�궳���ʽ�","1314872454","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("583","39","repayment","353.36","2916.88","64.56","288.80","0.00","0","��[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]����","1314872500","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("584","39","borrow_frost","353.36","288.80","353.36","0.00","0.00","0","��[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]���Ľⶳ","1314872500","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("585","16","invest_repayment","2274.71","505.00","1397.18","500.00","377.53","39","�ͻ���[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]���Ļ���","1314872500","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("586","16","tender_mange","2274.21","0.50","1396.68","500.00","377.53","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314872500","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("587","23","invest_repayment","1014.13","505.00","1014.13","0.00","0.00","39","�ͻ���[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]���Ļ���","1314872501","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("588","23","tender_mange","1013.63","0.50","1013.63","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314872501","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("589","24","invest_repayment","1008.50","505.00","509.00","499.50","0.00","39","�ͻ���[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]���Ļ���","1314872501","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("590","24","tender_mange","1008.00","0.50","508.50","499.50","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314872501","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("591","26","invest_repayment","1008.50","505.00","509.00","499.50","0.00","39","�ͻ���[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]���Ļ���","1314872502","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("592","26","tender_mange","1008.00","0.50","508.50","499.50","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314872502","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("593","19","invest_repayment","1109.40","505.00","609.40","500.00","0.00","39","�ͻ���[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]���Ļ���","1314872502","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("594","19","tender_mange","1108.90","0.50","608.90","500.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314872502","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("595","22","invest_repayment","1032.19","391.88","391.88","-0.50","640.81","39","�ͻ���[<a href=\'/invest/a17.html\' target=_blank>���£�������վʵ��</a>]���Ļ���","1314872502","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("596","22","tender_mange","1031.80","0.39","391.49","-0.50","640.81","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314872502","113.219.247.72");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("597","14","tender","2460.73","500.00","1461.14","999.59","0.00","49","Ͷ�궳���ʽ�","1314872632","113.65.154.93");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("598","18","tender","1130.74","500.00","130.74","1000.00","0.00","49","Ͷ�궳���ʽ�","1314872947","113.65.152.154");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("599","16","tender","2274.21","500.00","896.68","1000.00","377.53","49","Ͷ�궳���ʽ�","1314872980","113.65.153.207");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("600","23","tender","1013.63","500.00","513.63","500.00","0.00","49","Ͷ�궳���ʽ�","1314873018","113.65.175.180");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("601","24","tender","1008.00","500.00","8.50","999.50","0.00","49","Ͷ�궳���ʽ�","1314873063","113.65.185.5");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("602","26","tender","1008.00","500.00","8.50","999.50","0.00","49","Ͷ�궳���ʽ�","1314873093","113.65.185.5");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("603","22","tender","1031.80","391.49","0.00","390.99","640.81","49","Ͷ�궳���ʽ�","1314873211","113.65.153.214");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("604","19","tender","1108.90","500.00","108.90","1000.00","0.00","49","Ͷ�궳���ʽ�","1314873247","113.65.185.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("605","27","tender","10117.50","500.00","7117.50","3000.00","0.00","50","Ͷ�궳���ʽ�","1314873770","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("606","27","tender","10117.50","108.51","7008.99","3108.51","0.00","49","Ͷ�궳���ʽ�","1314873800","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("607","27","tender","10117.50","2000.00","5008.99","5108.51","0.00","4","Ͷ�궳���ʽ�","1314873840","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("608","27","tender","10117.50","5008.99","0.00","10117.50","0.00","12","Ͷ�궳���ʽ�","1314873875","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("609","46","tender","10000.00","3879.01","5620.99","4379.01","0.00","12","Ͷ�궳���ʽ�","1314873911","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("610","46","tender","10000.00","2000.00","3620.99","6379.01","0.00","4","Ͷ�궳���ʽ�","1314873939","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("611","46","tender","10000.00","500.00","3120.99","6879.01","0.00","50","Ͷ�궳���ʽ�","1314873962","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("612","46","tender","10000.00","500.00","2620.99","7379.01","0.00","39","Ͷ�궳���ʽ�","1314873987","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("613","45","tender","10117.50","500.00","9117.50","1000.00","0.00","39","Ͷ�궳���ʽ�","1314874274","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("614","45","tender","10117.50","500.00","8617.50","1500.00","0.00","50","Ͷ�궳���ʽ�","1314874298","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("615","45","tender","10117.50","2000.00","6617.50","3500.00","0.00","4","Ͷ�궳���ʽ�","1314874318","112.2.85.17");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("616","14","tender","2460.73","500.00","961.14","1499.59","0.00","50","Ͷ�궳���ʽ�","1314898778","113.65.155.196");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("617","14","tender","2460.73","500.00","461.14","1999.59","0.00","39","Ͷ�궳���ʽ�","1314898850","113.65.155.196");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("618","18","tender","1130.74","130.74","0.00","1130.74","0.00","50","Ͷ�궳���ʽ�","1314898908","113.65.155.244");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("619","16","tender","2274.21","500.00","396.68","1500.00","377.53","50","Ͷ�궳���ʽ�","1314898953","113.65.152.15");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("620","23","tender","1013.63","500.00","13.63","1000.00","0.00","50","Ͷ�궳���ʽ�","1314899045","113.65.152.37");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("621","19","tender","1108.90","108.90","0.00","1108.90","0.00","50","Ͷ�궳���ʽ�","1314899092","113.65.152.69");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("622","33","repayment","102.56","1018.33","2.56","100.00","0.00","0","��[<a href=\'/invest/a20.html\' target=_blank>��һ�� лл </a>]����","1314928141","118.250.168.196");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("623","33","borrow_frost","102.56","100.00","102.56","0.00","0.00","0","��[<a href=\'/invest/a20.html\' target=_blank>��һ�� лл </a>]���Ľⶳ","1314928141","118.250.168.196");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("624","22","invest_repayment","1031.80","640.81","640.81","390.99","0.00","33","�ͻ���[<a href=\'/invest/a20.html\' target=_blank>��һ�� лл </a>]���Ļ���","1314928141","118.250.168.196");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("625","22","tender_mange","1030.65","1.15","639.66","390.99","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314928141","118.250.168.196");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("626","16","invest_repayment","2274.21","377.53","774.21","1500.00","0.00","33","�ͻ���[<a href=\'/invest/a20.html\' target=_blank>��һ�� лл </a>]���Ļ���","1314928142","118.250.168.196");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("627","16","tender_mange","2273.53","0.68","773.53","1500.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1314928142","118.250.168.196");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("628","14","recharge","2507.49","46.76","507.90","1999.59","0.00","0","�˺ų�ֵ","1314929852","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("629","16","recharge","2317.63","44.10","817.63","1500.00","0.00","0","�˺ų�ֵ","1314929864","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("630","18","recharge","1152.74","22.00","22.00","1130.74","0.00","0","�˺ų�ֵ","1314929875","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("631","19","recharge","1130.90","22.00","22.00","1108.90","0.00","0","�˺ų�ֵ","1314929885","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("632","22","recharge","1050.65","20.00","659.66","390.99","0.00","0","�˺ų�ֵ","1314929896","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("633","23","recharge","1033.63","20.00","33.63","1000.00","0.00","0","�˺ų�ֵ","1314929908","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("634","24","recharge","1028.00","20.00","28.50","999.50","0.00","0","�˺ų�ֵ","1314929922","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("635","26","recharge","1028.00","20.00","28.50","999.50","0.00","0","�˺ų�ֵ","1314929933","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("636","27","recharge","10423.20","305.70","305.70","10117.50","0.00","0","�˺ų�ֵ","1314929948","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("637","45","recharge","10423.20","305.70","6923.20","3500.00","0.00","0","�˺ų�ֵ","1314929964","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("638","34","tender","4867.00","2000.00","1047.00","3820.00","0.00","4","Ͷ�궳���ʽ�","1314930060","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("639","34","tender","4867.00","500.00","547.00","4320.00","0.00","28","Ͷ�궳���ʽ�","1314930239","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("640","34","tender","4867.00","500.00","47.00","4820.00","0.00","39","Ͷ�궳���ʽ�","1314930275","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("641","7","tender","10013.50","2000.00","8013.50","2000.00","0.00","4","Ͷ�궳���ʽ�","1314930457","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("642","7","tender","10013.50","3000.00","5013.50","5000.00","0.00","20","Ͷ�궳���ʽ�","1314930484","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("643","11","tender","10086.57","2000.00","8086.57","2000.00","0.00","4","Ͷ�궳���ʽ�","1314930632","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("644","43","tender","10117.50","2000.00","6817.50","3300.00","0.00","4","Ͷ�궳���ʽ�","1314930675","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("645","43","tender","10117.50","5040.00","1777.50","8340.00","0.00","13","Ͷ�궳���ʽ�","1314930739","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("646","43","tender","10117.50","500.00","1277.50","8840.00","0.00","39","Ͷ�궳���ʽ�","1314930783","113.219.121.221");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("647","27","tender","10423.20","305.70","0.00","10423.20","0.00","39","Ͷ�궳���ʽ�","1314934170","180.110.133.168");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("648","40","tender","10117.50","2000.00","4937.50","5180.00","0.00","4","Ͷ�궳���ʽ�","1314955229","113.219.155.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("649","42","tender","10117.50","2000.00","8117.50","2000.00","0.00","4","Ͷ�궳���ʽ�","1314955416","113.219.155.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("650","42","tender","10117.50","1500.00","6617.50","3500.00","0.00","33","Ͷ�궳���ʽ�","1314955445","113.219.155.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("651","42","tender","10117.50","100.00","6517.50","3600.00","0.00","50","Ͷ�궳���ʽ�","1314955499","113.219.155.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("652","42","tender","10117.50","1500.00","5017.50","5100.00","0.00","20","Ͷ�궳���ʽ�","1314955528","113.219.155.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("653","12","tender","9756.99","2000.00","5947.88","3200.00","609.11","4","Ͷ�궳���ʽ�","1314955583","113.219.155.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("654","27","invest_false","10423.20","2000.00","2000.00","8423.20","0.00","38","�б�[<a href=\'/invest/a22.html\' target=_blank>��2��~~~~�ٴ����飡��</a>]ʧ�ܷ��ص�Ͷ���","1315353094","113.117.119.47");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("655","22","tender","1050.65","500.00","159.66","890.99","0.00","50","Ͷ�궳���ʽ�","1315391742","113.65.185.0");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("656","22","tender","1050.65","159.66","0.00","1050.65","0.00","39","Ͷ�궳���ʽ�","1315391766","113.65.185.0");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("657","16","tender","2317.63","500.00","317.63","2000.00","0.00","39","Ͷ�궳���ʽ�","1315391911","113.65.185.0");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("658","27","invest","5414.21","5008.99","2000.00","3414.21","0.00","12","Ͷ��ɹ����ÿ۳�","1315441757","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("659","27","collection","10473.29","5059.08","2000.00","3414.21","5059.08","12","���ս��","1315441757","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("660","46","invest","6120.99","3879.01","2620.99","3500.00","0.00","12","Ͷ��ɹ����ÿ۳�","1315441757","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("661","46","collection","10038.79","3917.80","2620.99","3500.00","3917.80","12","���ս��","1315441757","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("662","12","borrow_success","18644.99","8888.00","14835.88","3200.00","609.11","0","ͨ��[<a href=\'/invest/a28.html\' target=_blank>��л��վ�Ľ���  ��������������</a>]�赽�Ŀ�","1315441757","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("663","12","margin","18644.99","888.80","13947.08","4088.80","609.11","0","��������[<a href=\'/invest/a28.html\' target=_blank>��л��վ�Ľ���  ��������������</a>]�ı�֤��","1315441757","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("664","12","borrow_fee","18467.23","177.76","13769.32","4088.80","609.11","0","���[<a href=\'/invest/a28.html\' target=_blank>��л��վ�Ľ���  ��������������</a>]��������","1315441757","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("665","34","invest","4367.00","500.00","47.00","4320.00","0.00","28","Ͷ��ɹ����ÿ۳�","1315441770","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("666","34","collection","4870.33","503.33","47.00","4320.00","503.33","28","���ս��","1315441770","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("667","28","borrow_success","525.64","500.00","525.64","0.00","0.00","0","ͨ��[<a href=\'/invest/a26.html\' target=_blank>������</a>]�赽�Ŀ�","1315441770","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("668","28","margin","525.64","50.00","475.64","50.00","0.00","0","��������[<a href=\'/invest/a26.html\' target=_blank>������</a>]�ı�֤��","1315441770","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("669","28","borrow_fee","515.64","10.00","465.64","50.00","0.00","0","���[<a href=\'/invest/a26.html\' target=_blank>������</a>]��������","1315441770","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("670","6","invest","9601.13","500.00","2898.09","6500.00","203.04","49","Ͷ��ɹ����ÿ۳�","1315441818","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("671","6","collection","10106.13","505.00","2898.09","6500.00","708.04","49","���ս��","1315441818","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("672","5","invest","9663.56","500.00","3000.52","6460.00","203.04","49","Ͷ��ɹ����ÿ۳�","1315441818","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("673","5","collection","10168.56","505.00","3000.52","6460.00","708.04","49","���ս��","1315441818","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("674","14","invest","2007.49","500.00","507.90","1499.59","0.00","49","Ͷ��ɹ����ÿ۳�","1315441818","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("675","14","collection","2512.49","505.00","507.90","1499.59","505.00","49","���ս��","1315441818","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("676","18","invest","652.74","500.00","22.00","630.74","0.00","49","Ͷ��ɹ����ÿ۳�","1315441819","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("677","18","collection","1157.74","505.00","22.00","630.74","505.00","49","���ս��","1315441819","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("678","16","invest","1817.63","500.00","317.63","1500.00","0.00","49","Ͷ��ɹ����ÿ۳�","1315441819","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("679","16","collection","2322.63","505.00","317.63","1500.00","505.00","49","���ս��","1315441819","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("680","23","invest","533.63","500.00","33.63","500.00","0.00","49","Ͷ��ɹ����ÿ۳�","1315441819","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("681","23","collection","1038.63","505.00","33.63","500.00","505.00","49","���ս��","1315441819","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("682","24","invest","528.00","500.00","28.50","499.50","0.00","49","Ͷ��ɹ����ÿ۳�","1315441820","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("683","24","collection","1033.00","505.00","28.50","499.50","505.00","49","���ս��","1315441820","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("684","26","invest","528.00","500.00","28.50","499.50","0.00","49","Ͷ��ɹ����ÿ۳�","1315441820","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("685","26","collection","1033.00","505.00","28.50","499.50","505.00","49","���ս��","1315441820","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("686","22","invest","659.16","391.49","0.00","659.16","0.00","49","Ͷ��ɹ����ÿ۳�","1315441820","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("687","22","collection","1054.56","395.40","0.00","659.16","395.40","49","���ս��","1315441820","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("688","19","invest","630.90","500.00","22.00","608.90","0.00","49","Ͷ��ɹ����ÿ۳�","1315441821","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("689","19","collection","1135.90","505.00","22.00","608.90","505.00","49","���ս��","1315441821","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("690","27","invest","10364.78","108.51","2000.00","3305.70","5059.08","49","Ͷ��ɹ����ÿ۳�","1315441821","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("691","27","collection","10474.38","109.60","2000.00","3305.70","5168.68","49","���ս��","1315441821","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("692","49","borrow_success","5040.00","5000.00","5040.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]�赽�Ŀ�","1315441821","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("693","49","margin","5040.00","500.00","4540.00","500.00","0.00","0","��������[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]�ı�֤��","1315441821","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("694","49","borrow_fee","4940.00","100.00","4440.00","500.00","0.00","0","���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]��������","1315441821","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("695","43","invest","9617.50","500.00","1277.50","8340.00","0.00","44","Ͷ��ɹ����ÿ۳�","1315441851","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("696","43","collection","10122.50","505.00","1277.50","8340.00","505.00","44","���ս��","1315441851","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("697","18","invest","767.68","390.06","22.00","240.68","505.00","44","Ͷ��ɹ����ÿ۳�","1315441851","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("698","18","collection","1161.64","393.96","22.00","240.68","898.96","44","���ս��","1315441851","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("699","19","invest","635.90","500.00","22.00","108.90","505.00","44","Ͷ��ɹ����ÿ۳�","1315441852","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("700","19","collection","1140.90","505.00","22.00","108.90","1010.00","44","���ս��","1315441852","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("701","24","invest","533.00","500.00","28.50","-0.50","505.00","44","Ͷ��ɹ����ÿ۳�","1315441852","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("702","24","collection","1038.00","505.00","28.50","-0.50","1010.00","44","���ս��","1315441852","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("703","26","invest","533.00","500.00","28.50","-0.50","505.00","44","Ͷ��ɹ����ÿ۳�","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("704","26","collection","1038.00","505.00","28.50","-0.50","1010.00","44","���ս��","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("705","14","invest","2012.49","500.00","507.90","999.59","505.00","44","Ͷ��ɹ����ÿ۳�","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("706","14","collection","2517.49","505.00","507.90","999.59","1010.00","44","���ս��","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("707","46","invest","9538.79","500.00","2620.99","3000.00","3917.80","44","Ͷ��ɹ����ÿ۳�","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("708","46","collection","10043.79","505.00","2620.99","3000.00","4422.80","44","���ս��","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("709","27","invest","9974.38","500.00","2000.00","2805.70","5168.68","44","Ͷ��ɹ����ÿ۳�","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("710","27","collection","10479.38","505.00","2000.00","2805.70","5673.68","44","���ս��","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("711","45","invest","9923.20","500.00","6923.20","3000.00","0.00","44","Ͷ��ɹ����ÿ۳�","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("712","45","collection","10428.20","505.00","6923.20","3000.00","505.00","44","���ս��","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("713","18","invest","1051.70","109.94","22.00","130.74","898.96","44","Ͷ��ɹ����ÿ۳�","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("714","18","collection","1162.74","111.04","22.00","130.74","1010.00","44","���ս��","1315441853","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("715","16","invest","1822.63","500.00","317.63","1000.00","505.00","44","Ͷ��ɹ����ÿ۳�","1315441854","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("716","16","collection","2327.63","505.00","317.63","1000.00","1010.00","44","���ս��","1315441854","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("717","44","borrow_success","5020.00","5000.00","5020.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]�赽�Ŀ�","1315441854","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("718","44","margin","5020.00","500.00","4520.00","500.00","0.00","0","��������[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]�ı�֤��","1315441854","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("719","44","borrow_fee","4920.00","100.00","4420.00","500.00","0.00","0","���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]��������","1315441854","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("720","12","repayment","9490.35","8976.88","4792.44","4088.80","609.11","0","��[<a href=\'/invest/a28.html\' target=_blank>��л��վ�Ľ���  ��������������</a>]����","1315442653","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("721","12","borrow_frost","9490.35","888.80","5681.24","3200.00","609.11","0","��[<a href=\'/invest/a28.html\' target=_blank>��л��վ�Ľ���  ��������������</a>]���Ľⶳ","1315442653","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("722","27","invest_repayment","10479.38","5059.08","7059.08","2805.70","614.60","12","�ͻ���[<a href=\'/invest/a28.html\' target=_blank>��л��վ�Ľ���  ��������������</a>]���Ļ���","1315442653","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("723","27","tender_mange","10474.37","5.01","7054.07","2805.70","614.60","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315442653","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("724","46","invest_repayment","10043.79","3917.80","6538.79","3000.00","505.00","12","�ͻ���[<a href=\'/invest/a28.html\' target=_blank>��л��վ�Ľ���  ��������������</a>]���Ļ���","1315442653","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("725","46","tender_mange","10039.91","3.88","6534.91","3000.00","505.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315442653","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("726","12","tender","9490.35","5681.00","0.24","8881.00","609.11","4","Ͷ�궳���ʽ�","1315442921","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("727","6","tender","10106.13","500.00","2398.09","7000.00","708.04","39","Ͷ�궳���ʽ�","1315443026","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("728","45","recharge","10928.20","500.00","7423.20","3000.00","505.00","0","�˺ų�ֵ","1315443540","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("729","46","recharge","10539.91","500.00","7034.91","3000.00","505.00","0","�˺ų�ֵ","1315443550","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("730","27","recharge","10974.37","500.00","7554.07","2805.70","614.60","0","�˺ų�ֵ","1315443561","113.218.152.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("731","36","realname","-5.00","5.00","-5.00","0.00","0.00","0","ʵ����֤�۳�����","1315484544","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("732","34","recharge","34870.33","30000.00","30047.00","4320.00","503.33","0","�˺ų�ֵ","1315485094","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("733","6","invest_false","10106.13","2000.00","4398.09","5000.00","708.04","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("734","5","invest_false","10168.56","2000.00","5000.52","4460.00","708.04","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("735","27","invest_false","10974.37","2000.00","9554.07","805.70","614.60","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("736","46","invest_false","10539.91","2000.00","9034.91","1000.00","505.00","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("737","45","invest_false","10928.20","2000.00","9423.20","1000.00","505.00","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("738","34","invest_false","34870.33","2000.00","32047.00","2320.00","503.33","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("739","7","invest_false","10013.50","2000.00","7013.50","3000.00","0.00","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("740","11","invest_false","10086.57","2000.00","10086.57","0.00","0.00","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("741","43","invest_false","10122.50","2000.00","3277.50","6340.00","505.00","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("742","40","invest_false","10117.50","2000.00","6937.50","3180.00","0.00","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("743","42","invest_false","10117.50","2000.00","7017.50","3100.00","0.00","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("744","12","invest_false","9490.35","2000.00","2000.24","6881.00","609.11","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("745","12","invest_false","9490.35","5681.00","7681.24","1200.00","609.11","4","�б�[<a href=\'/invest/a24.html\' target=_blank>��վ��û������ ����С���</a>]ʧ�ܷ��ص�Ͷ���","1315486776","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("746","34","tender","34870.33","18888.00","13159.00","21208.00","503.33","4","Ͷ�궳���ʽ�","1315487115","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("747","34","tender","34870.33","1888.00","11271.00","23096.00","503.33","25","Ͷ�궳���ʽ�","1315487162","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("748","34","tender","34870.33","1888.00","9383.00","24984.00","503.33","38","Ͷ�궳���ʽ�","1315487222","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("749","34","tender","34870.33","1888.00","7495.00","26872.00","503.33","33","Ͷ�궳���ʽ�","1315487304","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("750","34","tender","34870.33","1888.00","5607.00","28760.00","503.33","20","Ͷ�궳���ʽ�","1315487339","113.218.53.251");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("751","27","tender","10974.37","9554.07","0.00","10359.77","614.60","4","Ͷ�궳���ʽ�","1315487676","183.209.141.81");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("752","46","tender","10539.91","9034.91","0.00","10034.91","505.00","4","Ͷ�궳���ʽ�","1315487735","183.209.141.81");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("753","45","tender","10928.20","9423.20","0.00","10423.20","505.00","4","Ͷ�궳���ʽ�","1315487776","183.209.141.81");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("754","4","recharge","7181.49","1.00","7181.49","0.00","0.00","0","���߳�ֵ","1315557736","61.152.88.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("755","4","fee","7181.48","0.01","7181.48","0.00","0.00","0","���߳�ֵ������","1315557736","61.152.88.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("756","4","recharge","7181.58","0.10","7181.58","0.00","0.00","0","���߳�ֵ","1315558253","61.152.88.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("757","4","fee","7181.58","0.00","7181.58","0.00","0.00","0","���߳�ֵ������","1315558253","61.152.88.27");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("758","6","tender","10106.13","4398.00","0.09","9398.00","708.04","4","Ͷ�궳���ʽ�","1315566865","113.218.177.229");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("759","12","tender","9490.35","48.36","7632.88","1248.36","609.11","50","Ͷ�궳���ʽ�","1315566951","113.218.177.229");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("760","12","tender","9490.35","7000.00","632.88","8248.36","609.11","4","Ͷ�궳���ʽ�","1315566974","113.218.177.229");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("761","12","tender","9490.35","632.00","0.88","8880.36","609.11","38","Ͷ�궳���ʽ�","1315566999","113.218.177.229");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("762","7","tender","10013.50","500.00","6513.50","3500.00","0.00","39","Ͷ�궳���ʽ�","1315610979","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("763","7","tender","10013.50","6513.00","0.50","10013.00","0.00","4","Ͷ�궳���ʽ�","1315611009","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("764","6","invest","9606.13","500.00","0.09","8898.00","708.04","50","Ͷ��ɹ����ÿ۳�","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("765","6","collection","10109.83","503.70","0.09","8898.00","1211.74","50","���ս��","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("766","5","invest","9668.56","500.00","5000.52","3960.00","708.04","50","Ͷ��ɹ����ÿ۳�","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("767","5","collection","10172.26","503.70","5000.52","3960.00","1211.74","50","���ս��","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("768","27","invest","10474.37","500.00","0.00","9859.77","614.60","50","Ͷ��ɹ����ÿ۳�","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("769","27","collection","10978.07","503.70","0.00","9859.77","1118.30","50","���ս��","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("770","46","invest","10039.91","500.00","0.00","9534.91","505.00","50","Ͷ��ɹ����ÿ۳�","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("771","46","collection","10543.61","503.70","0.00","9534.91","1008.70","50","���ս��","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("772","45","invest","10428.20","500.00","0.00","9923.20","505.00","50","Ͷ��ɹ����ÿ۳�","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("773","45","collection","10931.90","503.70","0.00","9923.20","1008.70","50","���ս��","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("774","14","invest","2017.49","500.00","507.90","499.59","1010.00","50","Ͷ��ɹ����ÿ۳�","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("775","14","collection","2521.19","503.70","507.90","499.59","1513.70","50","���ս��","1315611154","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("776","18","invest","1032.00","130.74","22.00","0.00","1010.00","50","Ͷ��ɹ����ÿ۳�","1315611155","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("777","18","collection","1163.71","131.71","22.00","0.00","1141.71","50","���ս��","1315611155","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("778","16","invest","1827.63","500.00","317.63","500.00","1010.00","50","Ͷ��ɹ����ÿ۳�","1315611156","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("779","16","collection","2331.33","503.70","317.63","500.00","1513.70","50","���ս��","1315611156","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("780","23","invest","538.63","500.00","33.63","0.00","505.00","50","Ͷ��ɹ����ÿ۳�","1315611156","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("781","23","collection","1042.33","503.70","33.63","0.00","1008.70","50","���ս��","1315611156","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("782","19","invest","1032.00","108.90","22.00","0.00","1010.00","50","Ͷ��ɹ����ÿ۳�","1315611157","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("783","19","collection","1141.71","109.71","22.00","0.00","1119.71","50","���ս��","1315611157","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("784","42","invest","10017.50","100.00","7017.50","3000.00","0.00","50","Ͷ��ɹ����ÿ۳�","1315611157","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("785","42","collection","10118.24","100.74","7017.50","3000.00","100.74","50","���ս��","1315611157","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("786","22","invest","554.56","500.00","0.00","159.16","395.40","50","Ͷ��ɹ����ÿ۳�","1315611157","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("787","22","collection","1058.26","503.70","0.00","159.16","899.10","50","���ս��","1315611157","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("788","12","invest","9441.99","48.36","0.88","8832.00","609.11","50","Ͷ��ɹ����ÿ۳�","1315611158","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("789","12","collection","9490.71","48.72","0.88","8832.00","657.83","50","���ս��","1315611158","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("790","50","borrow_success","4978.00","4888.00","4978.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]�赽�Ŀ�","1315611158","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("791","50","margin","4978.00","488.80","4489.20","488.80","0.00","0","��������[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]�ı�֤��","1315611158","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("792","50","borrow_fee","4880.24","97.76","4391.44","488.80","0.00","0","���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]��������","1315611158","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("793","34","invest","33870.33","1000.00","5607.00","27760.00","503.33","13","Ͷ��ɹ����ÿ۳�","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("794","34","collection","34935.45","1065.12","5607.00","27760.00","1568.45","13","���ս��","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("795","40","invest","8117.50","2000.00","6937.50","1180.00","0.00","13","Ͷ��ɹ����ÿ۳�","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("796","40","collection","10247.80","2130.30","6937.50","1180.00","2130.30","13","���ս��","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("797","43","invest","9322.50","800.00","3277.50","5540.00","505.00","13","Ͷ��ɹ����ÿ۳�","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("798","43","collection","10174.62","852.12","3277.50","5540.00","1357.12","13","���ս��","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("799","5","invest","9012.26","1160.00","5000.52","2800.00","1211.74","13","Ͷ��ɹ����ÿ۳�","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("800","5","collection","10247.84","1235.58","5000.52","2800.00","2447.32","13","���ս��","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("801","43","invest","5134.62","5040.00","3277.50","500.00","1357.12","13","Ͷ��ɹ����ÿ۳�","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("802","43","collection","10502.94","5368.32","3277.50","500.00","6725.44","13","���ս��","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("803","13","borrow_success","10360.00","10000.00","10360.00","0.00","0.00","0","ͨ��[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�赽�Ŀ�","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("804","13","margin","10360.00","1000.00","9360.00","1000.00","0.00","0","��������[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�ı�֤��","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("805","13","borrow_fee","10080.00","280.00","9080.00","1000.00","0.00","0","���[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]��������","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("806","34","award_add","34955.45","20.00","5627.00","27760.00","1568.45","13","���[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("807","13","award_lower","10060.00","20.00","9060.00","1000.00","0.00","34","�۳����[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("808","40","award_add","10287.80","40.00","6977.50","1180.00","2130.30","13","���[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("809","13","award_lower","10020.00","40.00","9020.00","1000.00","0.00","40","�۳����[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("810","43","award_add","10518.94","16.00","3293.50","500.00","6725.44","13","���[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("811","13","award_lower","10004.00","16.00","9004.00","1000.00","0.00","43","�۳����[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("812","5","award_add","10271.04","23.20","5023.72","2800.00","2447.32","13","���[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("813","13","award_lower","9980.80","23.20","8980.80","1000.00","0.00","5","�۳����[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("814","43","award_add","10619.74","100.80","3394.30","500.00","6725.44","13","���[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("815","13","award_lower","9880.00","100.80","8880.00","1000.00","0.00","43","�۳����[<a href=\'/invest/a15.html\' target=_blank>�����ʽ���ת ����2</a>]�Ľ���","1315611209","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("816","43","recharge","30619.74","20000.00","23394.30","500.00","6725.44","0","�˺ų�ֵ","1315611341","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("817","43","tender","30619.74","6612.00","16782.30","7112.00","6725.44","20","Ͷ�궳���ʽ�","1315611381","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("818","43","tender","30619.74","6782.00","10000.30","13894.00","6725.44","4","Ͷ�궳���ʽ�","1315611403","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("819","44","recharge","5920.00","1000.00","5420.00","500.00","0.00","0","�˺ų�ֵ","1315611582","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("820","49","recharge","5940.00","1000.00","5440.00","500.00","0.00","0","�˺ų�ֵ","1315611590","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("821","50","recharge","5880.24","1000.00","5391.44","488.80","0.00","0","�˺ų�ֵ","1315611598","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("822","44","repayment","870.00","5050.00","370.00","500.00","0.00","0","��[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]����","1315611657","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("823","44","borrow_frost","870.00","500.00","870.00","0.00","0.00","0","��[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ľⶳ","1315611657","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("824","43","invest_repayment","30619.74","505.00","10505.30","13894.00","6220.44","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611657","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("825","43","tender_mange","30619.24","0.50","10504.80","13894.00","6220.44","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611657","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("826","18","invest_repayment","1163.71","393.96","415.96","0.00","747.75","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611657","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("827","18","tender_mange","1163.32","0.39","415.57","0.00","747.75","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611657","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("828","19","invest_repayment","1141.71","505.00","527.00","0.00","614.71","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611657","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("829","19","tender_mange","1141.21","0.50","526.50","0.00","614.71","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611657","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("830","24","invest_repayment","1038.00","505.00","533.50","-0.50","505.00","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611658","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("831","24","tender_mange","1037.50","0.50","533.00","-0.50","505.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611658","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("832","26","invest_repayment","1038.00","505.00","533.50","-0.50","505.00","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611658","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("833","26","tender_mange","1037.50","0.50","533.00","-0.50","505.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611658","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("834","14","invest_repayment","2521.19","505.00","1012.90","499.59","1008.70","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("835","14","tender_mange","2520.69","0.50","1012.40","499.59","1008.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("836","46","invest_repayment","10543.61","505.00","505.00","9534.91","503.70","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("837","46","tender_mange","10543.11","0.50","504.50","9534.91","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("838","27","invest_repayment","10978.07","505.00","505.00","9859.77","613.30","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("839","27","tender_mange","10977.57","0.50","504.50","9859.77","613.30","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("840","45","invest_repayment","10931.90","505.00","505.00","9923.20","503.70","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("841","45","tender_mange","10931.40","0.50","504.50","9923.20","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("842","18","invest_repayment","1163.32","111.04","526.61","0.00","636.71","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("843","18","tender_mange","1163.21","0.11","526.50","0.00","636.71","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("844","16","invest_repayment","2331.33","505.00","822.63","500.00","1008.70","44","�ͻ���[<a href=\'/invest/a21.html\' target=_blank>�뻹 ��һ�������ƽ̨ ������վʵ�� </a>]���Ļ���","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("845","16","tender_mange","2330.83","0.50","822.13","500.00","1008.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315611659","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("846","49","repayment","890.00","5050.00","390.00","500.00","0.00","0","��[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]����","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("847","49","borrow_frost","890.00","500.00","890.00","0.00","0.00","0","��[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ľⶳ","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("848","6","invest_repayment","10109.83","505.00","505.09","8898.00","706.74","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("849","6","tender_mange","10109.33","0.50","504.59","8898.00","706.74","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("850","5","invest_repayment","10271.04","505.00","5528.72","2800.00","1942.32","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("851","5","tender_mange","10270.54","0.50","5528.22","2800.00","1942.32","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("852","14","invest_repayment","2520.69","505.00","1517.40","499.59","503.70","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("853","14","tender_mange","2520.19","0.50","1516.90","499.59","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("854","18","invest_repayment","1163.21","505.00","1031.50","0.00","131.71","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("855","18","tender_mange","1162.71","0.50","1031.00","0.00","131.71","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612283","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("856","16","invest_repayment","2330.83","505.00","1327.13","500.00","503.70","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612284","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("857","16","tender_mange","2330.33","0.50","1326.63","500.00","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612284","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("858","23","invest_repayment","1042.33","505.00","538.63","0.00","503.70","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612284","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("859","23","tender_mange","1041.83","0.50","538.13","0.00","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612284","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("860","24","invest_repayment","1037.50","505.00","1038.00","-0.50","0.00","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612284","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("861","24","tender_mange","1037.00","0.50","1037.50","-0.50","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612284","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("862","26","invest_repayment","1037.50","505.00","1038.00","-0.50","0.00","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612285","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("863","26","tender_mange","1037.00","0.50","1037.50","-0.50","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612285","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("864","22","invest_repayment","1058.26","395.40","395.40","159.16","503.70","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612285","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("865","22","tender_mange","1057.87","0.39","395.01","159.16","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612285","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("866","19","invest_repayment","1141.21","505.00","1031.50","0.00","109.71","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612285","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("867","19","tender_mange","1140.71","0.50","1031.00","0.00","109.71","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612285","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("868","27","invest_repayment","10977.57","109.60","614.10","9859.77","503.70","49","�ͻ���[<a href=\'/invest/a23.html\' target=_blank>¶����  ����</a>]���Ļ���","1315612286","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("869","27","tender_mange","10977.46","0.11","613.99","9859.77","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315612286","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("870","49","video","880.00","10.00","880.00","0.00","0.00","0","��Ƶ��֤�۳�����","1315612513","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("871","5","tender","10270.54","500.00","5028.22","3300.00","1942.32","39","Ͷ�궳���ʽ�","1315612845","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("872","5","tender","10270.54","5028.00","0.22","8328.00","1942.32","4","Ͷ�궳���ʽ�","1315612864","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("873","11","tender","10086.57","34.64","10051.93","34.64","0.00","39","Ͷ�궳���ʽ�","1315612954","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("874","11","tender","10086.57","530.00","9521.93","564.64","0.00","25","Ͷ�궳���ʽ�","1315612975","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("875","11","tender","10086.57","300.00","9221.93","864.64","0.00","33","Ͷ�궳���ʽ�","1315612999","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("876","12","recharge","59490.71","50000.00","50000.88","8832.00","657.83","0","�˺ų�ֵ","1315613149","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("877","7","recharge","60013.50","50000.00","50000.50","10013.00","0.00","0","�˺ų�ֵ","1315613157","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("878","11","recharge","40086.57","30000.00","39221.93","864.64","0.00","0","�˺ų�ֵ","1315613269","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("879","41","tender","10117.50","2117.00","8000.50","2117.00","0.00","4","Ͷ�궳���ʽ�","1315613349","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("880","28","recharge","615.64","100.00","565.64","50.00","0.00","0","�˺ų�ֵ","1315613426","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("881","41","tender","10117.50","8000.00","0.50","10117.00","0.00","49","Ͷ�궳���ʽ�","1315613545","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("882","12","tender","59490.71","30000.00","20000.88","38832.00","657.83","13","Ͷ�궳���ʽ�","1315613598","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("883","46","invest","10043.11","500.00","504.50","9034.91","503.70","39","Ͷ��ɹ����ÿ۳�","1315614183","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("884","46","collection","10546.81","503.70","504.50","9034.91","1007.40","39","���ս��","1315614183","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("885","45","invest","10431.40","500.00","504.50","9423.20","503.70","39","Ͷ��ɹ����ÿ۳�","1315614183","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("886","45","collection","10935.10","503.70","504.50","9423.20","1007.40","39","���ս��","1315614183","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("887","14","invest","2020.19","500.00","1516.90","-0.41","503.70","39","Ͷ��ɹ����ÿ۳�","1315614183","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("888","14","collection","2523.89","503.70","1516.90","-0.41","1007.40","39","���ս��","1315614183","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("889","34","invest","34455.45","500.00","5627.00","27260.00","1568.45","39","Ͷ��ɹ����ÿ۳�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("890","34","collection","34959.15","503.70","5627.00","27260.00","2072.15","39","���ս��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("891","43","invest","30119.24","500.00","10504.80","13394.00","6220.44","39","Ͷ��ɹ����ÿ۳�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("892","43","collection","30622.94","503.70","10504.80","13394.00","6724.14","39","���ս��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("893","27","invest","10671.76","305.70","613.99","9554.07","503.70","39","Ͷ��ɹ����ÿ۳�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("894","27","collection","10979.72","307.96","613.99","9554.07","811.66","39","���ս��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("895","22","invest","898.21","159.66","395.01","-0.50","503.70","39","Ͷ��ɹ����ÿ۳�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("896","22","collection","1059.05","160.84","395.01","-0.50","664.54","39","���ս��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("897","16","invest","1830.33","500.00","1326.63","0.00","503.70","39","Ͷ��ɹ����ÿ۳�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("898","16","collection","2334.03","503.70","1326.63","0.00","1007.40","39","���ս��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("899","6","invest","9609.33","500.00","504.59","8398.00","706.74","39","Ͷ��ɹ����ÿ۳�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("900","6","collection","10113.03","503.70","504.59","8398.00","1210.44","39","���ս��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("901","7","invest","59513.50","500.00","50000.50","9513.00","0.00","39","Ͷ��ɹ����ÿ۳�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("902","7","collection","60017.20","503.70","50000.50","9513.00","503.70","39","���ս��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("903","5","invest","9770.54","500.00","0.22","7828.00","1942.32","39","Ͷ��ɹ����ÿ۳�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("904","5","collection","10274.24","503.70","0.22","7828.00","2446.02","39","���ս��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("905","11","invest","40051.93","34.64","39221.93","830.00","0.00","39","Ͷ��ɹ����ÿ۳�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("906","11","collection","40086.83","34.90","39221.93","830.00","34.90","39","���ս��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("907","39","borrow_success","5353.36","5000.00","5353.36","0.00","0.00","0","ͨ��[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]�赽�Ŀ�","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("908","39","margin","5353.36","500.00","4853.36","500.00","0.00","0","��������[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]�ı�֤��","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("909","39","borrow_fee","5253.36","100.00","4753.36","500.00","0.00","0","���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]��������","1315614184","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("910","50","repayment","956.07","4924.17","467.27","488.80","0.00","0","��[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]����","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("911","50","borrow_frost","956.07","488.80","956.07","0.00","0.00","0","��[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ľⶳ","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("912","6","invest_repayment","10113.03","503.70","1008.29","8398.00","706.74","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("913","6","tender_mange","10112.66","0.37","1007.92","8398.00","706.74","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("914","5","invest_repayment","10274.24","503.70","503.92","7828.00","1942.32","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("915","5","tender_mange","10273.87","0.37","503.55","7828.00","1942.32","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("916","27","invest_repayment","10979.72","503.70","1117.69","9554.07","307.96","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("917","27","tender_mange","10979.35","0.37","1117.32","9554.07","307.96","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("918","46","invest_repayment","10546.81","503.70","1008.20","9034.91","503.70","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("919","46","tender_mange","10546.44","0.37","1007.83","9034.91","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("920","45","invest_repayment","10935.10","503.70","1008.20","9423.20","503.70","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("921","45","tender_mange","10934.73","0.37","1007.83","9423.20","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("922","14","invest_repayment","2523.89","503.70","2020.60","-0.41","503.70","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("923","14","tender_mange","2523.52","0.37","2020.23","-0.41","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614386","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("924","18","invest_repayment","1162.71","131.71","1162.71","0.00","0.00","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614387","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("925","18","tender_mange","1162.61","0.10","1162.61","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614387","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("926","16","invest_repayment","2334.03","503.70","1830.33","0.00","503.70","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614387","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("927","16","tender_mange","2333.66","0.37","1829.96","0.00","503.70","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614387","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("928","23","invest_repayment","1041.83","503.70","1041.83","0.00","0.00","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614387","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("929","23","tender_mange","1041.46","0.37","1041.46","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614387","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("930","19","invest_repayment","1140.71","109.71","1140.71","0.00","0.00","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614388","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("931","19","tender_mange","1140.63","0.08","1140.63","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614388","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("932","42","invest_repayment","10118.24","100.74","7118.24","3000.00","0.00","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614388","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("933","42","tender_mange","10118.17","0.07","7118.17","3000.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614388","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("934","22","invest_repayment","1059.05","503.70","898.71","-0.50","160.84","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614388","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("935","22","tender_mange","1058.68","0.37","898.34","-0.50","160.84","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614388","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("936","12","invest_repayment","59490.71","48.72","20049.60","38832.00","609.11","50","�ͻ���[<a href=\'/invest/a25.html\' target=_blank>������ ���� Ը��վ����������</a>]���Ļ���","1315614389","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("937","12","tender_mange","59490.67","0.04","20049.56","38832.00","609.11","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315614389","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("938","28","repayment","112.31","503.33","62.31","50.00","0.00","0","��[<a href=\'/invest/a26.html\' target=_blank>������</a>]����","1315616966","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("939","28","borrow_frost","112.31","50.00","112.31","0.00","0.00","0","��[<a href=\'/invest/a26.html\' target=_blank>������</a>]���Ľⶳ","1315616967","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("940","34","invest_repayment","34959.15","503.33","6130.33","27260.00","1568.82","28","�ͻ���[<a href=\'/invest/a26.html\' target=_blank>������</a>]���Ļ���","1315616967","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("941","34","tender_mange","34958.82","0.33","6130.00","27260.00","1568.82","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315616967","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("942","28","account_other","-67.69","180.00","-67.69","0.00","0.00","0","��Ա��","1315620469","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("943","34","tender","34958.82","3000.00","3130.00","30260.00","1568.82","28","Ͷ�궳���ʽ�","1315620827","113.218.120.128");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("944","22","tender","1058.68","898.34","0.00","897.84","160.84","4","Ͷ�궳���ʽ�","1315621481","113.65.186.11");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("945","14","tender","2523.52","2020.23","0.00","2019.82","503.70","4","Ͷ�궳���ʽ�","1315621533","113.65.186.11");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("946","18","tender","1162.61","1162.61","0.00","1162.61","0.00","4","Ͷ�궳���ʽ�","1315621576","113.65.186.11");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("947","16","tender","2333.66","1829.96","0.00","1829.96","503.70","4","Ͷ�궳���ʽ�","1315621606","113.65.186.11");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("948","23","tender","1041.46","1041.46","0.00","1041.46","0.00","4","Ͷ�궳���ʽ�","1315621632","113.65.186.11");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("949","19","tender","1140.63","1140.63","0.00","1140.63","0.00","4","Ͷ�궳���ʽ�","1315621660","113.65.186.179");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("950","24","tender","1037.00","1037.50","0.00","1037.00","0.00","4","Ͷ�궳���ʽ�","1315621683","113.65.186.179");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("951","26","tender","1037.00","1019.09","18.41","1018.59","0.00","4","Ͷ�궳���ʽ�","1315621761","113.65.186.179");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("952","34","invest","31958.82","3000.00","3130.00","27260.00","1568.82","28","Ͷ��ɹ����ÿ۳�","1315627021","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("953","34","collection","35019.03","3060.21","3130.00","27260.00","4629.03","28","���ս��","1315627021","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("954","28","borrow_success","2932.31","3000.00","2932.31","0.00","0.00","0","ͨ��[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]�赽�Ŀ�","1315627021","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("955","28","margin","2932.31","300.00","2632.31","300.00","0.00","0","��������[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]�ı�֤��","1315627021","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("956","28","borrow_fee","2866.31","66.00","2566.31","300.00","0.00","0","���[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]��������","1315627021","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("957","34","award_add","35049.03","30.00","3160.00","27260.00","4629.03","28","���[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]�Ľ���","1315627021","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("958","28","award_lower","2836.31","30.00","2536.31","300.00","0.00","34","�۳����[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]�Ľ���","1315627021","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("959","28","repayment","1816.24","1020.07","1516.24","300.00","0.00","0","��[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]����","1315627325","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("960","34","invest_repayment","35049.03","1020.07","4180.07","27260.00","3608.96","28","�ͻ���[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]���Ļ���","1315627325","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("961","34","tender_mange","35046.03","3.00","4177.07","27260.00","3608.96","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315627325","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("962","28","repayment","796.17","1020.07","496.17","300.00","0.00","0","��[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]����","1315627345","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("963","34","invest_repayment","35046.03","1020.07","5197.14","27260.00","2588.89","28","�ͻ���[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]���Ļ���","1315627345","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("964","34","tender_mange","35044.02","2.01","5195.13","27260.00","2588.89","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315627345","123.87.177.3");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("965","11","tender","40086.83","2000.00","37221.93","2830.00","34.90","44","Ͷ�궳���ʽ�","1315629338","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("966","11","tender","40086.83","2000.00","35221.93","4830.00","34.90","50","Ͷ�궳���ʽ�","1315629358","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("967","11","tender","40086.83","35221.00","0.93","40051.00","34.90","13","Ͷ�궳���ʽ�","1315629384","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("968","34","invest","16156.02","18888.00","5195.13","8372.00","2588.89","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("969","34","collection","35441.30","19285.28","5195.13","8372.00","21874.17","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("970","27","invest","1425.28","9554.07","1117.32","0.00","307.96","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("971","27","collection","11180.30","9755.02","1117.32","0.00","10062.98","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("972","46","invest","1511.53","9034.91","1007.83","0.00","503.70","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("973","46","collection","10736.47","9224.94","1007.83","0.00","9728.64","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("974","45","invest","1511.53","9423.20","1007.83","0.00","503.70","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("975","45","collection","11132.93","9621.40","1007.83","0.00","10125.10","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("976","6","invest","5714.66","4398.00","1007.92","4000.00","706.74","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("977","6","collection","10205.16","4490.50","1007.92","4000.00","5197.24","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("978","12","invest","52490.67","7000.00","20049.56","31832.00","609.11","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("979","12","collection","59637.90","7147.23","20049.56","31832.00","7756.34","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("980","7","invest","53504.20","6513.00","50000.50","3000.00","503.70","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("981","7","collection","60154.19","6649.99","50000.50","3000.00","7153.69","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("982","43","invest","23840.94","6782.00","10504.80","6612.00","6724.14","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("983","43","collection","30765.59","6924.65","10504.80","6612.00","13648.79","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("984","5","invest","5245.87","5028.00","503.55","2800.00","1942.32","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("985","5","collection","10379.63","5133.76","503.55","2800.00","7076.08","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("986","41","invest","8000.50","2117.00","0.50","8000.00","0.00","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("987","41","collection","10162.03","2161.53","0.50","8000.00","2161.53","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("988","22","invest","160.34","898.34","0.00","-0.50","160.84","4","Ͷ��ɹ����ÿ۳�","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("989","22","collection","1077.58","917.24","0.00","-0.50","1078.08","4","���ս��","1315629496","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("990","14","invest","503.29","2020.23","0.00","-0.41","503.70","4","Ͷ��ɹ����ÿ۳�","1315629497","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("991","14","collection","2566.01","2062.72","0.00","-0.41","2566.42","4","���ս��","1315629497","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("992","18","invest","0.00","1162.61","0.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1315629497","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("993","18","collection","1187.06","1187.06","0.00","0.00","1187.06","4","���ս��","1315629497","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("994","16","invest","503.70","1829.96","0.00","0.00","503.70","4","Ͷ��ɹ����ÿ۳�","1315629498","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("995","16","collection","2372.15","1868.45","0.00","0.00","2372.15","4","���ս��","1315629498","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("996","23","invest","0.00","1041.46","0.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1315629498","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("997","23","collection","1063.37","1063.37","0.00","0.00","1063.37","4","���ս��","1315629498","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("998","19","invest","0.00","1140.63","0.00","0.00","0.00","4","Ͷ��ɹ����ÿ۳�","1315629499","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("999","19","collection","1164.62","1164.62","0.00","0.00","1164.62","4","���ս��","1315629499","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1000","24","invest","-0.50","1037.50","0.00","-0.50","0.00","4","Ͷ��ɹ����ÿ۳�","1315629499","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1001","24","collection","1058.82","1059.32","0.00","-0.50","1059.32","4","���ս��","1315629499","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1002","26","invest","17.91","1019.09","18.41","-0.50","0.00","4","Ͷ��ɹ����ÿ۳�","1315629499","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1003","26","collection","1058.43","1040.52","18.41","-0.50","1040.52","4","���ս��","1315629499","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1004","4","borrow_success","96069.58","88888.00","96069.58","0.00","0.00","0","ͨ��[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]�赽�Ŀ�","1315629500","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1005","4","margin","96069.58","8888.80","87180.78","8888.80","0.00","0","��������[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]�ı�֤��","1315629500","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1006","4","borrow_fee","94291.82","1777.76","85403.02","8888.80","0.00","0","���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]��������","1315629500","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1007","34","tender","35441.30","4000.00","1195.13","12372.00","21874.17","28","Ͷ�궳���ʽ�","1315629646","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1008","34","tender","35441.30","470.00","725.13","12842.00","21874.17","25","Ͷ�궳���ʽ�","1315629678","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1009","34","tender","35441.30","725.13","0.00","13567.13","21874.17","44","Ͷ�궳���ʽ�","1315629734","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1010","4","recharge","194291.82","100000.00","185403.02","8888.80","0.00","0","�˺ų�ֵ","1315630019","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1011","4","tender","194291.82","24779.00","160624.02","33667.80","0.00","13","Ͷ�궳���ʽ�","1315630514","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1012","53","realname","-5.00","5.00","-5.00","0.00","0.00","0","ʵ����֤�۳�����","1315630983","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1013","13","video","9870.00","10.00","8870.00","1000.00","0.00","0","��Ƶ��֤�۳�����","1315631150","113.218.36.55");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1014","39","recharge","5553.36","300.00","5053.36","500.00","0.00","0","�˺ų�ֵ","1315651432","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1015","12","invest","29637.90","30000.00","20049.56","1832.00","7756.34","13","Ͷ��ɹ����ÿ۳�","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1016","12","collection","60162.90","30525.00","20049.56","1832.00","38281.34","13","���ս��","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1017","11","invest","4865.83","35221.00","0.93","4830.00","34.90","13","Ͷ��ɹ����ÿ۳�","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1018","11","collection","40703.20","35837.37","0.93","4830.00","35872.27","13","���ս��","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1019","4","invest","169512.82","24779.00","160624.02","8888.80","0.00","13","Ͷ��ɹ����ÿ۳�","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1020","4","collection","194725.45","25212.63","160624.02","8888.80","25212.63","13","���ս��","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1021","13","borrow_success","99870.00","90000.00","98870.00","1000.00","0.00","0","ͨ��[<a href=\'/invest/a34.html\' target=_blank>��Ͷ����Լ��</a>]�赽�Ŀ�","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1022","13","margin","99870.00","9000.00","89870.00","10000.00","0.00","0","��������[<a href=\'/invest/a34.html\' target=_blank>��Ͷ����Լ��</a>]�ı�֤��","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1023","13","borrow_fee","98070.00","1800.00","88070.00","10000.00","0.00","0","���[<a href=\'/invest/a34.html\' target=_blank>��Ͷ����Լ��</a>]��������","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1024","12","award_add","61062.90","900.00","20949.56","1832.00","38281.34","13","���[<a href=\'/invest/a34.html\' target=_blank>��Ͷ����Լ��</a>]�Ľ���","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1025","13","award_lower","97170.00","900.00","87170.00","10000.00","0.00","12","�۳����[<a href=\'/invest/a34.html\' target=_blank>��Ͷ����Լ��</a>]�Ľ���","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1026","11","award_add","41759.83","1056.63","1057.56","4830.00","35872.27","13","���[<a href=\'/invest/a34.html\' target=_blank>��Ͷ����Լ��</a>]�Ľ���","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1027","13","award_lower","96113.37","1056.63","86113.37","10000.00","0.00","11","�۳����[<a href=\'/invest/a34.html\' target=_blank>��Ͷ����Լ��</a>]�Ľ���","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1028","4","award_add","195468.82","743.37","161367.39","8888.80","25212.63","13","���[<a href=\'/invest/a34.html\' target=_blank>��Ͷ����Լ��</a>]�Ľ���","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1029","13","award_lower","95370.00","743.37","85370.00","10000.00","0.00","4","�۳����[<a href=\'/invest/a34.html\' target=_blank>��Ͷ����Լ��</a>]�Ľ���","1315651473","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1030","39","repayment","516.32","5037.04","16.32","500.00","0.00","0","��[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]����","1315651533","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1031","39","borrow_frost","516.32","500.00","516.32","0.00","0.00","0","��[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ľⶳ","1315651533","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1032","46","invest_repayment","10736.47","503.70","1511.53","0.00","9224.94","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651533","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1033","46","tender_mange","10736.10","0.37","1511.16","0.00","9224.94","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651533","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1034","45","invest_repayment","11132.93","503.70","1511.53","0.00","9621.40","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651533","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1035","45","tender_mange","11132.56","0.37","1511.16","0.00","9621.40","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651533","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1036","14","invest_repayment","2566.01","503.70","503.70","-0.41","2062.72","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651534","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1037","14","tender_mange","2565.64","0.37","503.33","-0.41","2062.72","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651534","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1038","34","invest_repayment","35441.30","503.70","503.70","13567.13","21370.47","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1039","34","tender_mange","35440.93","0.37","503.33","13567.13","21370.47","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1040","43","invest_repayment","30765.59","503.70","11008.50","6612.00","13145.09","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1041","43","tender_mange","30765.22","0.37","11008.13","6612.00","13145.09","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1042","27","invest_repayment","11180.30","307.96","1425.28","0.00","9755.02","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1043","27","tender_mange","11180.07","0.23","1425.05","0.00","9755.02","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1044","22","invest_repayment","1077.58","160.84","160.84","-0.50","917.24","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1045","22","tender_mange","1077.46","0.12","160.72","-0.50","917.24","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1046","16","invest_repayment","2372.15","503.70","503.70","0.00","1868.45","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1047","16","tender_mange","2371.78","0.37","503.33","0.00","1868.45","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1048","6","invest_repayment","10205.16","503.70","1511.62","4000.00","4693.54","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1049","6","tender_mange","10204.79","0.37","1511.25","4000.00","4693.54","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1050","7","invest_repayment","60154.19","503.70","50504.20","3000.00","6649.99","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1051","7","tender_mange","60153.82","0.37","50503.83","3000.00","6649.99","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1052","5","invest_repayment","10379.63","503.70","1007.25","2800.00","6572.38","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1053","5","tender_mange","10379.26","0.37","1006.88","2800.00","6572.38","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1054","11","invest_repayment","41759.83","34.90","1092.46","4830.00","35837.37","39","�ͻ���[<a href=\'/invest/a27.html\' target=_blank>Ϊ������׼��  лл֧�� ͨ������</a>]���Ļ���","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1055","11","tender_mange","41759.80","0.03","1092.43","4830.00","35837.37","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315651535","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1056","7","tender","60153.82","42000.00","8503.83","45000.00","6649.99","49","Ͷ�궳���ʽ�","1315651735","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1057","25","cash_frost","814.75","700.00","14.75","800.00","0.00","0","�û���������","1315652488","124.114.177.90");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1058","4","repayment","104711.21","90757.61","70609.78","8888.80","25212.63","0","��[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1059","4","borrow_frost","104711.21","8888.80","79498.58","0.00","25212.63","0","��[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ľⶳ","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1060","34","invest_repayment","35440.93","19285.28","19788.61","13567.13","2085.19","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1061","34","tender_mange","35401.20","39.73","19748.88","13567.13","2085.19","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1062","27","invest_repayment","11180.07","9755.02","11180.07","0.00","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1063","27","tender_mange","11159.98","20.10","11159.98","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1064","46","invest_repayment","10736.10","9224.94","10736.10","0.00","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1065","46","tender_mange","10717.10","19.00","10717.10","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1066","45","invest_repayment","11132.56","9621.40","11132.56","0.00","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1067","45","tender_mange","11112.74","19.82","11112.74","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1068","6","invest_repayment","10204.79","4490.50","6001.75","4000.00","203.04","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1069","6","tender_mange","10195.54","9.25","5992.50","4000.00","203.04","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1070","12","invest_repayment","61062.90","7147.23","28096.79","1832.00","31134.11","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1071","12","tender_mange","61048.18","14.72","28082.07","1832.00","31134.11","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1072","7","invest_repayment","60153.82","6649.99","15153.82","45000.00","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1073","7","tender_mange","60140.12","13.70","15140.12","45000.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1074","43","invest_repayment","30765.22","6924.65","17932.78","6612.00","6220.44","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1075","43","tender_mange","30750.96","14.27","17918.52","6612.00","6220.44","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1076","5","invest_repayment","10379.26","5133.76","6140.64","2800.00","1438.62","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1077","5","tender_mange","10368.68","10.58","6130.06","2800.00","1438.62","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1078","41","invest_repayment","10162.03","2161.53","2162.03","8000.00","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1079","41","tender_mange","10157.58","4.45","2157.58","8000.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1080","22","invest_repayment","1077.46","917.24","1077.96","-0.50","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1081","22","tender_mange","1075.57","1.89","1076.07","-0.50","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657360","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1082","14","invest_repayment","2565.64","2062.72","2566.05","-0.41","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657361","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1083","14","tender_mange","2561.39","4.25","2561.80","-0.41","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657361","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1084","18","invest_repayment","1187.06","1187.06","1187.06","0.00","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657361","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1085","18","tender_mange","1184.62","2.45","1184.62","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657361","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1086","16","invest_repayment","2371.78","1868.45","2371.78","0.00","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657362","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1087","16","tender_mange","2367.93","3.85","2367.93","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657362","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1088","23","invest_repayment","1063.37","1063.37","1063.37","0.00","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657362","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1089","23","tender_mange","1061.18","2.19","1061.18","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657362","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1090","19","invest_repayment","1164.62","1164.62","1164.62","0.00","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657363","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1091","19","tender_mange","1162.22","2.40","1162.22","0.00","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657363","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1092","24","invest_repayment","1058.82","1059.32","1059.32","-0.50","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657363","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1093","24","tender_mange","1056.64","2.18","1057.14","-0.50","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657363","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1094","26","invest_repayment","1058.43","1040.52","1058.93","-0.50","0.00","4","�ͻ���[<a href=\'/invest/a32.html\' target=_blank>�ֲ���վʧ�� Ͷ����ʧ ��</a>]���Ļ���","1315657364","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1095","26","tender_mange","1056.29","2.14","1056.79","-0.50","0.00","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315657364","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1096","12","tender","61048.18","6000.00","22082.07","7832.00","31134.11","50","Ͷ�궳���ʽ�","1315657806","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1097","46","recharge","11022.80","305.70","11022.80","0.00","0.00","0","�˺ų�ֵ","1315660480","113.218.125.86");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1098","43","recharge","60750.96","30000.00","47918.52","6612.00","6220.44","0","�˺ų�ֵ","1315700506","113.218.92.0");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1099","40","recharge","40287.80","30000.00","36977.50","1180.00","2130.30","0","�˺ų�ֵ","1315700525","113.218.92.0");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1100","45","recharge","11217.60","104.86","11217.60","0.00","0.00","0","�˺ų�ֵ","1315702035","113.218.154.44");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1101","46","recharge","11058.22","35.42","11058.22","0.00","0.00","0","�˺ų�ֵ","1315702049","113.218.154.44");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1102","27","recharge","11214.81","54.83","11214.81","0.00","0.00","0","�˺ų�ֵ","1315702087","113.218.154.44");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1103","43","tender","60750.96","30000.00","17918.52","36612.00","6220.44","4","Ͷ�궳���ʽ�","1315702233","113.218.154.44");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1104","28","recharge","1346.17","550.00","1046.17","300.00","0.00","0","�˺ų�ֵ","1315703399","113.218.154.44");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1105","28","repayment","326.10","1020.07","26.10","300.00","0.00","0","��[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]����","1315703618","123.87.178.188");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1106","28","borrow_frost","326.10","300.00","326.10","0.00","0.00","0","��[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]���Ľⶳ","1315703618","123.87.178.188");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1107","34","invest_repayment","35401.20","1020.07","20768.95","13567.13","1065.12","28","�ͻ���[<a href=\'/invest/a37.html\' target=_blank>Ϊ������ȣ����뻹</a>]���Ļ���","1315703618","123.87.178.188");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1108","34","tender_mange","35400.19","1.01","20767.94","13567.13","1065.12","0","�û��ɹ�����۳���Ϣ�Ĺ�����","1315703618","123.87.178.188");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1109","6","tender","10195.54","5992.00","0.50","9992.00","203.04","4","Ͷ�궳���ʽ�","1315707388","113.218.74.188");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1110","27","cash_frost","11214.81","11214.81","0.00","11214.81","0.00","0","�û���������","1315709576","183.209.42.217");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1111","26","cash_frost","1056.29","1056.79","0.00","1056.29","0.00","0","�û���������","1315709705","113.65.153.25");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1112","12","tender","61048.18","22082.00","0.07","29914.00","31134.11","4","Ͷ�궳���ʽ�","1315710641","113.218.44.254");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1113","24","cash_frost","1056.64","1057.14","0.00","1056.64","0.00","0","�û���������","1315710712","113.65.173.135");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1114","19","cash_frost","1162.22","1162.22","0.00","1162.22","0.00","0","�û���������","1315710760","113.65.154.216");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1115","23","cash_frost","1061.18","1061.18","0.00","1061.18","0.00","0","�û���������","1315710806","113.65.185.77");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1116","41","tender","10157.58","2157.00","0.58","10157.00","0.00","4","Ͷ�궳���ʽ�","1315710905","113.218.44.254");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1117","16","cash_frost","2367.93","2367.93","0.00","2367.93","0.00","0","�û���������","1315710952","113.65.185.133");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1118","27","cash_cancel","11214.81","11215.00","11215.00","-0.19","0.00","0","ȡ�����ֽⶳ","1315714534","183.209.42.217");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1119","5","recharge","60368.68","50000.00","56130.06","2800.00","1438.62","0","�˺ų�ֵ","1315714625","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1120","5","fee","60318.68","50.00","56080.06","2800.00","1438.62","0","��ֵ�����ѿ۳�","1315714625","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1121","5","tender","60318.68","56080.00","0.06","58880.00","1438.62","4","Ͷ�궳���ʽ�","1315714818","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1122","34","tender","35400.19","20767.94","0.00","34335.07","1065.12","4","Ͷ�궳���ʽ�","1315714948","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1123","13","cash_frost","95370.00","44980.00","40390.00","54980.00","0.00","0","�û���������","1315715718","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1124","13","recharge_success","50390.00","44980.00","40390.00","10000.00","0.00","0","���ֳɹ�","1315715794","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1125","46","cash_frost","11058.22","11058.22","0.00","11058.22","0.00","0","�û���������","1315715839","183.209.42.217");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1126","13","tender","50390.00","40390.00","0.00","50390.00","0.00","4","Ͷ�궳���ʽ�","1315715851","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1127","45","cash_frost","11217.60","11217.60","0.00","11217.60","0.00","0","�û���������","1315715956","183.209.42.217");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1128","46","recharge_success","0.22","11058.00","0.00","0.22","0.00","0","���ֳɹ�","1315716014","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1129","45","recharge_success","-0.40","11218.00","0.00","-0.40","0.00","0","���ֳɹ�","1315716089","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1130","27","recharge","33490.81","22276.00","33491.00","-0.19","0.00","0","�˺ų�ֵ","1315716161","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1131","11","recharge","61759.80","20000.00","21092.43","4830.00","35837.37","0","�˺ų�ֵ","1315716661","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1132","11","fee","61709.80","50.00","21042.43","4830.00","35837.37","0","��ֵ�����ѿ۳�","1315716661","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1133","11","tender","61709.80","21042.00","0.43","25872.00","35837.37","4","Ͷ�궳���ʽ�","1315716699","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1134","30","recharge","10050.00","10050.00","10050.00","0.00","0.00","0","�˺ų�ֵ","1315716820","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1135","30","fee","10000.00","50.00","10000.00","0.00","0.00","0","��ֵ�����ѿ۳�","1315716820","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1136","30","tender","10000.00","10000.00","0.00","10000.00","0.00","4","Ͷ�궳���ʽ�","1315716998","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1137","55","recharge","20050.00","20050.00","20050.00","0.00","0.00","0","�˺ų�ֵ","1315717867","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1138","55","fee","20000.00","50.00","20000.00","0.00","0.00","0","��ֵ�����ѿ۳�","1315717867","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1139","55","tender","20000.00","20000.00","0.00","20000.00","0.00","4","Ͷ�궳���ʽ�","1315717945","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1140","40","tender","40287.80","36977.00","0.50","38157.00","2130.30","4","Ͷ�궳���ʽ�","1315726146","113.218.4.79");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1141","42","tender","10118.17","7118.00","0.17","10118.00","0.00","4","Ͷ�궳���ʽ�","1315785182","113.218.95.63");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1142","7","tender","60140.12","15140.00","0.12","60140.00","0.00","4","Ͷ�궳���ʽ�","1315785326","113.218.95.63");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1143","57","recharge","50000.00","50000.00","50000.00","0.00","0.00","0","�˺ų�ֵ","1315823257","113.218.198.239");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1144","57","fee","49950.00","50.00","49950.00","0.00","0.00","0","��ֵ�����ѿ۳�","1315823257","113.218.198.239");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1145","57","tender","49950.00","40000.00","9950.00","40000.00","0.00","4","Ͷ�궳���ʽ�","1315823358","113.218.198.239");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1146","57","tender","49950.00","1368.00","8582.00","41368.00","0.00","38","Ͷ�궳���ʽ�","1315823387","113.218.198.239");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1147","57","tender","49950.00","1312.00","7270.00","42680.00","0.00","33","Ͷ�궳���ʽ�","1315823428","113.218.198.239");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1148","58","recharge","50000.00","50000.00","50000.00","0.00","0.00","0","�˺ų�ֵ","1315823751","113.218.198.239");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1149","58","tender","50000.00","50000.00","0.00","50000.00","0.00","4","Ͷ�궳���ʽ�","1315823831","113.218.198.239");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1150","27","cash_frost","33490.81","33491.00","0.00","33490.81","0.00","0","�û���������","1315876658","180.111.28.225");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1151","22","tender","1075.57","1076.07","0.00","1075.57","0.00","4","Ͷ�궳���ʽ�","1315936171","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1152","14","tender","2561.39","2561.80","0.00","2561.39","0.00","4","Ͷ�궳���ʽ�","1315936200","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1153","18","tender","1184.62","1184.62","0.00","1184.62","0.00","4","Ͷ�궳���ʽ�","1315936252","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1154","16","cash_cancel","2367.93","2368.00","2368.00","-0.07","0.00","0","ȡ�����ֽⶳ","1315936322","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1155","16","tender","2367.93","2368.00","0.00","2367.93","0.00","4","Ͷ�궳���ʽ�","1315936337","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1156","24","cash_cancel","1056.64","1057.00","1057.00","-0.36","0.00","0","ȡ�����ֽⶳ","1315936405","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1157","24","tender","1056.64","1057.00","0.00","1056.64","0.00","4","Ͷ�궳���ʽ�","1315936420","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1158","19","cash_cancel","1162.22","1162.00","1162.00","0.22","0.00","0","ȡ�����ֽⶳ","1315936442","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1159","19","tender","1162.22","1162.00","0.00","1162.22","0.00","4","Ͷ�궳���ʽ�","1315936455","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1160","23","cash_cancel","1061.18","1061.00","1061.00","0.18","0.00","0","ȡ�����ֽⶳ","1315936490","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1161","23","tender","1061.18","1061.00","0.00","1061.18","0.00","4","Ͷ�궳���ʽ�","1315936505","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1162","26","cash_cancel","1056.29","1057.00","1057.00","-0.71","0.00","0","ȡ�����ֽⶳ","1315936561","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1163","26","tender","1056.29","1057.00","0.00","1056.29","0.00","4","Ͷ�궳���ʽ�","1315936575","113.65.153.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1164","34","invest_false","35400.19","1888.00","1888.00","32447.07","1065.12","25","�б�[<a href=\'/invest/a31.html\' target=_blank>�����ã����ν�����������ʵ���</a>]ʧ�ܷ��ص�Ͷ���","1315971113","221.215.143.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1165","11","invest_false","61709.80","530.00","530.43","25342.00","35837.37","25","�б�[<a href=\'/invest/a31.html\' target=_blank>�����ã����ν�����������ʵ���</a>]ʧ�ܷ��ص�Ͷ���","1315971113","221.215.143.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1166","34","invest_false","35400.19","470.00","2358.00","31977.07","1065.12","25","�б�[<a href=\'/invest/a31.html\' target=_blank>�����ã����ν�����������ʵ���</a>]ʧ�ܷ��ص�Ͷ���","1315971113","221.215.143.110");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1167","28","cash_frost","326.10","320.00","6.10","320.00","0.00","0","�û���������","1315978096","123.87.177.95");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1168","34","invest_false","35400.19","4000.00","6358.00","27977.07","1065.12","28","�б�[<a href=\'/invest/a38.html\' target=_blank>�����֣�֧����վ����Ͷ������ӡ��</a>]ʧ�ܷ��ص�Ͷ���","1315978144","123.87.177.95");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1169","27","recharge","33490.82","0.01","0.01","33490.81","0.00","0","���߳�ֵ","1316239514","58.251.61.177");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1170","27","fee","33490.82","0.00","0.01","33490.81","0.00","0","���߳�ֵ������","1316239514","58.251.61.177");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1171","43","invest_false","60750.96","30000.00","47918.52","6612.00","6220.44","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1172","6","invest_false","10195.54","5992.00","5992.50","4000.00","203.04","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1173","12","invest_false","61048.18","22082.00","22082.07","7832.00","31134.11","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1174","41","invest_false","10157.58","2157.00","2157.58","8000.00","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1175","5","invest_false","60318.68","56080.00","56080.06","2800.00","1438.62","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1176","34","invest_false","35400.19","20767.94","27125.94","7209.13","1065.12","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1177","13","invest_false","50390.00","40390.00","40390.00","10000.00","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1178","11","invest_false","61709.80","21042.00","21572.43","4300.00","35837.37","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1179","30","invest_false","10000.00","10000.00","10000.00","0.00","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1180","55","invest_false","20000.00","20000.00","20000.00","0.00","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1181","40","invest_false","40287.80","36977.00","36977.50","1180.00","2130.30","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1182","42","invest_false","10118.17","7118.00","7118.17","3000.00","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1183","7","invest_false","60140.12","15140.00","15140.12","45000.00","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1184","57","invest_false","49950.00","40000.00","47270.00","2680.00","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1185","58","invest_false","50000.00","50000.00","50000.00","0.00","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1186","22","invest_false","1075.57","1076.07","1076.07","-0.50","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573665","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1187","14","invest_false","2561.39","2561.80","2561.80","-0.41","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573667","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1188","18","invest_false","1184.62","1184.62","1184.62","0.00","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573667","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1189","16","invest_false","2367.93","2368.00","2368.00","-0.07","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573668","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1190","24","invest_false","1056.64","1057.00","1057.00","-0.36","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573668","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1191","19","invest_false","1162.22","1162.00","1162.00","0.22","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573669","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1192","23","invest_false","1061.18","1061.00","1061.00","0.18","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573669","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1193","26","invest_false","1056.29","1057.00","1057.00","-0.71","0.00","0","�б�[<a href=\'/invest/a41.html\' target=_blank>��ǰף����ͨ��Ա����ڿ��֣�</a>]ʧ�ܷ��ص�Ͷ���","1316573670","58.46.175.19");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1194","64","realname","-5.00","5.00","-5.00","0.00","0.00","0","ʵ����֤�۳�����","1318663558","58.219.248.170");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1195","64","recharge","995.00","1000.00","995.00","0.00","0.00","0","�˺ų�ֵ","1318738703","117.93.26.61");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1196","64","fee","985.00","10.00","985.00","0.00","0.00","0","��ֵ�����ѿ۳�","1318738703","117.93.26.61");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1197","64","vip","805.00","180.00","805.00","0.00","0.00","0","�۳�VIP��Ա��","1318738703","117.93.26.61");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1198","64","recharge","1805.00","1000.00","1805.00","0.00","0.00","0","�˺ų�ֵ","1318738734","117.93.26.61");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1199","64","tender","1805.00","100.00","1705.00","100.00","0.00","28","Ͷ�궳���ʽ�","1318777198","117.93.29.70");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1200","64","tender","1805.00","200.00","1505.00","300.00","0.00","25","Ͷ�궳���ʽ�","1318777274","117.93.29.70");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1201","65","recharge","5000.00","5000.00","5000.00","0.00","0.00","0","�˺ų�ֵ","1318814375","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1202","65","vip","4820.00","180.00","4820.00","0.00","0.00","0","�۳�VIP��Ա��","1318814375","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1203","65","recharge","9820.00","5000.00","9820.00","0.00","0.00","0","�˺ų�ֵ","1318814409","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1204","65","recharge","10320.00","500.00","10320.00","0.00","0.00","0","�˺ų�ֵ","1318814423","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1205","65","fee","10315.00","5.00","10315.00","0.00","0.00","0","��ֵ�����ѿ۳�","1318814423","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1206","65","tender","10315.00","5000.00","5315.00","5000.00","0.00","64","Ͷ�궳���ʽ�","1318814536","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1207","65","invest","5315.00","5000.00","5315.00","0.00","0.00","64","Ͷ��ɹ����ÿ۳�","1318814706","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1208","65","collection","10659.32","5344.32","5315.00","0.00","5344.32","64","���ս��","1318814706","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1209","64","borrow_success","6805.00","5000.00","6505.00","300.00","0.00","0","ͨ��[<a href=\'/invest/a44.html\' target=_blank>����</a>]�赽�Ŀ�","1318814706","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1210","64","margin","6805.00","500.00","6005.00","800.00","0.00","0","��������[<a href=\'/invest/a44.html\' target=_blank>����</a>]�ı�֤��","1318814706","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1211","64","borrow_fee","6665.00","140.00","5865.00","800.00","0.00","0","���[<a href=\'/invest/a44.html\' target=_blank>����</a>]��������","1318814706","117.93.22.200");

insert into `dw_account_log` ( `id`,`user_id`,`type`,`total`,`money`,`use_money`,`no_use_money`,`collection`,`to_user`,`remark`,`addtime`,`addip`) values ("1212","1","recharge","50.00","50.00","50.00","0.00","0.00","0","�˺ų�ֵ","1331707154","110.191.130.26");

