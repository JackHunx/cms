insert into `dw_online` ( `user_id`,`username`,`type_id`,`tid`,`fid`,`atpage`,`ip`,`activetime`) values ("0","","","0","0","","124.115.0.139","1331800681");

insert into `dw_online` ( `user_id`,`username`,`type_id`,`tid`,`fid`,`atpage`,`ip`,`activetime`) values ("1","admin","1","0","0","","112.192.43.32","1331800570");

insert into `dw_online` ( `user_id`,`username`,`type_id`,`tid`,`fid`,`atpage`,`ip`,`activetime`) values ("0","","","0","0","","220.181.125.47","1331800697");

