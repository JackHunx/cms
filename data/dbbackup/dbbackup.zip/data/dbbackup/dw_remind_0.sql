insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("1","�����Ϊ����","friend_request","0","10","4","1","4","4","1284123091","127.0.0.1");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("2","��Ϊ���ѹ�ϵ","friend_yes","0","12","4","3","4","4","1284123281","127.0.0.1");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("3","�������ͨ��","withdraw_yes","0","10","1","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("4","������˲�ͨ��","withdraw_no","0","10","1","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("5","��վ��ֵ","recharge","0","10","1","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("6","��֤��ⶳ","margin_thaw","0","10","1","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("7","���³�ֵ","recharge_down","0","10","1","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("8","VIP���ͨ��","vip_yes","0","10","1","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("9","VIP��˲�ͨ��","vip_no","0","10","1","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("10","�������ͨ��","borrow_yes","0","10","2","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("11","�������ͨ��","borrow_no","0","10","2","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("12","��������Ͷ��ʱ","borrow_join","0","10","2","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("13","���긴��ͨ��","borrow_review_yes","0","10","2","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("14","���긴��ͨ��","borrow_review_no","0","10","2","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("15","��������","borrow_end","0","10","2","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("16","��������","borrow_msg","0","10","2","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("17","Ͷ��Ľ����޸�����","loan_update","0","10","3","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("18","Ͷ��Ľ�������","loan_end","0","10","3","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("19","����ɹ����۳������","loan_yes_account","0","10","3","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("20","���ʧ�ܣ��ⶳ�����","loan_no_account","0","10","3","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("21","�յ�����","loan_pay","0","10","3","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("22","��վ�渶","loan_advanced","0","10","3","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("23","��������","loan_assess","0","10","3","1","4","2","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("24","�ܾ���������","friend_pass","0","10","4","1","4","4","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("25","������ѹ�ϵ","friend_end","0","10","4","1","4","4","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("26","�������ͨ��","info_yes","0","10","4","1","4","4","0","");

insert into `dw_remind` ( `id`,`name`,`nid`,`status`,`order`,`type_id`,`message`,`email`,`phone`,`addtime`,`addip`) values ("27","������˲�ͨ��","info_no","0","10","4","1","4","4","0","");

