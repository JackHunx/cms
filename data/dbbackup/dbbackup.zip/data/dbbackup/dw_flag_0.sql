insert into `dw_flag` ( `id`,`name`,`nid`,`order`) values ("1","�Ƽ�","t","10");

insert into `dw_flag` ( `id`,`name`,`nid`,`order`) values ("2","ͷ��","h","10");

insert into `dw_flag` ( `id`,`name`,`nid`,`order`) values ("3","�õ�Ƭ","f","10");

