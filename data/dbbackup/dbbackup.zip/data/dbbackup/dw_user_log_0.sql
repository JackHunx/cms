insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("1","1","module/payment/edit","htxd&q=module/payment/edit&nid=offline&id=31","1","1314325492","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("2","1","module/article/new","htxd&q=module/article/new&site_id=22&a=site","1","1314325669","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("3","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=15&id=5","1","1314325747","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("4","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=4&id=6","1","1314325769","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("5","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=4&id=10","1","1314325961","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("6","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=32","1","1314326130","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("7","1","module/scrollpic/del","htxd&q=module/scrollpic/del&id=6","1","1314409683","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("8","1","module/scrollpic/del","htxd&q=module/scrollpic/del&id=8","1","1314409687","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("9","1","module/scrollpic/del","htxd&q=module/scrollpic/del&id=12","1","1314409690","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("10","1","module/scrollpic/new","htxd&q=module/scrollpic/new&site_id=58&a=site","1","1314409718","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("11","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=10&site_id=51&a=site","1","1314422024","58.46.179.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("12","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=34","1","1314542761","113.219.77.148");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("13","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=34&site_id=51&a=site","1","1314543047","113.219.77.148");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("14","1","module/article/new","htxd&q=module/article/new&site_id=22&a=site","1","1314585927","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("15","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=75","1","1314589512","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("16","1","module/scrollpic/new","htxd&q=module/scrollpic/new&site_id=58&a=site","1","1314595794","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("17","1","module/scrollpic/del","htxd&q=module/scrollpic/del&id=14","1","1314595842","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("18","1","module/scrollpic/new","htxd&q=module/scrollpic/new","1","1314595855","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("19","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=35","1","1314596228","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("20","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=15&id=13","1","1314596378","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("21","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=25&id=14","1","1314596604","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("22","1","module/article/new","htxd&q=module/article/new&site_id=59&a=site","1","1314597339","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("23","1","module/article/new","htxd&q=module/article/new&site_id=59&a=site","1","1314597446","58.46.162.87");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("24","1","module/borrow/edit","htxd&q=module/borrow/edit&site_id=15&a=site&user_id=4&id=10","Array","1314617782","113.219.1.152");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("25","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=13&id=7","1","1314665243","113.219.225.103");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("26","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=12&id=9","1","1314665273","113.219.225.103");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("27","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=20&id=8","1","1314665294","113.219.225.103");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("28","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=25&id=14","Array","1314665311","113.219.225.103");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("29","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=25&id=14","1","1314665320","113.219.225.103");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("30","1","module/account/cash_view","htxd&q=module/account/cash_view&site_id=53&a=site&id=1","1","1314677086","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("31","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=99","1","1314678279","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("32","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=33&site_id=51&a=site","1","1314680609","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("33","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=53&a=site&id=42","1","1314680911","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("34","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=3","1","1314680985","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("35","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=13&id=15","1","1314681190","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("36","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=38&site_id=51&a=site","1","1314682582","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("37","1","module/scrollpic/new","htxd&q=module/scrollpic/new&site_id=58&a=site","1","1314683733","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("38","1","module/scrollpic/del","htxd&q=module/scrollpic/del&id=16","1","1314683899","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("39","1","module/scrollpic/new","htxd&q=module/scrollpic/new","1","1314683971","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("40","1","module/scrollpic/edit","htxd&q=module/scrollpic/edit&id=15","1","1314684558","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("41","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=38&id=16","1","1314684710","58.46.184.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("42","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=43","1","1314716436","113.219.166.91");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("43","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=39&site_id=51&a=site","1","1314716801","113.219.166.91");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("44","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=39&id=17","1","1314717039","113.219.166.91");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("45","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=44","1","1314717297","113.219.166.91");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("46","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=45","1","1314717479","113.219.166.91");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("47","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=4","1","1314717578","113.219.166.91");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("48","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=20&id=18","1","1314717687","113.219.166.91");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("49","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=46","1","1314720166","113.219.166.91");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("50","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=47","1","1314720733","113.219.166.91");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("51","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=48","1","1314753194","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("52","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=38&id=16","1","1314753326","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("53","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=68","1","1314753597","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("54","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=67","1","1314753615","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("55","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=66","1","1314753630","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("56","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=65","1","1314753646","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("57","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=64","1","1314753659","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("58","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=63","1","1314753670","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("59","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=62","1","1314753682","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("60","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=61","1","1314753694","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("61","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=60","1","1314753705","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("62","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=59","1","1314753721","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("63","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=58","1","1314753744","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("64","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=57","1","1314753755","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("65","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=56","1","1314753766","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("66","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=55","1","1314753793","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("67","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=54","1","1314753805","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("68","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=53","1","1314753816","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("69","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=52","1","1314753838","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("70","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=51","1","1314753857","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("71","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=50","1","1314753873","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("72","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=49","1","1314753885","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("73","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=48","1","1314753897","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("74","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=47","1","1314753908","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("75","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=46","1","1314753924","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("76","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=45","1","1314753939","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("77","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=44","1","1314753950","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("78","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=43","1","1314753969","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("79","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=42","1","1314753984","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("80","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=41","1","1314753995","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("81","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=40","1","1314754011","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("82","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=39","1","1314754026","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("83","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=38","1","1314754038","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("84","1","module/attestation/view","htxd&q=module/attestation/view&site_id=26&a=site&id=37","1","1314754048","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("85","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=28&site_id=51&a=site","1","1314754101","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("86","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=49","1","1314754503","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("87","1","module/article/new","htxd&q=module/article/new&site_id=22&a=site","1","1314756283","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("88","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=98","1","1314757013","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("89","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=33&id=19","1","1314757172","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("90","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=33&id=20","1","1314758135","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("91","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=50","1","1314758637","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("92","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=44&site_id=51&a=site","1","1314758974","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("93","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=44&id=21","1","1314759095","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("94","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=104","1","1314760270","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("95","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=51","1","1314761004","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("96","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=52","1","1314761562","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("97","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=54","1","1314763864","58.46.178.119");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("98","1","module/payment/edit","htxd&q=module/payment/edit&nid=offline&id=31","1","1314777406","118.253.15.116");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("99","1","module/article/new","htxd&q=module/article/new&site_id=22&a=site","1","1314780252","118.253.15.116");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("100","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=55","1","1314782232","118.253.15.116");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("101","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=56","1","1314782906","118.253.15.116");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("102","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=57","1","1314783245","113.219.8.170");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("103","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=27&site_id=51&a=site","1","1314789355","113.219.34.69");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("104","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=45","1","1314789392","113.219.34.69");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("105","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=46","1","1314789424","113.219.34.69");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("106","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=30&a=site&user_id=33&id=20","1","1314789582","113.219.34.69");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("107","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=30&a=site&user_id=4&id=10","1","1314789683","113.219.34.69");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("108","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=38&id=22","1","1314839992","113.219.169.177");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("109","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=66","1","1314849120","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("110","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=39&id=17","Array","1314849355","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("111","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=39&id=17","1","1314849367","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("112","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=67","1","1314851415","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("113","1","module/article/new","htxd&q=module/article/new&site_id=22&a=site","1","1314851505","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("114","1","module/article/del","htxd&q=module/article/del&site_id=22&a=site&id=106","1","1314853587","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("115","1","module/article/new","htxd&q=module/article/new&site_id=22&a=site","1","1314853814","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("116","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=107","1","1314853898","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("117","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=155","1","1314855571","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("118","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=154","1","1314855594","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("119","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=153","1","1314855615","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("120","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=152","1","1314855634","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("121","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=151","1","1314855645","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("122","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=150","1","1314855665","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("123","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=149","1","1314855685","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("124","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=148","1","1314855703","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("125","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=147","1","1314855717","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("126","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=146","1","1314855736","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("127","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=145","1","1314855748","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("128","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=144","1","1314855763","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("129","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=143","1","1314855793","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("130","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=139","1","1314855814","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("131","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=138","1","1314855830","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("132","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=137","1","1314855846","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("133","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=136","1","1314855866","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("134","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=135","1","1314855886","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("135","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=134","1","1314855898","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("136","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=133","1","1314855912","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("137","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=132","1","1314855922","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("138","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=131","1","1314855936","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("139","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=118","1","1314855960","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("140","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=106","1","1314855988","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("141","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=104","1","1314856010","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("142","1","module/attestation/view","htxd&q=module/attestation/view&site_id=47&a=site&id=130","1","1314856026","58.46.183.83");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("143","1","module/user/del","htxd&q=module/user/del&user_id=48&site_id=50&a=site","1","1314865598","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("144","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=69","1","1314866580","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("145","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=68","1","1314866591","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("146","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=50&site_id=51&a=site","1","1314867241","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("147","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=49&site_id=51&a=site","1","1314867257","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("148","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=1","1","1314867550","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("149","1","module/borrow/view","htxd&q=module/borrow/view&user_id=4&id=24","1","1314867685","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("150","1","module/borrow/view","htxd&q=module/borrow/view&user_id=49&id=23","1","1314867718","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("151","1","module/borrow/view","htxd&q=module/borrow/view&user_id=50&id=25","1","1314868055","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("152","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=70","1","1314871842","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("153","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=71","1","1314872376","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("154","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=5","1","1314872649","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("155","1","module/borrow/view","htxd&q=module/borrow/view&user_id=39&id=27","1","1314872767","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("156","1","module/borrow/view","htxd&q=module/borrow/view&user_id=12&id=28","1","1314872777","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("157","1","module/borrow/view","htxd&q=module/borrow/view&user_id=28&id=26","1","1314872787","113.219.247.72");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("158","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=82","1","1314929853","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("159","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=81","1","1314929865","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("160","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=80","1","1314929875","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("161","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=79","1","1314929885","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("162","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=78","1","1314929898","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("163","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=77","1","1314929908","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("164","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=76","1","1314929922","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("165","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=75","1","1314929934","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("166","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=74","1","1314929948","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("167","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=73","1","1314929964","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("168","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=72","1","1314929978","113.219.121.221");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("169","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=33&id=29","1","1314942602","119.39.229.181");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("170","1","module/article/edit","htxd&q=module/article/edit&site_id=11&a=site&id=78","1","1315339315","113.219.140.1");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("171","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=38&id=30","1","1315441729","113.218.152.110");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("172","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=12&id=28","1","1315441757","113.218.152.110");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("173","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=28&id=26","1","1315441770","113.218.152.110");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("174","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=49&id=23","1","1315441821","113.218.152.110");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("175","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=44&id=21","1","1315441854","113.218.152.110");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("176","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=87","1","1315443540","113.218.152.110");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("177","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=86","1","1315443550","113.218.152.110");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("178","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=85","1","1315443561","113.218.152.110");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("179","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=25&id=31","1","1315469184","113.218.160.49");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("180","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=36&site_id=51&a=site","1","1315484485","113.218.53.251");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("181","1","module/article/new","htxd&q=module/article/new&site_id=22&a=site","1","1315484900","113.218.53.251");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("182","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=90","1","1315485094","113.218.53.251");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("183","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=4&id=32","1","1315487030","113.218.53.251");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("184","1","module/payment/edit","htxd&q=module/payment/edit&nid=tenpay&id=9","1","1315558000","113.218.188.121");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("185","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=30&a=site&user_id=50&id=25","1","1315611158","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("186","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=30&a=site&user_id=13&id=15","1","1315611209","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("187","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=96","1","1315611341","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("188","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=97","1","1315611582","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("189","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=98","1","1315611590","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("190","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=99","1","1315611598","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("191","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=7","1","1315612476","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("192","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&id=8","1","1315612495","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("193","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=3","1","1315612704","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("194","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&id=9","1","1315612712","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("195","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=49&id=33","1","1315613061","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("196","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=13&id=34","1","1315613085","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("197","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=100","1","1315613149","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("198","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=101","1","1315613157","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("199","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=102","1","1315613269","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("200","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=103","1","1315613426","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("201","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=39&id=27","1","1315614184","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("202","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=10","1","1315614446","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("203","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=44&id=35","1","1315614559","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("204","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=50&id=36","1","1315614572","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("205","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=28&id=37","1","1315620090","113.218.120.128");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("206","1","module/payment/edit","htxd&q=module/payment/edit&nid=offline&id=31","1","1315626927","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("207","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=28&id=37","1","1315627021","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("208","1","module/article/del","htxd&q=module/article/del&site_id=22&a=site&id=105","1","1315627293","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("209","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=28&id=38","1","1315629134","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("210","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=4&id=32","1","1315629500","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("211","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=104","1","1315630019","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("212","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=12","1","1315630109","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("213","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=4&id=39","1","1315630256","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("214","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=13","1","1315630651","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("215","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&id=6","1","1315630743","113.218.36.55");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("216","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=105","1","1315651432","113.218.125.86");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("217","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=15&a=site&user_id=13&id=34","1","1315651473","113.218.125.86");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("218","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=15","1","1315651578","113.218.125.86");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("219","1","module/borrow/view","htxd&q=module/borrow/view&user_id=39&id=40","1","1315651652","113.218.125.86");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("220","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=13","1","1315657429","113.218.125.86");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("221","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&id=13","1","1315657611","113.218.125.86");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("222","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=108","1","1315660480","113.218.125.86");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("223","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=109","1","1315700506","113.218.92.0");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("224","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=110","1","1315700525","113.218.92.0");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("225","1","module/borrow/amount_view","htxd&q=module/borrow/amount_view&site_id=52&a=site&id=1","1","1315700642","113.218.92.0");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("226","1","module/borrow/view","htxd&q=module/borrow/view&user_id=4&id=41","1","1315701402","113.218.92.0");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("227","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=116","1","1315702035","113.218.154.44");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("228","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=115","1","1315702049","113.218.154.44");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("229","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=114","1","1315702087","113.218.154.44");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("230","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=117","1","1315703399","113.218.154.44");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("231","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=118","1","1315714625","113.218.4.79");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("232","1","module/account/cash_view","htxd&q=module/account/cash_view&id=12","1","1315715794","113.218.4.79");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("233","1","module/account/cash_view","htxd&q=module/account/cash_view&id=13","1","1315716014","113.218.4.79");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("234","1","module/account/cash_view","htxd&q=module/account/cash_view&id=14","1","1315716089","113.218.4.79");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("235","1","module/account/recharge_view","htxd&q=module/account/recharge_view&id=119","1","1315716161","113.218.4.79");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("236","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=120","1","1315716661","113.218.4.79");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("237","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=121","1","1315716820","113.218.4.79");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("238","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=122","1","1315717867","113.218.4.79");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("239","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=123","1","1315823257","113.218.198.239");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("240","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=53&a=site&id=124","1","1315823751","113.218.198.239");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("241","1","module/borrow/edit","htxd&q=module/borrow/edit&site_id=15&a=site&user_id=4&id=41","Array","1316572834","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("242","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=77","1","1316572907","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("243","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=75","1","1316572955","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("244","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=71","1","1316572988","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("245","1","module/article/edit","htxd&q=module/article/edit&site_id=11&a=site&id=80","1","1316573036","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("246","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=108","1","1316573077","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("247","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=107","1","1316573094","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("248","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=104","1","1316573117","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("249","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=99","1","1316573192","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("250","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=98","1","1316573208","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("251","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=92","1","1316573267","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("252","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=91","1","1316573291","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("253","1","module/liuyan/edit","htxd&q=module/liuyan/edit&id=1","1","1316573327","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("254","1","module/borrow/edit","htxd&q=module/borrow/edit&site_id=15&a=site&user_id=4&id=41","Array","1316573653","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("255","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=28&id=43","1","1316585273","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("256","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=25&id=42","1","1316585291","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("257","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=77","1","1316585571","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("258","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=75","1","1316585618","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("259","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=71","1","1316585651","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("260","1","module/article/edit","htxd&q=module/article/edit&site_id=9&a=site&id=96","1","1316585716","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("261","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=108","1","1316585749","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("262","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=107","1","1316585766","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("263","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=104","1","1316585782","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("264","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=101","1","1316585799","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("265","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=99","1","1316585838","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("266","1","module/article/del","htxd&q=module/article/del&site_id=22&a=site&id=92","1","1316585859","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("267","1","module/article/del","htxd&q=module/article/del&site_id=22&a=site&id=91","1","1316585864","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("268","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=98","1","1316585896","58.46.175.19");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("269","1","system/info/edit","htxd&q=system/info/edit&id=47","1","1318581998","117.93.16.227");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("270","1","system/info/edit","htxd&q=system/info/edit&id=44","1","1318582039","117.93.16.227");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("271","1","system/info/edit","htxd&q=system/info/edit&id=53","1","1318582062","117.93.16.227");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("272","1","system/info/edit","htxd&q=system/info/edit&id=46","1","1318582194","117.93.16.227");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("273","1","system/info/edit","htxd&q=system/info/edit&id=45","1","1318582224","117.93.16.227");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("274","1","system/info/edit","htxd&q=system/info/edit&id=47","1","1318582331","117.93.16.227");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("275","1","module/article/del","htxd&q=module/article/del&site_id=10&a=site&id=110","1","1318582838","112.125.41.74");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("276","1","system/info/edit","htxd&q=system/info/edit&id=48","1","1318583015","117.93.16.227");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("277","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=64&site_id=51&a=site","1","1318667379","58.219.248.170");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("278","1","module/borrow/view","htxd&q=module/borrow/view&site_id=15&a=site&user_id=64&id=44","1","1318668534","58.219.248.170");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("279","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=132","1","1318738703","117.93.26.61");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("280","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=133","1","1318738734","117.93.26.61");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("281","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=65&a=site","1","1318814119","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("282","1","module/account/recharge_view","htxd&q=module/account/recharge_view&id=134","1","1318814375","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("283","1","module/account/recharge_view","htxd&q=module/account/recharge_view&id=136","1","1318814409","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("284","1","module/account/recharge_view","htxd&q=module/account/recharge_view&id=135","1","1318814423","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("285","1","module/borrow/full_view","htxd&q=module/borrow/full_view&site_id=30&a=site&user_id=64&id=44","1","1318814706","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("286","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=1&site_id=51&a=site","1","1318815607","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("287","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=65&site_id=25&a=site","Array","1318815853","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("288","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=64&site_id=25&a=site","Array","1318815949","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("289","1","module/attestation/vipview","htxd&q=module/attestation/vipview&user_id=65&site_id=25&a=site","Array","1318822250","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("290","1","module/attestation/new","htxd&q=module/attestation/new&site_id=25&a=site","1","1318822285","117.93.22.200");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("291","1","module/scrollpic/edit","htxd&q=module/scrollpic/edit&id=17","1","1331706379","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("292","1","module/scrollpic/edit","htxd&q=module/scrollpic/edit&id=17","1","1331706420","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("293","1","module/scrollpic/edit","htxd&q=module/scrollpic/edit&id=17","1","1331706471","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("294","1","module/manager/del","htxd&q=module/manager/del&user_id=69&a=system","1","1331706977","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("295","1","module/manager/del","htxd&q=module/manager/del&user_id=68&a=system","1","1331706982","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("296","1","module/manager/del","htxd&q=module/manager/del&user_id=59&a=system","1","1331706985","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("297","1","module/manager/del","htxd&q=module/manager/del&user_id=32&a=system","1","1331706988","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("298","1","module/manager/del","htxd&q=module/manager/del&user_id=31&a=system","1","1331706992","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("299","1","module/manager/del","htxd&q=module/manager/del&user_id=30&a=system","1","1331706996","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("300","1","module/manager/del","htxd&q=module/manager/del&user_id=3&a=system","1","1331706999","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("301","1","module/manager/del","htxd&q=module/manager/del&user_id=2&a=system","1","1331707003","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("302","1","module/account/recharge_view","htxd&q=module/account/recharge_view&site_id=29&a=site&id=138","1","1331707154","110.191.130.26");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("303","1","module/links/edit","htxd&q=module/links/edit&id=8","1","1331715672","221.10.9.254");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("304","1","module/links/edit","htxd&q=module/links/edit&id=8","1","1331732092","112.195.115.130");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("305","1","module/links/edit","htxd&q=module/links/edit&id=7","1","1331732601","112.195.115.130");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("306","1","module/links/edit","htxd&q=module/links/edit&id=6","1","1331732636","112.195.115.130");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("307","1","module/links/edit","htxd&q=module/links/edit&id=2","1","1331732748","112.195.115.130");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("308","1","module/links/edit","htxd&q=module/links/edit&id=6","1","1331732776","112.195.115.130");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("309","1","module/scrollpic/edit","htxd&q=module/scrollpic/edit&id=15","1","1331795693","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("310","1","module/scrollpic/edit","htxd&q=module/scrollpic/edit&id=13","1","1331796137","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("311","1","module/article/del","htxd&q=module/article/del&site_id=10&a=site&id=109","1","1331797476","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("312","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=96","1","1331797588","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("313","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=76","1","1331797633","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("314","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=75","1","1331797767","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("315","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=71","1","1331797888","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("316","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=70","1","1331797914","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("317","1","module/article/edit","htxd&q=module/article/edit&site_id=11&a=site&id=78","1","1331798072","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("318","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=108","1","1331798149","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("319","1","module/article/del","htxd&q=module/article/del&site_id=22&a=site&id=107","1","1331798163","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("320","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=104","1","1331798240","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("321","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=98","1","1331798265","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("322","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=99","1","1331798335","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("323","1","module/article/edit","htxd&q=module/article/edit&site_id=22&a=site&id=97","1","1331798403","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("324","1","module/article/edit","htxd&q=module/article/edit&site_id=34&a=site&id=90","1","1331798493","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("325","1","module/article/edit","htxd&q=module/article/edit&site_id=34&a=site&id=90","1","1331798608","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("326","1","module/article/edit","htxd&q=module/article/edit&site_id=34&a=site&id=89","1","1331798665","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("327","1","module/article/edit","htxd&q=module/article/edit&site_id=34&a=site&id=88","1","1331798862","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("328","1","module/article/edit","htxd&q=module/article/edit&site_id=10&a=site&id=77","1","1331798949","112.192.43.32");

insert into `dw_user_log` ( `log_id`,`user_id`,`query`,`url`,`result`,`addtime`,`addip`) values ("329","1","module/payment/del","htxd&q=module/payment/del&id=31","1","1331800134","112.192.43.32");

