insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("1","0","5","1","1","1000","1000","1015","60","4015","0","0","15","1314097403","118.253.4.77");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("2","0","7","1","1","1000","1000","1015","37.53","4060","0","0","15","1314098111","118.253.4.77");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("3","0","6","1","1","1000","1000","1015","28.32","1903","0","0","15","1314098179","118.253.4.77");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("4","0","6","1","2","1000","1000","1007.4","27.4","3007.4","0","0","7.4","1314176561","58.46.172.103");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("5","0","5","1","2","1000","1000","1007.4","12.4","1507.4","0","0","7.4","1314188171","222.243.13.108");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("6","0","11","1","2","1000","1000","1007.4","140.72","9895.4","0","0","7.4","1314245199","58.46.193.18");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("7","0","12","1","2","100","45","45.33","40.33","3045.33","0","0","0.33","1314249273","58.46.193.18");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("8","0","5","1","3","200","200","203","40","5203","0","0","3","1314251721","58.46.193.18");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("9","0","6","1","5","100","100","101","76","5101","0","0","1","1314257328","58.46.193.18");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("10","0","6","1","4","500","500","505","755","50505","0","0","5","1314257358","58.46.193.18");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("11","0","6","1","3","200","200","203","3","203","0","0","3","1314257822","58.46.193.18");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("12","0","14","1","3","488","488","495.32","7.32","495.32","0","0","7.32","1314258383","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("13","0","14","1","4","500","500","505","5","505","0","0","5","1314258415","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("14","0","14","1","4","1000","1000","1010","10","1010","0","0","10","1314259420","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("15","0","14","1","5","100","100","101","1","101","0","0","1","1314259440","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("16","0","16","1","5","100","100","101","7.25","601","0","0","1","1314261504","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("17","0","19","1","5","100","100","101","29.88","2989","0","0","1","1314263481","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("18","0","18","1","5","100","100","101","1","101","0","0","1","1314263522","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("19","0","14","1","6","300","300","304.5","4.5","304.5","0","0","4.5","1314263594","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("20","0","22","1","6","1000","1000","1015","33.33","2015","0","0","15","1314268848","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("21","0","6","1","8","500","500","503.7","53.7","5503.7","0","0","3.7","1314269144","118.253.11.171");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("22","0","6","1","7","500","500","506.67","6.67","506.67","0","0","6.67","1314269170","118.253.11.171");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("23","0","6","1","6","1000","1000","1015","65","6015","0","0","15","1314269201","118.253.11.171");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("24","0","24","1","6","1000","1000","1015","15","1015","0","0","15","1314270173","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("25","0","23","1","6","1000","1000","1015","51.17","5903","0","0","15","1314270219","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("26","0","26","1","6","1000","1000","1015","18.33","1515","0","0","15","1314270755","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("27","0","18","1","6","1000","1000","1015","52.04","6015","0","0","15","1314271764","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("28","0","12","1","8","1000","1000","1007.4","96.28","9895.4","0","0","7.4","1314272031","118.253.11.171");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("29","0","12","1","7","500","500","506.67","6.67","506.67","0","0","6.67","1314272062","118.253.11.171");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("30","0","12","1","6","1000","1000","1015","15","1015","0","0","15","1314272092","118.253.11.171");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("31","0","19","1","6","1000","1000","1015","15","1015","0","0","15","1314272449","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("32","0","16","1","6","588","588","596.82","1878.43","89484.82","0","0","8.82","1314273004","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("33","0","16","1","9","1517.63","1517.63","1540.39","22.76","1540.39","0","0","22.76","1314273899","113.65.155.250");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("34","0","5","1","8","1000","1000","1007.4","7.4","1007.4","0","0","7.4","1314275439","58.46.219.35");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("35","0","5","1","9","1000","1000","1015","15","1015","0","0","15","1314275464","58.46.219.35");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("36","0","5","1","10","2000","2000","2030","30","2030","0","0","30","1314326556","58.46.179.32");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("37","0","12","1","10","2000","2000","2030","90.2","5030.01","0","0","30","1314327761","58.46.179.32");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("38","0","6","1","10","2000","2000","2030","30","2030","0","0","30","1314409789","58.46.179.32");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("39","0","11","1","10","2000","2000","2030","30","2030","0","0","30","1314527473","113.219.24.38");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("40","0","11","1","9","1500","1500","1522.5","22.5","1522.5","0","0","22.5","1314527512","113.219.24.38");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("41","0","11","1","7","500","500","506.67","6.67","506.67","0","0","6.67","1314527533","113.219.24.38");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("42","0","11","1","8","1000","1000","1007.4","7.4","1007.4","0","0","7.4","1314527606","113.219.24.38");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("43","0","22","1","9","1014","982.37","997.11","14.74","997.11","0","0","14.74","1314538735","113.65.172.88");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("44","0","14","1","8","1000","1000","1007.4","7.4","1007.4","0","0","7.4","1314538839","113.65.172.88");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("45","0","18","1","8","1000","500","503.7","3.7","503.7","0","0","3.7","1314538916","113.65.172.88");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("46","0","18","1","7","500","500","506.67","6.67","506.67","0","0","6.67","1314538946","113.65.172.88");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("47","0","14","1","7","500","500","506.67","6.67","506.67","0","0","6.67","1314539024","113.65.172.88");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("48","0","16","1","7","500","500","506.67","6.67","506.67","0","0","6.67","1314539094","113.65.172.88");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("49","0","34","1","10","2000","2000","2030","30","2030","0","0","30","1314543711","113.219.77.148");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("50","0","6","1","13","1000","1000","1038.57","38.57","0","1038.57","38.57","0","1314596550","58.46.162.87");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("51","0","6","1","14","200","200","203.04","3.04","0","203.04","3.04","0","1314597188","58.46.162.87");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("52","0","5","1","13","800","800","830.85","30.85","0","830.85","30.85","0","1314597741","58.46.162.87");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("53","0","5","1","14","200","200","203.04","3.04","0","203.04","3.04","0","1314597766","58.46.162.87");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("54","0","12","1","14","600","600","609.11","9.11","0","609.11","9.11","0","1314617566","113.219.1.152");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("55","0","12","1","13","1200","1200","1246.29","46.29","0","1246.29","46.29","0","1314617618","113.219.1.152");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("56","0","12","1","10","3000","3000","3045","45","3045","0","0","45","1314677371","58.46.184.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("57","0","34","1","15","1000","1000","1065.12","65.12","0","1065.12","65.12","0","1314682959","58.46.184.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("58","0","34","1","13","820","820","851.64","31.64","0","851.64","31.64","0","1314682981","58.46.184.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("59","0","23","1","16","500","500","506.25","6.25","506.25","0","0","6.25","1314685711","113.65.154.14");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("60","0","16","1","17","500","500","505","5","505","0","0","5","1314717349","113.65.174.11");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("61","0","23","1","17","500","500","505","5","505","0","0","5","1314717828","113.65.154.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("62","0","24","1","17","500","500","505","5","505","0","0","5","1314718630","113.65.152.6");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("63","0","40","1","10","5000","5000","5075","75","5075","0","0","75","1314720224","113.219.166.91");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("64","0","40","1","15","2000","2000","2130.3","130.3","0","2130.3","130.3","0","1314720332","113.219.166.91");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("65","0","40","1","13","1200","1180","1225.53","45.53","0","1225.53","45.53","0","1314720377","113.219.166.91");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("66","0","41","1","10","5000","5000","5075","75","5075","0","0","75","1314720801","113.219.166.91");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("67","0","26","1","17","500","500","505","5","505","0","0","5","1314722232","113.65.154.201");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("68","0","19","1","17","500","500","505","5","505","0","0","5","1314722957","113.65.153.161");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("69","0","22","1","17","388","388","391.88","3.88","391.88","0","0","3.88","1314723420","113.65.154.174");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("70","0","42","1","10","5000","5000","5075","75","5075","0","0","75","1314753254","58.46.178.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("71","0","43","1","10","5000","5000","5075","75","5075","0","0","75","1314754545","58.46.178.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("72","0","43","1","15","800","800","852.12","52.12","0","852.12","52.12","0","1314757224","58.46.178.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("73","0","22","1","20","629.27","629.27","640.81","11.54","640.81","0","0","11.54","1314758800","113.65.187.251");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("74","0","16","1","20","370.73","370.73","377.53","6.8","377.53","0","0","6.8","1314758929","113.65.186.215");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("75","0","43","1","21","500","500","505","5","505","0","0","5","1314759796","58.46.178.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("76","0","5","1","10","3000","3000","3045","45","3045","0","0","45","1314760544","58.46.178.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("77","0","27","1","10","5000","5000","5075","75","5075","0","0","75","1314761098","180.110.4.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("78","0","16","1","10","1360.22","1360.22","1380.62","20.4","1380.62","0","0","20.4","1314761421","113.65.186.215");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("79","0","45","1","10","5000","5000","5075","75","5075","0","0","75","1314761747","180.110.4.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("80","0","14","1","10","1916.11","1916.11","1944.85","28.74","1944.85","0","0","28.74","1314764015","113.65.172.7");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("81","0","18","1","10","723.67","723.67","734.53","10.86000000","734.53","0","0","10.86","1314764066","113.65.185.211");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("82","0","18","1","21","390.06","390.06","393.96","3.9","393.96","0","0","3.9","1314764093","113.65.185.211");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("83","0","19","1","21","500","500","505","5","505","0","0","5","1314764693","113.66.243.41");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("84","0","24","1","21","500","500","505","5","505","0","0","5","1314764810","113.65.186.224");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("85","0","26","1","21","500","500","505","5","505","0","0","5","1314764863","113.65.187.184");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("86","0","14","1","21","500","500","505","5","505","0","0","5","1314764941","113.65.185.61");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("87","0","46","1","21","500","500","505","5","505","0","0","5","1314767105","222.94.41.7");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("88","0","27","1","21","500","500","505","5","505","0","0","5","1314782310","180.110.4.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("89","0","45","1","21","500","500","505","5","505","0","0","5","1314783047","180.110.4.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("90","0","18","1","21","109.94","109.94","111.04","1.1","111.04","0","0","1.1","1314801230","113.65.172.148");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("91","0","16","1","21","500","500","505","5","505","0","0","5","1314801427","113.65.153.33");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("92","0","27","2","22","2000","2000","2026.67","26.67","0","2026.67","26.67","0","1314841482","180.110.4.119");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("93","0","6","1","25","500","500","503.7","3.7","503.7","0","0","3.7","1314868128","113.219.247.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("94","0","6","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314868169","113.219.247.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("95","0","6","1","23","500","500","505","5","505","0","0","5","1314868189","113.219.247.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("96","0","6","1","18","3000","3000","3195.42","195.42","0","3195.42","195.42","0","1314868215","113.219.247.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("97","0","5","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314872031","113.219.247.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("98","0","5","1","18","2000","2000","2130.3","130.3","0","2130.3","130.3","0","1314872131","113.219.247.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("99","0","5","1","25","500","500","503.7","3.7","503.7","0","0","3.7","1314872177","113.219.247.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("100","0","5","1","23","500","500","505","5","505","0","0","5","1314872238","113.219.247.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("101","0","5","1","15","1160","1160","1235.58","75.58","0","1235.58","75.58","0","1314872454","113.219.247.72");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("102","0","14","1","23","500","500","505","5","505","0","0","5","1314872632","113.65.154.93");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("103","0","18","1","23","500","500","505","5","505","0","0","5","1314872947","113.65.152.154");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("104","0","16","1","23","500","500","505","5","505","0","0","5","1314872980","113.65.153.207");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("105","0","23","1","23","500","500","505","5","505","0","0","5","1314873018","113.65.175.180");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("106","0","24","1","23","500","500","505","5","505","0","0","5","1314873063","113.65.185.5");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("107","0","26","1","23","500","500","505","5","505","0","0","5","1314873093","113.65.185.5");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("108","0","22","1","23","391.49","391.49","395.4","3.91","395.4","0","0","3.91","1314873211","113.65.153.214");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("109","0","19","1","23","500","500","505","5","505","0","0","5","1314873247","113.65.185.19");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("110","0","27","1","25","500","500","503.7","3.7","503.7","0","0","3.7","1314873770","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("111","0","27","1","23","500","108.51","109.6","1.089999999","109.6","0","-1.00000008","1.09","1314873800","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("112","0","27","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314873840","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("113","0","27","1","28","5008.99","5008.99","5059.08","50.09","5059.08","0","0","50.09","1314873875","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("114","0","46","1","28","9500","3879.01","3917.8","38.79","3917.8","0","0","38.79","1314873911","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("115","0","46","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314873939","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("116","0","46","1","25","500","500","503.7","3.7","503.7","0","0","3.7","1314873962","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("117","0","46","1","27","500","500","503.7","3.7","503.7","0","0","3.7","1314873987","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("118","0","45","1","27","500","500","503.7","3.7","503.7","0","0","3.7","1314874274","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("119","0","45","1","25","500","500","503.7","3.7","503.7","0","0","3.7","1314874298","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("120","0","45","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314874318","112.2.85.17");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("121","0","14","1","25","500","500","503.7","3.7","503.7","0","0","3.7","1314898778","113.65.155.196");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("122","0","14","1","27","500","500","503.7","3.7","503.7","0","0","3.7","1314898850","113.65.155.196");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("123","0","18","1","25","130.74","130.74","131.71","0.97","131.71","0","0","0.97","1314898908","113.65.155.244");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("124","0","16","1","25","500","500","503.7","3.7","503.7","0","0","3.7","1314898953","113.65.152.15");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("125","0","23","1","25","500","500","503.7","3.7","503.7","0","0","3.7","1314899045","113.65.152.37");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("126","0","19","1","25","108.90","108.90","109.71","0.809999999","109.71","0","-1.00000008","0.81","1314899092","113.65.152.69");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("127","0","34","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314930060","113.219.121.221");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("128","0","34","1","26","500","500","503.33","3.33","503.33","0","0","3.33","1314930239","113.219.121.221");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("129","0","34","1","27","500","500","503.7","3.7","503.7","0","0","3.7","1314930275","113.219.121.221");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("130","0","7","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314930457","113.219.121.221");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("131","0","7","1","18","3000","3000","3195.42","195.42","0","3195.42","195.42","0","1314930484","113.219.121.221");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("132","0","11","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314930632","113.219.121.221");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("133","0","43","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314930675","113.219.121.221");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("134","0","43","1","15","6000","5040","5368.32","328.32","0","5368.32","328.32","0","1314930738","113.219.121.221");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("135","0","43","1","27","500","500","503.7","3.7","503.7","0","0","3.7","1314930783","113.219.121.221");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("136","0","27","1","27","305.7","305.7","307.96","2.26","307.96","0","0","2.26","1314934170","180.110.133.168");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("137","0","40","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314955229","113.219.155.27");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("138","0","42","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314955416","113.219.155.27");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("139","0","42","1","29","1500","1500","1555.32","55.32","0","1555.32","55.32","0","1314955445","113.219.155.27");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("140","0","42","1","25","100","100","100.74","0.739999999","100.74","0","-9.99999971","0.74","1314955499","113.219.155.27");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("141","0","42","1","18","1500","1500","1597.68","97.68","0","1597.68","97.68","0","1314955528","113.219.155.27");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("142","0","12","2","24","2000","2000","2031.47","31.47","0","2031.47","31.47","0","1314955583","113.219.155.27");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("143","0","22","1","25","500","500","503.7","3.7","503.7","0","0","3.7","1315391742","113.65.185.0");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("144","0","22","1","27","159.66","159.66","160.84","1.18","160.84","0","0","1.18","1315391766","113.65.185.0");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("145","0","16","1","27","500","500","503.7","3.7","503.7","0","0","3.7","1315391911","113.65.185.0");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("146","0","12","2","24","5681","5681","5770.38","89.38","0","5770.38","89.38","0","1315442921","113.218.152.110");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("147","0","6","1","27","500","500","503.7","3.7","503.7","0","0","3.7","1315443026","113.218.152.110");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("148","0","34","1","32","18888","18888","19285.28","397.28","19285.28","0","0","397.28","1315487115","113.218.53.251");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("149","0","34","2","31","1888","1888","1976.92","88.92","0","1976.92","88.92","0","1315487162","113.218.53.251");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("150","0","34","1","30","1888","1888","1957.65","69.65","0","1957.65","69.65","0","1315487222","113.218.53.251");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("151","0","34","1","29","1888","1888","1957.65","69.65","0","1957.65","69.65","0","1315487304","113.218.53.251");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("152","0","34","1","18","1888","1888","2010.96","122.96","0","2010.96","122.96","0","1315487339","113.218.53.251");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("153","0","27","1","32","9554.07","9554.07","9755.02","200.95","9755.02","0","0","200.95","1315487676","183.209.141.81");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("154","0","46","1","32","9034.91","9034.91","9224.94","190.03","9224.94","0","0","190.03","1315487735","183.209.141.81");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("155","0","45","1","32","9423.20","9423.20","9621.4","198.2","9621.4","0","0","198.2","1315487776","183.209.141.81");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("156","0","6","1","32","4398","4398","4490.5","92.5","4490.5","0","0","92.5","1315566865","113.218.177.229");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("157","0","12","1","25","500","48.36","48.72","0.360000000","48.72","0","0","0.36","1315566951","113.218.177.229");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("158","0","12","1","32","7000","7000","7147.23","147.23","7147.23","0","0","147.23","1315566974","113.218.177.229");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("159","0","12","1","30","632","632","655.32","23.32","0","655.32","23.32","0","1315566999","113.218.177.229");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("160","0","7","1","27","500","500","503.7","3.7","503.7","0","0","3.7","1315610979","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("161","0","7","1","32","6513","6513","6649.99","136.99","6649.99","0","0","136.99","1315611009","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("162","0","43","1","18","6613","6612","7042.68","430.68","0","7042.68","430.68","0","1315611381","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("163","0","43","1","32","6782","6782","6924.65","142.65","6924.65","0","0","142.65","1315611403","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("164","0","5","1","27","500","500","503.7","3.7","503.7","0","0","3.7","1315612845","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("165","0","5","1","32","5028","5028","5133.76","105.76","5133.76","0","0","105.76","1315612864","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("166","0","11","1","27","500","34.64","34.9","0.259999999","34.9","0","-1.00000002","0.26","1315612954","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("167","0","11","2","31","530","530","554.96","24.96","0","554.96","24.96","0","1315612975","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("168","0","11","1","29","300","300","311.07","11.07","0","311.07","11.07","0","1315612999","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("169","0","41","1","32","2117","2117","2161.53","44.53","2161.53","0","0","44.53","1315613349","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("170","0","41","1","33","8000","8000","8572.75","572.75","0","8572.75","572.75","0","1315613545","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("171","0","12","1","34","30000","30000","30525","525","0","30525","525","0","1315613598","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("172","0","34","1","37","3000","3000","3060.21","60.21","3060.21","0","0.009999999","60.2","1315620827","113.218.120.128");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("173","0","22","1","32","898.34","898.34","917.24","18.9","917.24","0","0","18.9","1315621481","113.65.186.11");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("174","0","14","1","32","2020.23","2020.23","2062.72","42.49","2062.72","0","0","42.49","1315621533","113.65.186.11");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("175","0","18","1","32","1162.61","1162.61","1187.06","24.45","1187.06","0","0","24.45","1315621576","113.65.186.11");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("176","0","16","1","32","1829.96","1829.96","1868.45","38.49","1868.45","0","0","38.49","1315621606","113.65.186.11");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("177","0","23","1","32","1041.46","1041.46","1063.37","21.91","1063.37","0","0","21.91","1315621632","113.65.186.11");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("178","0","19","1","32","1140.63","1140.63","1164.62","23.99","1164.62","0","0","23.99","1315621660","113.65.186.179");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("179","0","24","1","32","1037.50","1037.50","1059.32","21.82","1059.32","0","0","21.82","1315621683","113.65.186.179");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("180","0","26","1","32","1037.50","1019.09","1040.52","21.43000000","1040.52","0","0","21.43","1315621761","113.65.186.179");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("181","0","11","1","35","2000","2000","2316.12","316.12","0","2316.12","316.12","0","1315629338","113.218.36.55");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("182","0","11","1","36","2000","2000","2075.56","75.56","0","2075.56","75.56","0","1315629358","113.218.36.55");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("183","0","11","1","34","35221","35221","35837.37","616.37","0","35837.37","616.37","0","1315629384","113.218.36.55");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("184","0","34","2","38","4000","4000","4100.48","100.48","0","4100.48","100.48","0","1315629646","113.218.36.55");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("185","0","34","2","31","470","470","492.12","22.12","0","492.12","22.12","0","1315629678","113.218.36.55");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("186","0","34","1","35","725.13","725.13","839.76","114.63","0","839.76","114.63","0","1315629734","113.218.36.55");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("187","0","4","1","34","24779","24779","25212.63","433.63","0","25212.63","433.63","0","1315630514","113.218.36.55");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("188","0","7","1","33","42000","42000","45006.85","3006.85","0","45006.85","3006.85","0","1315651735","113.218.125.86");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("189","0","12","1","36","6000","6000","6226.68","226.68","0","6226.68","226.68","0","1315657806","113.218.125.86");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("190","0","43","2","41","30000","30000","30472","472","0","30472","472","0","1315702233","113.218.154.44");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("191","0","6","2","41","5992","5992","6086.27","94.27","0","6086.27","94.27","0","1315707388","113.218.74.188");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("192","0","12","2","41","22082","22082","22429.42","347.42","0","22429.42","347.42","0","1315710641","113.218.44.254");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("193","0","41","2","41","2157","2157","2190.94","33.94","0","2190.94","33.94","0","1315710905","113.218.44.254");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("194","0","5","2","41","56080","56080","56962.33","882.33","0","56962.33","882.33","0","1315714818","113.218.4.79");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("195","0","34","2","41","20767.94","20767.94","21094.69","326.75","0","21094.69","326.75","0","1315714948","113.218.4.79");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("196","0","13","2","41","40390","40390","41025.47","635.47","0","41025.47","635.47","0","1315715851","113.218.4.79");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("197","0","11","2","41","21042","21042","21373.06","331.06","0","21373.06","331.06","0","1315716699","113.218.4.79");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("198","0","30","2","41","10000","10000","10157.33","157.33","0","10157.33","157.33","0","1315716998","113.218.4.79");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("199","0","55","2","41","20000","20000","20314.67","314.67","0","20314.67","314.67","0","1315717945","113.218.4.79");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("200","0","40","2","41","36977","36977","37558.77","581.77","0","37558.77","581.77","0","1315726146","113.218.4.79");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("201","0","42","2","41","7118","7118","7229.99","111.99","0","7229.99","111.99","0","1315785182","113.218.95.63");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("202","0","7","2","41","15140","15140","15378.2","238.2","0","15378.2","238.2","0","1315785326","113.218.95.63");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("203","0","57","2","41","40000","40000","40629.33","629.33","0","40629.33","629.33","0","1315823358","113.218.198.239");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("204","0","57","1","30","1369","1368","1418.46","50.46","0","1418.46","50.46","0","1315823387","113.218.198.239");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("205","0","57","1","29","1312","1312","1360.41","48.41","0","1360.41","48.41","0","1315823428","113.218.198.239");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("206","0","58","2","41","50000","50000","50786.67","786.67","0","50786.67","786.67","0","1315823831","113.218.198.239");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("207","0","22","2","41","1076.07","1076.07","1093","16.93","0","1093","16.93","0","1315936171","113.65.153.19");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("208","0","14","2","41","2561.80","2561.80","2602.11","40.31","0","2602.11","40.31","0","1315936200","113.65.153.19");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("209","0","18","2","41","1184.62","1184.62","1203.26","18.64","0","1203.26","18.64","0","1315936252","113.65.153.19");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("210","0","16","2","41","2368.00","2368.00","2405.26","37.26","0","2405.26","37.26","0","1315936337","113.65.153.19");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("211","0","24","2","41","1057.00","1057.00","1073.63","16.63","0","1073.63","16.63","0","1315936420","113.65.153.19");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("212","0","19","2","41","1162.00","1162.00","1180.28","18.28","0","1180.28","18.28","0","1315936455","113.65.153.19");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("213","0","23","2","41","1061.00","1061.00","1077.69","16.69","0","1077.69","16.69","0","1315936505","113.65.153.19");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("214","0","26","2","41","1057.00","1057.00","1073.63","16.63","0","1073.63","16.63","0","1315936575","113.65.153.19");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("215","0","64","1","43","100","100","104.04","4.04","0","104.04","4.04","0","1318777198","117.93.29.70");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("216","0","64","1","42","200","200","205.62","5.62","0","205.62","5.62","0","1318777274","117.93.29.70");

insert into `dw_borrow_tender` ( `id`,`site_id`,`user_id`,`status`,`borrow_id`,`money`,`account`,`repayment_account`,`interest`,`repayment_yesaccount`,`wait_account`,`wait_interest`,`repayment_yesinterest`,`addtime`,`addip`) values ("217","0","65","1","44","5000","5000","5344.32","344.32","0","5344.32","344.32","0","1318814536","117.93.22.200");

