insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1","����","beijing","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2","������","beijingshi","1","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3","������","dongchengqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("4","������","xichengqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("5","������","chongwenqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("6","������","xuanwuqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("7","������","chaoyangqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("8","��̨��","fengtaiqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("9","ʯ��ɽ��","shijingshanqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("10","������","haidianqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("11","��ͷ����","mentougouqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("12","��ɽ��","fangshanqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("13","ͨ����","tongzhouqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("14","˳����","shunyiqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("15","��ƽ��","changpingqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("16","������","daxingqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("17","������","huairouqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("18","ƽ����","pingguqu","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("19","������","miyunxian","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("20","������","yanqingxian","2","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("21","���","tianjin","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("22","�����","tianjinshi","21","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("23","��ƽ��","hepingqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("24","�Ӷ���","hedongqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("25","������","hexiqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("26","�Ͽ���","nankaiqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("27","�ӱ���","hebeiqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("28","������","hongqiaoqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("29","������","tangguqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("30","������","hanguqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("31","�����","dagangqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("32","������","dongliqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("33","������","xiqingqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("34","������","jinnanqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("35","������","beichenqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("36","������","wuqingqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("37","������","baoqu","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("38","������","jinghaixian","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("39","����","jixian","22","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("40","�Ϻ�","shanghai","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("41","�Ϻ���","shanghaishi","40","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("42","������","huangpuqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("43","¬����","luwanqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("44","�����","xuhuiqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("45","������","changningqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("46","������","jinganqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("47","������","putuoqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("48","բ����","zhabeiqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("49","�����","hongkouqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("50","������","yangpuqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("51","������","xingqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("52","��ɽ��","baoshanqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("53","�ζ���","jiadingqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("54","�ֶ�����","pudongxinqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("55","��ɽ��","jinshanqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("56","�ɽ���","songjiangqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("57","������","qingpuqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("58","�ϻ���","nanhuiqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("59","������","fengxianqu","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("60","������","chongmingxian","41","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("61","����","zhongqing","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("62","������","zhongqingshi","61","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("63","������","wanzhouqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("64","������","fulingqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("65","������","yuzhongqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("66","��ɿ���","dadukouqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("67","������","jiangbeiqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("68","ɳƺ����","shapingbaqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("69","��������","jiulongpoqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("70","�ϰ���","nananqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("71","������","beiqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("72","��ʢ��","wanshengqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("73","˫����","shuangqiaoqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("74","�山��","yubeiqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("75","������","bananqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("76","ǭ����","qianjiangqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("77","������","changshouqu","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("78","������","nanxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("79","ͭ����","tongliangxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("80","������","dazuxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("81","�ٲ���","rongchangxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("82","�ɽ��","shanxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("83","��ƽ��","liangpingxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("84","�ǿ���","chengkouxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("85","�ᶼ��","fengduxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("86","�潭��","dianjiangxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("87","��¡��","wulongxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("88","����","zhongxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("89","����","kaixian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("90","������","yunyangxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("91","�����","fengjiexian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("92","��ɽ��","wushanxian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("93","��Ϫ��","wuxixian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("94","ʯ��������������","shizhutujiazuzizhixian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("95","��ɽ����������������","xiushantujiazumiaozuzizhixian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("96","��������������������","youyangtujiazumiaozuzizhixian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("97","��ˮ����������������","pengshuimiaozutujiazuzizhixian","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("98","������","jiangjinshi","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("99","�ϴ���","hechuanshi","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("100","������","yongchuanshi","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("101","�ϴ���","nanchuanshi","62","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("102","�ӱ�ʡ","hebeisheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("103","ʯ��ׯ","shijiazhuang","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("104","��Ͻ��","shixiaqu","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("105","������","changanqu","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("106","�Ŷ���","qiaodongqu","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("107","������","qiaoxiqu","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("108","�»���","xinhuaqu","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("109","�������","jingkuangqu","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("110","ԣ����","yuhuaqu","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("111","������","jingxian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("112","������","zhengdingxian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("113","�����","chengxian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("114","������","xingtangxian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("115","������","lingshouxian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("116","������","gaoyixian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("117","������","shenzexian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("118","�޻���","zanhuangxian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("119","�޼���","wujixian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("120","ƽɽ��","pingshanxian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("121","Ԫ����","yuanshixian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("122","����","zhaoxian","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("123","������","xinjishi","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("124","޻����","chengshi","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("125","������","jinzhoushi","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("126","������","xinleshi","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("127","¹Ȫ��","luquanshi","103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("128","��ɽ","tangshan","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("129","��Ͻ��","shixiaqu","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("130","·����","lunanqu","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("131","·����","lubeiqu","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("132","��ұ��","guyequ","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("133","��ƽ��","kaipingqu","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("134","������","fengnanqu","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("135","������","fengrunqu","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("136","����","luanxian","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("137","������","luannanxian","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("138","��ͤ��","letingxian","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("139","Ǩ����","qianxixian","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("140","������","yutianxian","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("141","�ƺ���","tanghaixian","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("142","����","zunhuashi","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("143","Ǩ����","qiananshi","128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("144","�ػʵ�","qinhuangdao","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("145","��Ͻ��","shixiaqu","144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("146","������","haigangqu","144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("147","ɽ������","shanhaiguanqu","144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("148","��������","beidaihequ","144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("149","��������������","qinglongmanzuzizhixian","144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("150","������","changlixian","144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("151","������","funingxian","144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("152","¬����","lulongxian","144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("153","����","handan","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("154","��Ͻ��","shixiaqu","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("155","��ɽ��","hanshanqu","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("156","��̨��","congtaiqu","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("157","������","fuxingqu","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("158","������","fengfengkuangqu","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("159","������","handanxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("160","������","linzhangxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("161","�ɰ���","chenganxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("162","������","damingxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("163","����","shexian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("164","����","cixian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("165","������","feixiangxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("166","������","yongnianxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("167","����","qiuxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("168","������","jizexian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("169","��ƽ��","guangpingxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("170","������","guantaoxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("171","κ��","weixian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("172","������","quzhouxian","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("173","�䰲��","wuanshi","153","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("174","��̨","xingtai","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("175","��Ͻ��","shixiaqu","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("176","�Ŷ���","qiaodongqu","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("177","������","qiaoxiqu","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("178","��̨��","xingtaixian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("179","�ٳ���","linchengxian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("180","������","neiqiuxian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("181","������","baixiangxian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("182","¡Ң��","longyaoxian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("183","����","renxian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("184","�Ϻ���","nanhexian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("185","������","ningjinxian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("186","��¹��","juluxian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("187","�º���","xinhexian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("188","������","guangzongxian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("189","ƽ����","pingxiangxian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("190","����","weixian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("191","�����","qinghexian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("192","������","linxixian","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("193","�Ϲ���","nangongshi","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("194","ɳ����","shaheshi","174","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("195","����","baoding","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("196","��Ͻ��","shixiaqu","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("197","������","xinshiqu","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("198","������","beishiqu","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("199","������","nanshiqu","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("200","������","manchengxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("201","��Է��","qingyuanxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("202","�ˮ��","shuixian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("203","��ƽ��","fupingxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("204","��ˮ��","xushuixian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("205","������","dingxingxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("206","����","tangxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("207","������","gaoyangxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("208","�ݳ���","rongchengxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("209","�Դ��","yuanxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("210","������","wangduxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("211","������","anxinxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("212","����","yixian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("213","������","quyangxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("214","���","xian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("215","˳ƽ��","shunpingxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("216","��Ұ��","boyexian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("217","����","xiongxian","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("218","������","zhoushi","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("219","������","dingzhoushi","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("220","������","anguoshi","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("221","�߱�����","gaobeidianshi","195","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("222","�żҿ�","zhangjiakou","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("223","��Ͻ��","shixiaqu","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("224","�Ŷ���","qiaodongqu","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("225","������","qiaoxiqu","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("226","������","xuanhuaqu","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("227","�»�԰��","xiahuayuanqu","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("228","������","xuanhuaxian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("229","�ű���","zhangbeixian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("230","������","kangbaoxian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("231","��Դ��","guyuanxian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("232","������","shangyixian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("233","ε��","weixian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("234","��ԭ��","yangyuanxian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("235","������","huaianxian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("236","��ȫ��","wanquanxian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("237","������","huailaixian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("238","��¹��","luxian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("239","�����","chichengxian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("240","������","chonglixian","222","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("241","�е�","chengde","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("242","��Ͻ��","shixiaqu","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("243","˫����","shuangqiaoqu","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("244","˫����","shuangluanqu","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("245","ӥ��Ӫ�ӿ���","yingshouyingzikuangqu","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("246","�е���","chengdexian","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("247","��¡��","xinglongxian","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("248","ƽȪ��","pingquanxian","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("249","��ƽ��","luanpingxian","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("250","¡����","longhuaxian","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("251","��������������","fengningmanzuzizhixian","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("252","��������������","kuanchengmanzuzizhixian","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("253","Χ�������ɹ���������","weichangmanzumengguzuzizhixian","241","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("254","����","cangzhou","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("255","��Ͻ��","shixiaqu","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("256","�»���","xinhuaqu","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("257","�˺���","yunhequ","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("258","����","cangxian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("259","����","qingxian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("260","������","dongguangxian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("261","������","haixingxian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("262","��ɽ��","yanshanxian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("263","������","suningxian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("264","��Ƥ��","nanpixian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("265","������","wuqiaoxian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("266","����","xianxian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("267","�ϴ����������","mengcunhuizuzizhixian","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("268","��ͷ��","botoushi","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("269","������","renqiushi","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("270","������","huangshi","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("271","�Ӽ���","hejianshi","254","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("272","�ȷ�","langfang","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("273","��Ͻ��","shixiaqu","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("274","������","anciqu","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("275","������","guangyangqu","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("276","�̰���","guanxian","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("277","������","yongqingxian","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("278","�����","xianghexian","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("279","�����","dachengxian","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("280","�İ���","wenanxian","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("281","�󳧻���������","dachanghuizuzizhixian","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("282","������","bazhoushi","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("283","������","sanheshi","272","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("284","��ˮ","hengshui","102","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("285","��Ͻ��","shixiaqu","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("286","�ҳ���","taochengqu","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("287","��ǿ��","zaoqiangxian","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("288","������","wuyixian","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("289","��ǿ��","wuqiangxian","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("290","������","raoyangxian","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("291","��ƽ��","anpingxian","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("292","�ʳ���","guchengxian","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("293","����","jingxian","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("294","������","fuchengxian","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("295","������","jizhoushi","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("296","������","shenzhoushi","284","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("297","ɽ��ʡ","shanxisheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("298","̫ԭ","taiyuan","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("299","��Ͻ��","shixiaqu","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("300","С����","xiaodianqu","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("301","ӭ����","yingzequ","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("302","�ӻ�����","xinghualingqu","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("303","���ƺ��","jiancaopingqu","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("304","�������","wanbailinqu","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("305","��Դ��","jinyuanqu","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("306","������","qingxuxian","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("307","������","yangquxian","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("308","¦����","loufanxian","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("309","�Ž���","gujiaoshi","298","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("310","��ͬ","datong","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("311","��Ͻ��","shixiaqu","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("312","����","chengqu","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("313","����","kuangqu","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("314","�Ͻ���","nanjiaoqu","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("315","������","xinrongqu","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("316","������","yanggaoxian","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("317","������","tianzhenxian","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("318","������","guanglingxian","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("319","������","lingqiuxian","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("320","��Դ��","hunyuanxian","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("321","������","zuoyunxian","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("322","��ͬ��","datongxian","310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("323","��Ȫ","yangquan","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("324","��Ͻ��","shixiaqu","323","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("325","����","chengqu","323","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("326","����","kuangqu","323","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("327","����","jiaoqu","323","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("328","ƽ����","pingdingxian","323","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("329","����","yuxian","323","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("330","����","changzhi","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("331","��Ͻ��","shixiaqu","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("332","����","chengqu","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("333","����","jiaoqu","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("334","������","changzhixian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("335","��ԫ��","xiangyuanxian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("336","������","tunliuxian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("337","ƽ˳��","pingshunxian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("338","�����","lichengxian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("339","������","huguanxian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("340","������","changzixian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("341","������","wuxiangxian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("342","����","qinxian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("343","��Դ��","qinyuanxian","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("344","º����","luchengshi","330","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("345","����","jincheng","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("346","��Ͻ��","shixiaqu","345","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("347","����","chengqu","345","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("348","��ˮ��","qinshuixian","345","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("349","������","yangchengxian","345","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("350","�괨��","lingchuanxian","345","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("351","������","zezhouxian","345","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("352","��ƽ��","gaopingshi","345","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("353","˷��","shuozhou","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("354","��Ͻ��","shixiaqu","353","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("355","˷����","shuochengqu","353","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("356","ƽ³��","pingluqu","353","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("357","ɽ����","shanyinxian","353","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("358","Ӧ��","yingxian","353","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("359","������","youyuxian","353","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("360","������","huairenxian","353","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("361","����","jinzhong","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("362","��Ͻ��","shixiaqu","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("363","�ܴ���","yuciqu","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("364","������","yushexian","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("365","��Ȩ��","zuoquanxian","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("366","��˳��","heshunxian","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("367","������","xiyangxian","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("368","������","shouyangxian","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("369","̫����","taiguxian","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("370","����","qixian","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("371","ƽң��","pingyaoxian","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("372","��ʯ��","lingshixian","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("373","������","jiexiushi","361","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("374","�˳�","yuncheng","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("375","��Ͻ��","shixiaqu","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("376","�κ���","yanhuqu","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("377","�����","linxian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("378","������","wanrongxian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("379","��ϲ��","wenxixian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("380","�ɽ��","shanxian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("381","�����","xinxian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("382","���","xian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("383","ԫ����","yuanquxian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("384","����","xiaxian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("385","ƽ½��","pingluxian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("386","�ǳ���","chengxian","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("387","������","yongjishi","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("388","�ӽ���","hejinshi","374","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("389","����","xinzhou","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("390","��Ͻ��","shixiaqu","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("391","�ø���","xinfuqu","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("392","������","dingxiangxian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("393","��̨��","wutaixian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("394","����","daixian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("395","������","fanzhixian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("396","������","ningwuxian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("397","������","jinglexian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("398","�����","shenchixian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("399","��կ��","wuzhaixian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("400","����","xian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("401","������","hequxian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("402","������","baodexian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("403","ƫ����","pianguanxian","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("404","ԭƽ��","yuanpingshi","389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("405","�ٷ�","linfen","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("406","��Ͻ��","shixiaqu","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("407","Ң����","yaoduqu","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("408","������","quwoxian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("409","������","yichengxian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("410","�����","xiangfenxian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("411","�鶴��","hongdongxian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("412","����","guxian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("413","������","anzexian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("414","��ɽ��","fushanxian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("415","����","jixian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("416","������","xiangningxian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("417","������","daningxian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("418","����","xian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("419","������","yonghexian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("420","����","puxian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("421","������","fenxixian","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("422","������","houmashi","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("423","������","huozhoushi","405","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("424","����","lvliang","297","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("425","��Ͻ��","shixiaqu","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("426","��ʯ��","lishiqu","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("427","��ˮ��","wenshuixian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("428","������","jiaochengxian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("429","����","xingxian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("430","����","linxian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("431","������","liulinxian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("432","ʯ¥��","shilouxian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("433","���","xian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("434","��ɽ��","fangshanxian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("435","������","zhongyangxian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("436","������","jiaokouxian","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("437","Т����","xiaoyishi","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("438","������","fenyangshi","424","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("439","���ɹ���","neimengguqu","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("440","���ͺ���","huhehaote","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("441","��Ͻ��","shixiaqu","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("442","�³���","xinchengqu","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("443","������","huiminqu","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("444","��Ȫ��","yuquanqu","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("445","������","saihanqu","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("446","��Ĭ������","tumotezuoqi","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("447","�п�����","tuoketuoxian","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("448","���ָ����","helingeerxian","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("449","��ˮ����","qingshuihexian","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("450","�䴨��","wuchuanxian","440","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("451","��ͷ","baotou","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("452","��Ͻ��","shixiaqu","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("453","������","donghequ","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("454","��������","kundulunqu","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("455","��ɽ��","qingshanqu","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("456","ʯ����","shiguaiqu","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("457","���ƿ���","baiyunkuangqu","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("458","��ԭ��","jiuyuanqu","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("459","��Ĭ������","tumoteyouqi","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("460","������","guyangxian","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("461","�����ï����������","daerhanmaominganlianheqi","451","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("462","�ں�","wuhai","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("463","��Ͻ��","shixiaqu","462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("464","��������","haibowanqu","462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("465","������","hainanqu","462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("466","�ڴ���","wudaqu","462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("467","���","chifeng","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("468","��Ͻ��","shixiaqu","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("469","��ɽ��","hongshanqu","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("470","Ԫ��ɽ��","yuanbaoshanqu","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("471","��ɽ��","songshanqu","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("472","��³�ƶ�����","alukeerqinqi","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("473","��������","balinzuoqi","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("474","��������","balinyouqi","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("475","������","linxixian","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("476","��ʲ������","keshiketengqi","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("477","��ţ����","wengniuteqi","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("478","��������","kalaqinqi","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("479","������","ningchengxian","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("480","������","aohanqi","467","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("481","ͨ��","tongliao","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("482","��Ͻ��","shixiaqu","481","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("483","�ƶ�����","keerqinqu","481","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("484","�ƶ�����������","keerqinzuoyizhongqi","481","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("485","�ƶ�����������","keerqinzuoyihouqi","481","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("486","��³��","kailuxian","481","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("487","������","kulunqi","481","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("488","������","naimanqi","481","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("489","��³����","zhaluteqi","481","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("490","���ֹ�����","huolinguoleshi","481","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("491","������˹","eerduosi","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("492","��ʤ��","dongshengqu","491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("493","��������","dalateqi","491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("494","׼�����","zhungeerqi","491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("495","���п�ǰ��","etuokeqianqi","491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("496","���п���","etuokeqi","491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("497","������","hangjinqi","491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("498","������","wushenqi","491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("499","���������","yijinhuoluoqi","491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("500","���ױ���","hulunbeier","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("501","��Ͻ��","shixiaqu","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("502","��������","hailaerqu","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("503","������","arongqi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("504","Ī�����ߴ��Ӷ���������","molidawadawoerzuzizhiqi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("505","���״�������","elunchunzizhiqi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("506","���¿���������","ewenkezuzizhiqi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("507","�°Ͷ�����","chenbaerhuqi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("508","�°Ͷ�������","xinbaerhuzuoqi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("509","�°Ͷ�������","xinbaerhuyouqi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("510","��������","manzhoulishi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("511","����ʯ��","yakeshishi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("512","��������","zhalantunshi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("513","���������","eergunashi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("514","������","genheshi","500","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("515","�����׶�","bayannaoer","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("516","��Ͻ��","shixiaqu","515","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("517","�ٺ���","linhequ","515","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("518","��ԭ��","wuyuanxian","515","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("519","�����","kouxian","515","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("520","������ǰ��","wulateqianqi","515","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("521","����������","wulatezhongqi","515","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("522","�����غ���","wulatehouqi","515","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("523","��������","hangjinhouqi","515","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("524","�����첼","wulanchabu","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("525","��Ͻ��","shixiaqu","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("526","������","jiningqu","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("527","׿����","zhuozixian","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("528","������","huadexian","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("529","�̶���","shangduxian","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("530","�˺���","xinghexian","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("531","������","liangchengxian","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("532","���������ǰ��","chahaeryouyiqianqi","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("533","�������������","chahaeryouyizhongqi","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("534","�������������","chahaeryouyihouqi","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("535","��������","siziwangqi","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("536","������","fengzhenshi","524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("537","�˰���","xinganmeng","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("538","����������","wulanhaoteshi","537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("539","����ɽ��","aershanshi","537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("540","�ƶ�������ǰ��","keerqinyouyiqianqi","537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("541","�ƶ�����������","keerqinyouyizhongqi","537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("542","��������","zhateqi","537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("543","ͻȪ��","tuquanxian","537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("544","���ֹ�����","xilinguolemeng","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("545","����������","erlianhaoteshi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("546","���ֺ�����","xilinhaoteshi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("547","���͸���","abagaqi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("548","����������","sunitezuoqi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("549","����������","suniteyouqi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("550","������������","dongwuzhumuqinqi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("551","������������","xiwuzhumuqinqi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("552","̫������","taipusiqi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("553","�����","xianghuangqi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("554","�������","zhengxiangbaiqi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("555","������","zhenglanqi","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("556","������","duolunxian","544","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("557","��������","alashanmeng","439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("558","����������","alashanzuoqi","557","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("559","����������","alashanyouqi","557","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("560","�������","ejinaqi","557","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("561","����ʡ","liaoningsheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("562","����","shenyang","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("563","��Ͻ��","shixiaqu","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("564","��ƽ��","hepingqu","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("565","�����","shenhequ","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("566","����","dadongqu","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("567","�ʹ���","huangguqu","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("568","������","tiexiqu","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("569","�ռ�����","sujiatunqu","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("570","������","donglingqu","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("571","�³�����","xinchengziqu","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("572","�ں���","yuhongqu","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("573","������","liaozhongxian","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("574","��ƽ��","kangpingxian","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("575","������","fakuxian","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("576","������","xinminshi","562","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("577","����","dalian","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("578","��Ͻ��","shixiaqu","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("579","��ɽ��","zhongshanqu","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("580","������","xigangqu","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("581","ɳ�ӿ���","shahekouqu","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("582","�ʾ�����","ganjingziqu","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("583","��˳����","lvshunkouqu","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("584","������","jinzhouqu","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("585","������","changhaixian","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("586","�߷�����","wafangdianshi","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("587","��������","pulandianshi","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("588","ׯ����","zhuangheshi","577","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("589","��ɽ","anshan","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("590","��Ͻ��","shixiaqu","589","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("591","������","tiedongqu","589","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("592","������","tiexiqu","589","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("593","��ɽ��","lishanqu","589","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("594","ǧɽ��","qianshanqu","589","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("595","̨����","taianxian","589","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("596","�������������","yanmanzuzizhixian","589","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("597","������","haichengshi","589","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("598","��˳","fushun","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("599","��Ͻ��","shixiaqu","598","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("600","�¸���","xinfuqu","598","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("601","������","dongzhouqu","598","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("602","������","wanghuaqu","598","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("603","˳����","shunchengqu","598","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("604","��˳��","fushunxian","598","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("605","�±�����������","xinbinmanzuzizhixian","598","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("606","��ԭ����������","qingyuanmanzuzizhixian","598","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("607","��Ϫ","benxi","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("608","��Ͻ��","shixiaqu","607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("609","ƽɽ��","pingshanqu","607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("610","Ϫ����","xihuqu","607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("611","��ɽ��","mingshanqu","607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("612","�Ϸ���","nanfenqu","607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("613","��Ϫ����������","benximanzuzizhixian","607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("614","��������������","huanrenmanzuzizhixian","607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("615","����","dandong","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("616","��Ͻ��","shixiaqu","615","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("617","Ԫ����","yuanbaoqu","615","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("618","������","zhenxingqu","615","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("619","����","zhenanqu","615","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("620","��������������","kuandianmanzuzizhixian","615","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("621","������","donggangshi","615","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("622","�����","fengchengshi","615","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("623","����","jinzhou","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("624","��Ͻ��","shixiaqu","623","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("625","������","gutaqu","623","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("626","�����","linghequ","623","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("627","̫����","taihequ","623","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("628","��ɽ��","heishanxian","623","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("629","����","yixian","623","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("630","�躣��","linghaishi","623","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("631","������","beiningshi","623","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("632","Ӫ��","yingkou","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("633","��Ͻ��","shixiaqu","632","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("634","վǰ��","zhanqianqu","632","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("635","������","xishiqu","632","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("636","����Ȧ��","yuquanqu","632","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("637","�ϱ���","laobianqu","632","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("638","������","gaizhoushi","632","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("639","��ʯ����","dashiqiaoshi","632","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("640","����","fuxin","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("641","��Ͻ��","shixiaqu","640","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("642","������","haizhouqu","640","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("643","������","xinqiuqu","640","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("644","̫ƽ��","taipingqu","640","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("645","�������","qinghemenqu","640","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("646","ϸ����","xihequ","640","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("647","�����ɹ���������","fuxinmengguzuzizhixian","640","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("648","������","zhangwuxian","640","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("649","����","liaoyang","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("650","��Ͻ��","shixiaqu","649","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("651","������","baitaqu","649","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("652","��ʥ��","wenshengqu","649","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("653","��ΰ��","hongweiqu","649","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("654","��������","gongchanglingqu","649","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("655","̫�Ӻ���","taizihequ","649","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("656","������","liaoyangxian","649","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("657","������","dengtashi","649","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("658","�̽�","panjin","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("659","��Ͻ��","shixiaqu","658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("660","˫̨����","shuangtaiziqu","658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("661","��¡̨��","xinglongtaiqu","658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("662","������","dawaxian","658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("663","��ɽ��","panshanxian","658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("664","����","tieling","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("665","��Ͻ��","shixiaqu","664","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("666","������","yinzhouqu","664","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("667","�����","qinghequ","664","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("668","������","tielingxian","664","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("669","������","xifengxian","664","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("670","��ͼ��","changtuxian","664","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("671","����ɽ��","diaobingshanshi","664","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("672","��ԭ��","kaiyuanshi","664","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("673","����","chaoyang","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("674","��Ͻ��","shixiaqu","673","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("675","˫����","shuangtaqu","673","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("676","������","longchengqu","673","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("677","������","chaoyangxian","673","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("678","��ƽ��","jianpingxian","673","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("679","�����������ɹ���������","kalaqinzuoyimengguzuzizhixian","673","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("680","��Ʊ��","beipiaoshi","673","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("681","��Դ��","lingyuanshi","673","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("682","��«��","huludao","561","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("683","��Ͻ��","shixiaqu","682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("684","��ɽ��","lianshanqu","682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("685","������","longgangqu","682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("686","��Ʊ��","nanpiaoqu","682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("687","������","suizhongxian","682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("688","������","jianchangxian","682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("689","�˳���","xingchengshi","682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("690","����ʡ","jilinsheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("691","����","changchun","690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("692","��Ͻ��","shixiaqu","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("693","�Ϲ���","nanguanqu","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("694","������","kuanchengqu","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("695","������","chaoyangqu","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("696","������","erdaoqu","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("697","��԰��","lvyuanqu","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("698","˫����","shuangyangqu","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("699","ũ����","nonganxian","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("700","��̨��","jiutaishi","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("701","������","yushushi","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("702","�»���","dehuishi","691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("703","����","jilin","690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("704","��Ͻ��","shixiaqu","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("705","������","changyiqu","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("706","��̶��","longtanqu","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("707","��Ӫ��","chuanyingqu","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("708","������","fengmanqu","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("709","������","yongjixian","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("710","�Ժ���","heshi","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("711","�����","dianshi","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("712","������","shulanshi","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("713","��ʯ��","panshishi","703","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("714","��ƽ","siping","690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("715","��Ͻ��","shixiaqu","714","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("716","������","tiexiqu","714","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("717","������","tiedongqu","714","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("718","������","lishuxian","714","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("719","��ͨ����������","yitongmanzuzizhixian","714","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("720","��������","gongzhulingshi","714","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("721","˫����","shuangliaoshi","714","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("722","��Դ","liaoyuan","690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("723","��Ͻ��","shixiaqu","722","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("724","��ɽ��","longshanqu","722","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("725","������","xianqu","722","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("726","������","dongfengxian","722","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("727","������","dongliaoxian","722","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("728","ͨ��","tonghua","690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("729","��Ͻ��","shixiaqu","728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("730","������","dongchangqu","728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("731","��������","erdaojiangqu","728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("732","ͨ����","tonghuaxian","728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("733","������","huinanxian","728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("734","������","liuhexian","728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("735","÷�ӿ���","meihekoushi","728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("736","������","jianshi","728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("737","��ɽ","baishan","690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("738","��Ͻ��","shixiaqu","737","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("739","�˵�����","badaojiangqu","737","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("740","������","fusongxian","737","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("741","������","jingyuxian","737","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("742","���׳�����������","changbaichaoxianzuzizhixian","737","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("743","��Դ��","jiangyuanxian","737","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("744","�ٽ���","linjiangshi","737","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("745","��ԭ","songyuan","690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("746","��Ͻ��","shixiaqu","745","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("747","������","ningjiangqu","745","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("748","ǰ������˹�ɹ���������","qianguoerluosimengguzuzizhixian","745","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("749","������","changlingxian","745","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("750","Ǭ����","qiananxian","745","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("751","������","fuyuxian","745","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("752","�׳�","baicheng","690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("753","��Ͻ��","shixiaqu","752","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("754","䬱���","beiqu","752","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("755","������","zhenxian","752","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("756","ͨ����","tongyuxian","752","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("757","�����","nanshi","752","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("758","����","daanshi","752","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("759","�ӱ�������","yanbianzizhizhou","690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("760","�Ӽ���","yanjishi","759","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("761","ͼ����","tumenshi","759","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("762","�ػ���","dunhuashi","759","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("763","������","chunshi","759","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("764","������","longjingshi","759","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("765","������","helongshi","759","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("766","������","wangqingxian","759","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("767","��ͼ��","antuxian","759","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("768","������ʡ","heilongjiangsheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("769","������","haerbin","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("770","��Ͻ��","shixiaqu","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("771","������","daoliqu","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("772","�ϸ���","nangangqu","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("773","������","daowaiqu","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("774","�㷻��","xiangfangqu","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("775","������","dongliqu","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("776","ƽ����","pingfangqu","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("777","�ɱ���","songbeiqu","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("778","������","hulanqu","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("779","������","yilanxian","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("780","������","fangzhengxian","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("781","����","binxian","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("782","������","bayanxian","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("783","ľ����","mulanxian","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("784","ͨ����","tonghexian","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("785","������","yanshouxian","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("786","������","achengshi","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("787","˫����","shuangchengshi","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("788","��־��","shangzhishi","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("789","�峣��","wuchangshi","769","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("790","�������","qiqihaer","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("791","��Ͻ��","shixiaqu","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("792","��ɳ��","longshaqu","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("793","������","jianhuaqu","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("794","������","tiefengqu","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("795","����Ϫ��","angangxiqu","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("796","����������","fulaerjiqu","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("797","����ɽ��","nianzishanqu","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("798","÷��˹���Ӷ�����","meilisidawoerzuqu","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("799","������","longjiangxian","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("800","������","yianxian","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("801","̩����","tailaixian","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("802","������","gannanxian","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("803","��ԣ��","fuyuxian","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("804","��ɽ��","keshanxian","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("805","�˶���","kedongxian","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("806","��Ȫ��","baiquanxian","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("807","ګ����","heshi","790","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("808","����","jixi","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("809","��Ͻ��","shixiaqu","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("810","������","jiguanqu","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("811","��ɽ��","hengshanqu","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("812","�ε���","didaoqu","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("813","������","lishuqu","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("814","���Ӻ���","chengzihequ","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("815","��ɽ��","mashanqu","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("816","������","jidongxian","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("817","������","hulinshi","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("818","��ɽ��","mishanshi","808","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("819","�׸�","hegang","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("820","��Ͻ��","shixiaqu","819","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("821","������","xiangyangqu","819","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("822","��ũ��","gongnongqu","819","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("823","��ɽ��","nanshanqu","819","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("824","�˰���","xinganqu","819","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("825","��ɽ��","dongshanqu","819","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("826","��ɽ��","xingshanqu","819","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("827","�ܱ���","luobeixian","819","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("828","�����","suibinxian","819","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("829","˫Ѽɽ","shuangyashan","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("830","��Ͻ��","shixiaqu","829","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("831","��ɽ��","jianshanqu","829","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("832","�붫��","lingdongqu","829","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("833","�ķ�̨��","sifangtaiqu","829","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("834","��ɽ��","baoshanqu","829","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("835","������","jixianxian","829","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("836","������","youyixian","829","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("837","������","baoqingxian","829","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("838","�ĺ���","raohexian","829","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("839","����","daqing","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("840","��Ͻ��","shixiaqu","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("841","����ͼ��","saertuqu","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("842","������","longfengqu","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("843","�ú�·��","ranghuluqu","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("844","�����","honggangqu","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("845","��ͬ��","datongqu","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("846","������","zhaozhouxian","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("847","��Դ��","zhaoyuanxian","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("848","�ֵ���","lindianxian","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("849","�Ŷ������ɹ���������","duerbotemengguzuzizhixian","839","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("850","����","yichun","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("851","��Ͻ��","shixiaqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("852","������","yichunqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("853","�ϲ���","nanchaqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("854","�Ѻ���","youhaoqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("855","������","xilinqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("856","������","cuiluanqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("857","������","xinqingqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("858","��Ϫ��","meixiqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("859","��ɽ����","jinshantunqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("860","��Ӫ��","wuyingqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("861","��������","wumahequ","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("862","��������","tangwanghequ","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("863","������","dailingqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("864","��������","wuyilingqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("865","������","hongxingqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("866","�ϸ�����","shangganlingqu","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("867","������","jiayinxian","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("868","������","tielishi","850","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("869","��ľ˹","jiamusi","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("870","��Ͻ��","shixiaqu","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("871","������","yonghongqu","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("872","������","xiangyangqu","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("873","ǰ����","qianjinqu","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("874","������","dongfengqu","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("875","����","jiaoqu","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("876","������","nanxian","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("877","�봨��","chuanxian","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("878","��ԭ��","tangyuanxian","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("879","��Զ��","fuyuanxian","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("880","ͬ����","tongjiangshi","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("881","������","fujinshi","869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("882","��̨��","qitaihe","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("883","��Ͻ��","shixiaqu","882","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("884","������","xinxingqu","882","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("885","��ɽ��","taoshanqu","882","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("886","���Ӻ���","qiezihequ","882","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("887","������","bolixian","882","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("888","ĵ����","mudanjiang","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("889","��Ͻ��","shixiaqu","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("890","������","donganqu","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("891","������","yangmingqu","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("892","������","aiminqu","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("893","������","xianqu","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("894","������","dongningxian","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("895","�ֿ���","linkouxian","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("896","��Һ���","suifenheshi","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("897","������","hailinshi","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("898","������","ninganshi","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("899","������","mulengshi","888","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("900","�ں�","heihe","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("901","��Ͻ��","shixiaqu","900","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("902","������","aihuiqu","900","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("903","�۽���","nenjiangxian","900","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("904","ѷ����","xunkexian","900","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("905","������","sunwuxian","900","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("906","������","beianshi","900","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("907","���������","wudalianchishi","900","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("908","�绯","suihua","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("909","��Ͻ��","shixiaqu","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("910","������","beilinqu","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("911","������","wangkuixian","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("912","������","lanxixian","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("913","�����","qinggangxian","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("914","�찲��","qinganxian","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("915","��ˮ��","mingshuixian","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("916","������","suilengxian","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("917","������","andashi","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("918","�ض���","zhaodongshi","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("919","������","hailunshi","908","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("920","���˰������","daxinganlingdiqu","768","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("921","������","humaxian","920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("922","������","tahexian","920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("923","Į����","mohexian","920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("924","����ʡ","jiangsusheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("925","�Ͼ�","nanjing","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("926","��Ͻ��","shixiaqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("927","������","xuanwuqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("928","������","baixiaqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("929","�ػ���","qinhuaiqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("930","������","jianqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("931","��¥��","gulouqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("932","�¹���","xiaguanqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("933","�ֿ���","pukouqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("934","��ϼ��","qixiaqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("935","�껨̨��","yuhuataiqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("936","������","jiangningqu","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("937","������","liuhequ","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("938","��ˮ��","shuixian","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("939","�ߴ���","gaochunxian","925","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("940","����","wuxi","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("941","��Ͻ��","shixiaqu","940","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("942","�簲��","chonganqu","940","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("943","�ϳ���","nanchangqu","940","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("944","������","beitangqu","940","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("945","��ɽ��","xishanqu","940","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("946","��ɽ��","huishanqu","940","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("947","������","binhuqu","940","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("948","������","jiangyinshi","940","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("949","������","yixingshi","940","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("950","����","xuzhou","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("951","��Ͻ��","shixiaqu","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("952","��¥��","gulouqu","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("953","������","yunlongqu","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("954","������","jiuliqu","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("955","������","jiawangqu","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("956","Ȫɽ��","quanshanqu","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("957","����","fengxian","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("958","����","peixian","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("959","ͭɽ��","tongshanxian","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("960","�����","ningxian","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("961","������","xinyishi","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("962","������","zhoushi","950","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("963","����","changzhou","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("964","��Ͻ��","shixiaqu","963","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("965","������","tianningqu","963","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("966","��¥��","zhonglouqu","963","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("967","��������","qishuyanqu","963","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("968","�±���","xinbeiqu","963","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("969","�����","wujinqu","963","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("970","������","yangshi","963","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("971","��̳��","jintanshi","963","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("972","����","suzhou","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("973","��Ͻ��","shixiaqu","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("974","������","canglangqu","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("975","ƽ����","pingjiangqu","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("976","������","jinqu","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("977","������","huqiuqu","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("978","������","wuzhongqu","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("979","�����","xiangchengqu","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("980","������","changshushi","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("981","�żҸ���","zhangjiagangshi","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("982","��ɽ��","kunshanshi","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("983","�⽭��","wujiangshi","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("984","̫����","taicangshi","972","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("985","��ͨ","nantong","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("986","��Ͻ��","shixiaqu","985","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("987","�紨��","chongchuanqu","985","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("988","��բ��","gangzhaqu","985","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("989","������","haianxian","985","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("990","�綫��","rudongxian","985","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("991","������","qidongshi","985","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("992","�����","rugaoshi","985","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("993","ͨ����","tongzhoushi","985","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("994","������","haimenshi","985","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("995","���Ƹ�","lianyungang","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("996","��Ͻ��","shixiaqu","995","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("997","������","lianyunqu","995","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("998","������","xinpuqu","995","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("999","������","haizhouqu","995","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1000","������","ganyuxian","995","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1001","������","donghaixian","995","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1002","������","guanyunxian","995","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1003","������","guannanxian","995","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1004","����","huaian","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1005","��Ͻ��","shixiaqu","1004","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1006","�����","qinghequ","1004","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1007","������","chuzhouqu","1004","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1008","������","huaiyinqu","1004","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1009","������","qingpuqu","1004","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1010","��ˮ��","lianshuixian","1004","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1011","������","hongzexian","1004","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1012","������","xian","1004","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1013","�����","jinhuxian","1004","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1014","�γ�","yancheng","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1015","��Ͻ��","shixiaqu","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1016","ͤ����","tinghuqu","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1017","�ζ���","yanduqu","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1018","��ˮ��","xiangshuixian","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1019","������","binhaixian","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1020","������","funingxian","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1021","������","sheyangxian","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1022","������","jianhuxian","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1023","��̨��","dongtaishi","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1024","�����","dafengshi","1014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1025","����","yangzhou","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1026","��Ͻ��","shixiaqu","1025","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1027","������","guanglingqu","1025","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1028","������","jiangqu","1025","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1029","����","jiaoqu","1025","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1030","��Ӧ��","baoyingxian","1025","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1031","������","yizhengshi","1025","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1032","������","gaoyoushi","1025","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1033","������","jiangdushi","1025","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1034","��","zhenjiang","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1035","��Ͻ��","shixiaqu","1034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1036","������","jingkouqu","1034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1037","������","runzhouqu","1034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1038","��ͽ��","dantuqu","1034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1039","������","danyangshi","1034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1040","������","yangzhongshi","1034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1041","������","jurongshi","1034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1042","̩��","taizhou","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1043","��Ͻ��","shixiaqu","1042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1044","������","hailingqu","1042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1045","�߸���","gaogangqu","1042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1046","�˻���","xinghuashi","1042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1047","������","jingjiangshi","1042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1048","̩����","taixingshi","1042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1049","������","jiangyanshi","1042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1050","��Ǩ","suqian","924","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1051","��Ͻ��","shixiaqu","1050","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1052","�޳���","suchengqu","1050","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1053","��ԥ��","suyuqu","1050","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1054","������","yangxian","1050","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1055","������","yangxian","1050","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1056","������","hongxian","1050","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1057","�㽭ʡ","zhejiangsheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1058","����","hangzhou","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1059","��Ͻ��","shixiaqu","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1060","�ϳ���","shangchengqu","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1061","�³���","xiachengqu","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1062","������","jiangganqu","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1063","������","gongshuqu","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1064","������","xihuqu","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1065","������","binjiangqu","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1066","��ɽ��","xiaoshanqu","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1067","�ຼ��","yuhangqu","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1068","ͩ®��","tongluxian","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1069","������","chunanxian","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1070","������","jiandeshi","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1071","������","fuyangshi","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1072","�ٰ���","linanshi","1058","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1073","����","ningbo","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1074","��Ͻ��","shixiaqu","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1075","������","haishuqu","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1076","������","jiangdongqu","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1077","������","jiangbeiqu","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1078","������","beilunqu","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1079","����","zhenhaiqu","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1080","۴����","zhouqu","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1081","��ɽ��","xiangshanxian","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1082","������","ninghaixian","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1083","��Ҧ��","yuyaoshi","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1084","��Ϫ��","cixishi","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1085","���","fenghuashi","1073","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1086","����","wenzhou","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1087","��Ͻ��","shixiaqu","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1088","¹����","luchengqu","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1089","������","longwanqu","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1090","걺���","haiqu","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1091","��ͷ��","dongtouxian","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1092","������","yongjiaxian","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1093","ƽ����","pingyangxian","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1094","������","cangnanxian","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1095","�ĳ���","wenchengxian","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1096","̩˳��","taishunxian","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1097","����","ruianshi","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1098","������","leqingshi","1086","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1099","����","jiaxing","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1100","��Ͻ��","shixiaqu","1099","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1101","�����","xiuchengqu","1099","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1102","������","xiuzhouqu","1099","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1103","������","jiashanxian","1099","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1104","������","haiyanxian","1099","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1105","������","hainingshi","1099","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1106","ƽ����","pinghushi","1099","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1107","ͩ����","tongxiangshi","1099","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1108","����","huzhou","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1109","��Ͻ��","shixiaqu","1108","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1110","������","wuxingqu","1108","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1111","�����","nanqu","1108","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1112","������","deqingxian","1108","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1113","������","changxingxian","1108","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1114","������","anjixian","1108","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1115","����","shaoxing","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1116","��Ͻ��","shixiaqu","1115","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1117","Խ����","yuechengqu","1115","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1118","������","shaoxingxian","1115","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1119","�²���","xinchangxian","1115","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1120","������","zhushi","1115","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1121","������","shangyushi","1115","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1122","������","zhoushi","1115","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1123","��","jinhua","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1124","��Ͻ��","shixiaqu","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1125","�ĳ���","chengqu","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1126","����","jindongqu","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1127","������","wuyixian","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1128","�ֽ���","pujiangxian","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1129","�Ͱ���","pananxian","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1130","��Ϫ��","lanxishi","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1131","������","yiwushi","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1132","������","dongyangshi","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1133","������","yongkangshi","1123","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1134","����","zhou","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1135","��Ͻ��","shixiaqu","1134","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1136","�³���","kechengqu","1134","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1137","�齭��","jiangqu","1134","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1138","��ɽ��","changshanxian","1134","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1139","������","kaihuaxian","1134","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1140","������","longyouxian","1134","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1141","��ɽ��","jiangshanshi","1134","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1142","��ɽ","zhoushan","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1143","��Ͻ��","shixiaqu","1142","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1144","������","dinghaiqu","1142","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1145","������","putuoqu","1142","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1146","�ɽ��","shanxian","1142","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1147","������","xian","1142","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1148","̨��","taizhou","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1149","��Ͻ��","shixiaqu","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1150","������","jiaojiangqu","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1151","������","huangyanqu","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1152","·����","luqiaoqu","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1153","����","yuhuanxian","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1154","������","sanmenxian","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1155","��̨��","tiantaixian","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1156","�ɾ���","xianjuxian","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1157","������","wenlingshi","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1158","�ٺ���","linhaishi","1148","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1159","��ˮ","lishui","1057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1160","��Ͻ��","shixiaqu","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1161","������","lianduqu","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1162","������","qingtianxian","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1163","������","yunxian","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1164","�����","suichangxian","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1165","������","songyangxian","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1166","�ƺ���","yunhexian","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1167","��Ԫ��","qingyuanxian","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1168","�������������","jingningzuzizhixian","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1169","��Ȫ��","longquanshi","1159","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1170","����ʡ","anhuisheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1171","�Ϸ�","hefei","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1172","��Ͻ��","shixiaqu","1171","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1173","������","yaohaiqu","1171","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1174","®����","luyangqu","1171","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1175","��ɽ��","shushanqu","1171","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1176","������","baohequ","1171","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1177","������","changfengxian","1171","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1178","�ʶ���","feidongxian","1171","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1179","������","feixixian","1171","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1180","�ߺ�","wuhu","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1181","��Ͻ��","shixiaqu","1180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1182","������","jinghuqu","1180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1183","������","matangqu","1180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1184","������","xinwuqu","1180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1185","𯽭��","jiangqu","1180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1186","�ߺ���","wuhuxian","1180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1187","������","fanchangxian","1180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1188","������","nanlingxian","1180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1189","����","bangbu","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1190","��Ͻ��","shixiaqu","1189","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1191","���Ӻ���","longzihuqu","1189","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1192","��ɽ��","bangshanqu","1189","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1193","������","yuhuiqu","1189","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1194","������","huaishangqu","1189","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1195","��Զ��","huaiyuanxian","1189","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1196","�����","wuhexian","1189","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1197","������","guzhenxian","1189","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1198","����","huainan","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1199","��Ͻ��","shixiaqu","1198","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1200","��ͨ��","datongqu","1198","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1201","�������","tianjiaqu","1198","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1202","л�Ҽ���","xiejiajiqu","1198","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1203","�˹�ɽ��","bagongshanqu","1198","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1204","�˼���","panjiqu","1198","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1205","��̨��","fengtaixian","1198","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1206","����ɽ","maanshan","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1207","��Ͻ��","shixiaqu","1206","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1208","���ׯ��","jinjiazhuangqu","1206","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1209","��ɽ��","huashanqu","1206","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1210","��ɽ��","yushanqu","1206","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1211","��Ϳ��","dangtuxian","1206","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1212","����","huaibei","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1213","��Ͻ��","shixiaqu","1212","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1214","�ż���","dujiqu","1212","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1215","��ɽ��","xiangshanqu","1212","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1216","��ɽ��","lieshanqu","1212","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1217","�Ϫ��","xixian","1212","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1218","ͭ��","tongling","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1219","��Ͻ��","shixiaqu","1218","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1220","ͭ��ɽ��","tongguanshanqu","1218","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1221","ʨ��ɽ��","shizishanqu","1218","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1222","����","jiaoqu","1218","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1223","ͭ����","tonglingxian","1218","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1224","����","anqing","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1225","��Ͻ��","shixiaqu","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1226","ӭ����","yingjiangqu","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1227","�����","daguanqu","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1228","����","jiaoqu","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1229","������","huainingxian","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1230","������","yangxian","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1231","Ǳɽ��","qianshanxian","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1232","̫����","taihuxian","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1233","������","susongxian","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1234","������","wangjiangxian","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1235","������","yuexixian","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1236","ͩ����","tongchengshi","1224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1237","��ɽ","huangshan","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1238","��Ͻ��","shixiaqu","1237","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1239","��Ϫ��","tunxiqu","1237","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1240","��ɽ��","huangshanqu","1237","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1241","������","huizhouqu","1237","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1242","���","xian","1237","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1243","������","xiuningxian","1237","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1244","����","xian","1237","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1245","������","qimenxian","1237","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1246","����","chuzhou","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1247","��Ͻ��","shixiaqu","1246","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1248","������","langqu","1246","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1249","������","nanqu","1246","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1250","������","laianxian","1246","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1251","ȫ����","quanjiaoxian","1246","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1252","��Զ��","dingyuanxian","1246","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1253","������","fengyangxian","1246","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1254","�쳤��","tianchangshi","1246","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1255","������","mingguangshi","1246","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1256","����","fuyang","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1257","��Ͻ��","shixiaqu","1256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1258","�����","zhouqu","1256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1259","򣶫��","dongqu","1256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1260","�Ȫ��","quanqu","1256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1261","��Ȫ��","linquanxian","1256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1262","̫����","taihexian","1256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1263","������","funanxian","1256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1264","�����","shangxian","1256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1265","������","jieshoushi","1256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1266","����","suzhou","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1267","��Ͻ��","shixiaqu","1266","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1268","ܭ����","qiaoqu","1266","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1269","��ɽ��","shanxian","1266","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1270","����","xiaoxian","1266","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1271","�����","lingxian","1266","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1272","����","xian","1266","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1273","����","chaohu","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1274","��Ͻ��","shixiaqu","1273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1275","�ӳ���","juchaoqu","1273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1276","®����","lujiangxian","1273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1277","��Ϊ��","wuweixian","1273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1278","��ɽ��","hanshanxian","1273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1279","����","hexian","1273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1280","����","liuan","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1281","��Ͻ��","shixiaqu","1280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1282","����","jinanqu","1280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1283","ԣ����","yuanqu","1280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1284","����","shouxian","1280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1285","������","huoqiuxian","1280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1286","�����","shuchengxian","1280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1287","��կ��","jinzhaixian","1280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1288","��ɽ��","huoshanxian","1280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1289","����","zhou","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1290","��Ͻ��","shixiaqu","1289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1291","�۳���","chengqu","1289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1292","������","woyangxian","1289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1293","�ɳ���","mengchengxian","1289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1294","������","lixinxian","1289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1295","����","chizhou","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1296","��Ͻ��","shixiaqu","1295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1297","�����","guichiqu","1295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1298","������","dongzhixian","1295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1299","ʯ̨��","shitaixian","1295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1300","������","qingyangxian","1295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1301","����","xuancheng","1170","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1302","��Ͻ��","shixiaqu","1301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1303","������","xuanzhouqu","1301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1304","��Ϫ��","langxixian","1301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1305","�����","guangdexian","1301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1306","����","xian","1301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1307","��Ϫ��","jixixian","1301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1308","캵���","dexian","1301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1309","������","ningguoshi","1301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1310","����ʡ","fujiansheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1311","����","fuzhou","1310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1312","��Ͻ��","shixiaqu","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1313","��¥��","gulouqu","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1314","̨����","taijiangqu","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1315","��ɽ��","cangshanqu","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1316","��β��","maweiqu","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1317","������","jinanqu","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1318","������","minhouxian","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1319","������","lianjiangxian","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1320","��Դ��","luoyuanxian","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1321","������","minqingxian","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1322","��̩��","yongtaixian","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1323","ƽ̶��","pingtanxian","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1324","������","fuqingshi","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1325","������","changleshi","1311","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1326","����","xiamen","1310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1327","��Ͻ��","shixiaqu","1326","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1328","˼����","simingqu","1326","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1329","������","haicangqu","1326","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1330","������","huliqu","1326","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1331","������","jimeiqu","1326","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1332","ͬ����","tonganqu","1326","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1333","�谲��","xianganqu","1326","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1334","����","putian","1310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1335","��Ͻ��","shixiaqu","1334","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1336","������","chengxiangqu","1334","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1337","������","hanjiangqu","1334","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1338","�����","lichengqu","1334","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1339","������","xiuyuqu","1334","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1340","������","xianyouxian","1334","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1341","����","sanming","1310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1342","��Ͻ��","shixiaqu","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1343","÷����","meiliequ","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1344","��Ԫ��","sanyuanqu","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1345","��Ϫ��","mingxixian","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1346","������","qingliuxian","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1347","������","ninghuaxian","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1348","������","datianxian","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1349","��Ϫ��","youxixian","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1350","ɳ��","shaxian","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1351","������","jianglexian","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1352","̩����","tainingxian","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1353","������","jianningxian","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1354","������","yonganshi","1341","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1355","Ȫ��","quanzhou","1310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1356","��Ͻ��","shixiaqu","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1357","�����","lichengqu","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1358","������","fengzequ","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1359","�彭��","luojiangqu","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1360","Ȫ����","quangangqu","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1361","�ݰ���","huianxian","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1362","��Ϫ��","anxixian","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1363","������","yongchunxian","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1364","�»���","dehuaxian","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1365","������","jinmenxian","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1366","ʯʨ��","shishishi","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1367","������","jinjiangshi","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1368","�ϰ���","nananshi","1355","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1369","����","zhangzhou","1310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1370","��Ͻ��","shixiaqu","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1371","ܼ����","chengqu","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1372","������","longwenqu","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1373","������","yunxiaoxian","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1374","������","zhangpuxian","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1375","گ����","anxian","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1376","��̩��","changtaixian","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1377","��ɽ��","dongshanxian","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1378","�Ͼ���","nanjingxian","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1379","ƽ����","pinghexian","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1380","������","huaanxian","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1381","������","longhaishi","1369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1382","��ƽ","nanping","1310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1383","��Ͻ��","shixiaqu","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1384","��ƽ��","yanpingqu","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1385","˳����","shunchangxian","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1386","�ֳ���","puchengxian","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1387","������","guangzexian","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1388","��Ϫ��","songxixian","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1389","������","zhenghexian","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1390","������","shaowushi","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1391","����ɽ��","wuyishanshi","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1392","�����","jianshi","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1393","������","jianyangshi","1382","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1394","����","longyan","1310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1395","��Ͻ��","shixiaqu","1394","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1396","������","xinluoqu","1394","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1397","��͡��","changtingxian","1394","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1398","������","yongdingxian","1394","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1399","�Ϻ���","shanghangxian","1394","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1400","��ƽ��","wupingxian","1394","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1401","������","lianchengxian","1394","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1402","��ƽ��","zhangpingshi","1394","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1403","����","ningde","1310","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1404","��Ͻ��","shixiaqu","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1405","������","jiaochengqu","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1406","ϼ����","xiapuxian","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1407","������","gutianxian","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1408","������","pingnanxian","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1409","������","shouningxian","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1410","������","zhouningxian","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1411","������","rongxian","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1412","������","fuanshi","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1413","������","fudingshi","1403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1414","����ʡ","jiangxisheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1415","�ϲ�","nanchang","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1416","��Ͻ��","shixiaqu","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1417","������","donghuqu","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1418","������","xihuqu","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1419","��������","qingyunpuqu","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1420","������","wanliqu","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1421","��ɽ����","qingshanhuqu","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1422","�ϲ���","nanchangxian","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1423","�½���","xinjianxian","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1424","������","anyixian","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1425","������","jinxianxian","1415","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1426","������","jingdezhen","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1427","��Ͻ��","shixiaqu","1426","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1428","������","changjiangqu","1426","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1429","��ɽ��","zhushanqu","1426","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1430","������","fuliangxian","1426","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1431","��ƽ��","lepingshi","1426","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1432","Ƽ��","pingxiang","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1433","��Ͻ��","shixiaqu","1432","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1434","��Դ��","anyuanqu","1432","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1435","�涫��","xiangdongqu","1432","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1436","������","lianhuaxian","1432","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1437","������","shanglixian","1432","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1438","«Ϫ��","luxixian","1432","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1439","�Ž�","jiujiang","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1440","��Ͻ��","shixiaqu","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1441","®ɽ��","lushanqu","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1442","�����","yangqu","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1443","�Ž���","jiujiangxian","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1444","������","wuningxian","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1445","��ˮ��","xiushuixian","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1446","������","yongxiuxian","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1447","�°���","deanxian","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1448","������","xingzixian","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1449","������","duchangxian","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1450","������","hukouxian","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1451","������","pengzexian","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1452","�����","ruichangshi","1439","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1453","����","xinyu","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1454","��Ͻ��","shixiaqu","1453","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1455","��ˮ��","yushuiqu","1453","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1456","������","fenyixian","1453","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1457","ӥ̶","yingtan","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1458","��Ͻ��","shixiaqu","1457","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1459","�º���","yuehuqu","1457","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1460","�཭��","yujiangxian","1457","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1461","��Ϫ��","guixishi","1457","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1462","����","ganzhou","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1463","��Ͻ��","shixiaqu","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1464","�¹���","zhanggongqu","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1465","����","ganxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1466","�ŷ���","xinfengxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1467","������","dayuxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1468","������","shangyouxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1469","������","chongyixian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1470","��Զ��","anyuanxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1471","������","longnanxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1472","������","dingnanxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1473","ȫ����","quannanxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1474","������","ningduxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1475","�ڶ���","yuduxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1476","�˹���","xingguoxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1477","�����","huichangxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1478","Ѱ����","xunwuxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1479","ʯ����","shichengxian","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1480","�����","ruijinshi","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1481","�Ͽ���","nankangshi","1462","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1482","����","jian","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1483","��Ͻ��","shixiaqu","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1484","������","jizhouqu","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1485","��ԭ��","qingyuanqu","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1486","������","jianxian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1487","��ˮ��","jishuixian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1488","Ͽ����","xiajiangxian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1489","�¸���","xinganxian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1490","������","yongfengxian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1491","̩����","taihexian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1492","�촨��","suichuanxian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1493","����","wananxian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1494","������","anfuxian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1495","������","yongxinxian","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1496","����ɽ��","jinggangshanshi","1482","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1497","�˴�","yichun","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1498","��Ͻ��","shixiaqu","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1499","Ԭ����","yuanzhouqu","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1500","������","fengxinxian","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1501","������","wanzaixian","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1502","�ϸ���","shanggaoxian","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1503","�˷���","yifengxian","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1504","������","jinganxian","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1505","ͭ����","tongguxian","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1506","�����","fengchengshi","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1507","������","zhangshushi","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1508","�߰���","gaoanshi","1497","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1509","����","fuzhou","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1510","��Ͻ��","shixiaqu","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1511","�ٴ���","linchuanqu","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1512","�ϳ���","nanchengxian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1513","�质��","lichuanxian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1514","�Ϸ���","nanfengxian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1515","������","chongrenxian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1516","�ְ���","leanxian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1517","�˻���","yihuangxian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1518","��Ϫ��","jinxixian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1519","��Ϫ��","zixixian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1520","������","dongxiangxian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1521","�����","guangchangxian","1509","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1522","����","shangrao","1414","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1523","��Ͻ��","shixiaqu","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1524","������","xinzhouqu","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1525","������","shangraoxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1526","�����","guangfengxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1527","��ɽ��","yushanxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1528","Ǧɽ��","qianshanxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1529","�����","hengfengxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1530","߮����","yangxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1531","�����","yuganxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1532","۶����","yangxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1533","������","wannianxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1534","��Դ��","yuanxian","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1535","������","dexingshi","1522","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1536","ɽ��ʡ","shandongsheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1537","����","jinan","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1538","��Ͻ��","shixiaqu","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1539","������","lixiaqu","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1540","������","shizhongqu","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1541","������","huaiyinqu","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1542","������","tianqiaoqu","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1543","������","lichengqu","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1544","������","changqingqu","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1545","ƽ����","pingyinxian","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1546","������","jiyangxian","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1547","�̺���","shanghexian","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1548","������","zhangqiushi","1537","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1549","�ൺ","qingdao","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1550","��Ͻ��","shixiaqu","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1551","������","shinanqu","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1552","�б���","shibeiqu","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1553","�ķ���","sifangqu","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1554","�Ƶ���","huangdaoqu","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1555","��ɽ��","shanqu","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1556","�����","licangqu","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1557","������","chengyangqu","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1558","������","jiaozhoushi","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1559","��ī��","jimoshi","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1560","ƽ����","pingdushi","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1561","������","jiaonanshi","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1562","������","laixishi","1549","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1563","�Ͳ�","zibo","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1564","��Ͻ��","shixiaqu","1563","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1565","�ʹ���","zichuanqu","1563","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1566","�ŵ���","zhangdianqu","1563","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1567","��ɽ��","boshanqu","1563","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1568","������","linziqu","1563","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1569","�ܴ���","zhoucunqu","1563","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1570","��̨��","huantaixian","1563","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1571","������","gaoqingxian","1563","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1572","��Դ��","yiyuanxian","1563","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1573","��ׯ","zaozhuang","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1574","��Ͻ��","shixiaqu","1573","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1575","������","shizhongqu","1573","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1576","Ѧ����","xuechengqu","1573","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1577","ỳ���","chengqu","1573","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1578","̨��ׯ��","taierzhuangqu","1573","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1579","ɽͤ��","shantingqu","1573","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1580","������","zhoushi","1573","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1581","��Ӫ","dongying","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1582","��Ͻ��","shixiaqu","1581","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1583","��Ӫ��","dongyingqu","1581","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1584","�ӿ���","hekouqu","1581","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1585","������","kenlixian","1581","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1586","������","lijinxian","1581","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1587","������","guangraoxian","1581","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1588","��̨","yantai","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1589","��Ͻ��","shixiaqu","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1590","֥���","zhiqu","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1591","��ɽ��","fushanqu","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1592","Ĳƽ��","moupingqu","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1593","��ɽ��","laishanqu","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1594","������","changdaoxian","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1595","������","longkoushi","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1596","������","laiyangshi","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1597","������","laizhoushi","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1598","������","penglaishi","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1599","��Զ��","zhaoyuanshi","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1600","��ϼ��","qixiashi","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1601","������","haiyangshi","1588","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1602","Ϋ��","weifang","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1603","��Ͻ��","shixiaqu","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1604","Ϋ����","weichengqu","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1605","��ͤ��","hantingqu","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1606","������","fangziqu","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1607","������","kuiwenqu","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1608","������","linxian","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1609","������","changlexian","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1610","������","qingzhoushi","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1611","�����","zhuchengshi","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1612","�ٹ���","shouguangshi","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1613","������","anqiushi","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1614","������","gaomishi","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1615","������","changyishi","1602","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1616","����","jining","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1617","��Ͻ��","shixiaqu","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1618","������","shizhongqu","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1619","�γ���","renchengqu","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1620","΢ɽ��","weishanxian","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1621","��̨��","yutaixian","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1622","������","jinxiangxian","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1623","������","jiaxiangxian","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1624","������","shangxian","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1625","��ˮ��","shuixian","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1626","��ɽ��","liangshanxian","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1627","������","qufushi","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1628","������","zhoushi","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1629","�޳���","zouchengshi","1616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1630","̩��","taian","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1631","��Ͻ��","shixiaqu","1630","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1632","̩ɽ��","taishanqu","1630","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1633","�����","yuequ","1630","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1634","������","ningyangxian","1630","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1635","��ƽ��","dongpingxian","1630","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1636","��̩��","xintaishi","1630","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1637","�ʳ���","feichengshi","1630","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1638","����","weihai","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1639","��Ͻ��","shixiaqu","1638","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1640","������","huancuiqu","1638","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1641","�ĵ���","wendengshi","1638","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1642","�ٳ���","rongchengshi","1638","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1643","��ɽ��","rushanshi","1638","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1644","����","rizhao","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1645","��Ͻ��","shixiaqu","1644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1646","������","donggangqu","1644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1647","�ɽ��","shanqu","1644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1648","������","wulianxian","1644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1649","����","xian","1644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1650","����","laiwu","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1651","��Ͻ��","shixiaqu","1650","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1652","������","laichengqu","1650","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1653","�ֳ���","gangchengqu","1650","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1654","����","linyi","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1655","��Ͻ��","shixiaqu","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1656","��ɽ��","lanshanqu","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1657","��ׯ��","luozhuangqu","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1658","�Ӷ���","hedongqu","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1659","������","yinanxian","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1660","۰����","chengxian","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1661","��ˮ��","yishuixian","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1662","��ɽ��","cangshanxian","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1663","����","feixian","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1664","ƽ����","pingyixian","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1665","������","nanxian","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1666","������","mengyinxian","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1667","������","linxian","1654","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1668","����","dezhou","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1669","��Ͻ��","shixiaqu","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1670","�³���","dechengqu","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1671","����","lingxian","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1672","������","ningjinxian","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1673","������","qingyunxian","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1674","������","linyixian","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1675","�����","qihexian","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1676","ƽԭ��","pingyuanxian","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1677","�Ľ���","xiajinxian","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1678","�����","wuchengxian","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1679","������","lelingshi","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1680","������","yuchengshi","1668","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1681","�ĳ�","liaocheng","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1682","��Ͻ��","shixiaqu","1681","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1683","��������","dongchangfuqu","1681","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1684","������","yangguxian","1681","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1685","ݷ��","xian","1681","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1686","��ƽ��","pingxian","1681","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1687","������","dongaxian","1681","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1688","����","guanxian","1681","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1689","������","gaotangxian","1681","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1690","������","linqingshi","1681","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1691","����","binzhou","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1692","��Ͻ��","shixiaqu","1691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1693","������","binchengqu","1691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1694","������","huiminxian","1691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1695","������","yangxinxian","1691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1696","�����","wuxian","1691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1697","մ����","zhanhuaxian","1691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1698","������","boxingxian","1691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1699","��ƽ��","zoupingxian","1691","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1700","����","heze","1536","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1701","��Ͻ��","shixiaqu","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1702","ĵ����","mudanqu","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1703","����","caoxian","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1704","����","danxian","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1705","������","chengwuxian","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1706","��Ұ��","juyexian","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1707","۩����","chengxian","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1708","۲����","chengxian","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1709","������","dingtaoxian","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1710","������","dongmingxian","1700","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1711","����ʡ","henansheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1712","֣��","zhengzhou","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1713","��Ͻ��","shixiaqu","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1714","��ԭ��","zhongyuanqu","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1715","������","erqiqu","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1716","�ܳǻ�����","guanchenghuizuqu","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1717","��ˮ��","jinshuiqu","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1718","�Ͻ���","shangjiequ","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1719","��ɽ��","shanqu","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1720","��Ĳ��","zhongmouxian","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1721","������","gongyishi","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1722","������","yangshi","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1723","������","xinmishi","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1724","��֣��","xinzhengshi","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1725","�Ƿ���","dengfengshi","1712","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1726","����","kaifeng","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1727","��Ͻ��","shixiaqu","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1728","��ͤ��","longtingqu","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1729","˳�ӻ�����","shunhehuizuqu","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1730","��¥��","gulouqu","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1731","�Ϲ���","nanguanqu","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1732","����","jiaoqu","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1733","���","xian","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1734","ͨ����","tongxuxian","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1735","ξ����","weishixian","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1736","������","kaifengxian","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1737","������","lankaoxian","1726","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1738","����","luoyang","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1739","��Ͻ��","shixiaqu","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1740","�ϳ���","laochengqu","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1741","������","xigongqu","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1742","�ܺӻ�����","hehuizuqu","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1743","������","jianxiqu","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1744","������","jiliqu","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1745","������","luolongqu","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1746","�Ͻ���","mengjinxian","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1747","�°���","xinanxian","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1748","�ﴨ��","chuanxian","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1749","����","xian","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1750","������","ruyangxian","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1751","������","yiyangxian","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1752","������","luoningxian","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1753","������","yichuanxian","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1754","��ʦ��","shishi","1738","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1755","ƽ��ɽ","pingdingshan","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1756","��Ͻ��","shixiaqu","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1757","�»���","xinhuaqu","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1758","������","weidongqu","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1759","ʯ����","shilongqu","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1760","տ����","zhanhequ","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1761","������","baofengxian","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1762","Ҷ��","yexian","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1763","³ɽ��","lushanxian","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1764","ۣ��","xian","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1765","�����","wugangshi","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1766","������","ruzhoushi","1755","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1767","����","anyang","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1768","��Ͻ��","shixiaqu","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1769","�ķ���","wenfengqu","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1770","������","beiguanqu","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1771","����","yinduqu","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1772","������","longanqu","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1773","������","anyangxian","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1774","������","tangyinxian","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1775","����","huaxian","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1776","�ڻ���","neihuangxian","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1777","������","linzhoushi","1767","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1778","�ױ�","hebi","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1779","��Ͻ��","shixiaqu","1778","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1780","��ɽ��","heshanqu","1778","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1781","ɽ����","shanchengqu","1778","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1782","俱���","binqu","1778","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1783","����","junxian","1778","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1784","���","xian","1778","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1785","����","xinxiang","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1786","��Ͻ��","shixiaqu","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1787","������","hongqiqu","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1788","������","weibinqu","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1789","��Ȫ��","fengquanqu","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1790","��Ұ��","muyequ","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1791","������","xinxiangxian","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1792","�����","huojiaxian","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1793","ԭ����","yuanyangxian","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1794","�ӽ���","yanjinxian","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1795","������","fengqiuxian","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1796","��ԫ��","changyuanxian","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1797","������","weihuishi","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1798","������","huixianshi","1785","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1799","����","jiaozuo","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1800","��Ͻ��","shixiaqu","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1801","�����","jiefangqu","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1802","��վ��","zhongzhanqu","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1803","������","macunqu","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1804","ɽ����","shanyangqu","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1805","������","xiuwuxian","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1806","������","boaixian","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1807","������","wuxian","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1808","����","wenxian","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1809","��Դ��","jiyuanshi","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1810","������","qinyangshi","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1811","������","mengzhoushi","1799","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1812","���","yang","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1813","��Ͻ��","shixiaqu","1812","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1814","������","hualongqu","1812","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1815","�����","qingfengxian","1812","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1816","������","nanlexian","1812","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1817","����","fanxian","1812","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1818","̨ǰ��","taiqianxian","1812","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1819","�����","yangxian","1812","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1820","����","xuchang","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1821","��Ͻ��","shixiaqu","1820","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1822","κ����","weiduqu","1820","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1823","������","xuchangxian","1820","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1824","۳����","lingxian","1820","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1825","�����","xiangchengxian","1820","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1826","������","yuzhoushi","1820","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1827","������","changgeshi","1820","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1828","���","he","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1829","��Ͻ��","shixiaqu","1828","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1830","Դ����","yuanhuiqu","1828","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1831","۱����","chengqu","1828","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1832","������","zhaolingqu","1828","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1833","������","wuyangxian","1828","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1834","�����","linxian","1828","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1835","����Ͽ","sanmenxia","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1836","��Ͻ��","shixiaqu","1835","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1837","������","hubinqu","1835","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1838","�ų���","chixian","1835","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1839","����","shanxian","1835","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1840","¬����","lushixian","1835","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1841","������","yimashi","1835","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1842","�鱦��","lingbaoshi","1835","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1843","����","nanyang","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1844","��Ͻ��","shixiaqu","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1845","�����","wanchengqu","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1846","������","wolongqu","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1847","������","nanzhaoxian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1848","������","fangchengxian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1849","��Ͽ��","xixiaxian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1850","��ƽ��","zhenpingxian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1851","������","neixiangxian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1852","������","chuanxian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1853","������","sheqixian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1854","�ƺ���","tanghexian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1855","��Ұ��","xinyexian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1856","ͩ����","tongbaixian","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1857","������","dengzhoushi","1843","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1858","����","shangqiu","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1859","��Ͻ��","shixiaqu","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1860","��԰��","liangyuanqu","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1861","�����","yangqu","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1862","��Ȩ��","minquanxian","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1863","���","xian","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1864","������","ninglingxian","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1865","�ϳ���","chengxian","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1866","�ݳ���","yuchengxian","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1867","������","xiayixian","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1868","������","yongchengshi","1858","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1869","����","xinyang","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1870","��Ͻ��","shixiaqu","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1871","ʦ����","shihequ","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1872","ƽ����","pingqiaoqu","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1873","��ɽ��","luoshanxian","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1874","��ɽ��","guangshanxian","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1875","����","xinxian","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1876","�̳���","shangchengxian","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1877","��ʼ��","gushixian","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1878","�괨��","chuanxian","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1879","������","huaibinxian","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1880","Ϣ��","xixian","1869","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1881","�ܿ�","zhoukou","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1882","��Ͻ��","shixiaqu","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1883","������","chuanhuiqu","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1884","������","fugouxian","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1885","������","xihuaxian","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1886","��ˮ��","shangshuixian","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1887","������","shenqiuxian","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1888","������","danchengxian","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1889","������","huaiyangxian","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1890","̫����","taikangxian","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1891","¹����","luyixian","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1892","�����","xiangchengshi","1881","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1893","פ����","zhumadian","1711","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1894","��Ͻ��","shixiaqu","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1895","�����","chengqu","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1896","��ƽ��","xipingxian","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1897","�ϲ���","shangcaixian","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1898","ƽ����","pingyuxian","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1899","������","zhengyangxian","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1900","ȷɽ��","queshanxian","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1901","������","miyangxian","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1902","������","runanxian","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1903","��ƽ��","suipingxian","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1904","�²���","xincaixian","1893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1905","����ʡ","hubeisheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1906","�人","wuhan","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1907","��Ͻ��","shixiaqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1908","������","jianganqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1909","������","jianghanqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1910","�ǿ���","qiaokouqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1911","������","hanyangqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1912","�����","wuchangqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1913","��ɽ��","qingshanqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1914","��ɽ��","hongshanqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1915","��������","dongxihuqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1916","������","hannanqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1917","�̵���","caidianqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1918","������","jiangxiaqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1919","������","huangqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1920","������","xinzhouqu","1906","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1921","��ʯ","huangshi","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1922","��Ͻ��","shixiaqu","1921","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1923","��ʯ����","huangshigangqu","1921","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1924","����ɽ��","xisaishanqu","1921","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1925","��½��","xialuqu","1921","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1926","��ɽ��","tieshanqu","1921","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1927","������","yangxinxian","1921","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1928","��ұ��","dayeshi","1921","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1929","ʮ��","shiyan","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1930","��Ͻ��","shixiaqu","1929","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1931","é����","maojianqu","1929","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1932","������","zhangwanqu","1929","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1933","����","yunxian","1929","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1934","������","yunxixian","1929","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1935","��ɽ��","zhushanxian","1929","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1936","��Ϫ��","zhuxixian","1929","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1937","����","fangxian","1929","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1938","��������","danjiangkoushi","1929","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1939","�˲�","yichang","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1940","��Ͻ��","shixiaqu","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1941","������","xilingqu","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1942","��Ҹ���","wujiagangqu","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1943","�����","dianjunqu","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1944","�Vͤ��","tingqu","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1945","������","yilingqu","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1946","Զ����","yuananxian","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1947","��ɽ��","xingshanxian","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1948","������","guixian","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1949","����������������","changyangtujiazuzizhixian","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1950","���������������","wufengtujiazuzizhixian","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1951","�˶���","yidushi","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1952","������","dangyangshi","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1953","֦����","zhijiangshi","1939","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1954","�差","xiangfan","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1955","��Ͻ��","shixiaqu","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1956","�����","xiangchengqu","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1957","������","fanchengqu","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1958","������","xiangyangqu","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1959","������","nanzhangxian","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1960","�ȳ���","guchengxian","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1961","������","baokangxian","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1962","�Ϻӿ���","laohekoushi","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1963","������","zaoyangshi","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1964","�˳���","yichengshi","1954","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1965","����","ezhou","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1966","��Ͻ��","shixiaqu","1965","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1967","���Ӻ���","liangzihuqu","1965","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1968","������","huarongqu","1965","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1969","������","echengqu","1965","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1970","����","jingmen","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1971","��Ͻ��","shixiaqu","1970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1972","������","dongbaoqu","1970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1973","�޵���","duodaoqu","1970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1974","��ɽ��","jingshanxian","1970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1975","ɳ����","shayangxian","1970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1976","������","zhongxiangshi","1970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1977","Т��","xiaogan","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1978","��Ͻ��","shixiaqu","1977","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1979","Т����","xiaonanqu","1977","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1980","Т����","xiaochangxian","1977","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1981","������","dawuxian","1977","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1982","������","yunmengxian","1977","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1983","Ӧ����","yingchengshi","1977","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1984","��½��","anlushi","1977","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1985","������","hanchuanshi","1977","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1986","����","jingzhou","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1987","��Ͻ��","shixiaqu","1986","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1988","ɳ����","shashiqu","1986","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1989","������","jingzhouqu","1986","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1990","������","gonganxian","1986","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1991","������","jianlixian","1986","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1992","������","jianglingxian","1986","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1993","ʯ����","shishoushi","1986","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1994","�����","honghushi","1986","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1995","������","songzishi","1986","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1996","�Ƹ�","huanggang","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1997","��Ͻ��","shixiaqu","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1998","������","huangzhouqu","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("1999","�ŷ���","tuanfengxian","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2000","�찲��","honganxian","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2001","������","luotianxian","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2002","Ӣɽ��","yingshanxian","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2003","�ˮ��","shuixian","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2004","ޭ����","chunxian","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2005","��÷��","huangmeixian","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2006","�����","machengshi","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2007","��Ѩ��","wuxueshi","1996","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2008","����","xianning","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2009","��Ͻ��","shixiaqu","2008","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2010","�̰���","xiananqu","2008","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2011","������","jiayuxian","2008","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2012","ͨ����","tongchengxian","2008","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2013","������","chongyangxian","2008","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2014","ͨɽ��","tongshanxian","2008","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2015","�����","chibishi","2008","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2016","����","suizhou","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2017","��Ͻ��","shixiaqu","2016","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2018","������","zengduqu","2016","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2019","��ˮ��","guangshuishi","2016","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2020","��ʩ������","enshizizhizhou","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2021","��ʩ��","enshishi","2020","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2022","������","lichuanshi","2020","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2023","��ʼ��","jianshixian","2020","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2024","�Ͷ���","badongxian","2020","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2025","������","xuanenxian","2020","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2026","�̷���","xianfengxian","2020","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2027","������","laifengxian","2020","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2028","�׷���","hefengxian","2020","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2029","����ʡϽ��λ","hubeishengxiadanwei","1905","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2030","������","xiantaoshi","2029","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2031","Ǳ����","qianjiangshi","2029","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2032","������","tianmenshi","2029","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2033","��ũ������","shennongjialinqu","2029","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2034","����ʡ","hunansheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2035","��ɳ","changsha","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2036","��Ͻ��","shixiaqu","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2037","ܽ����","rongqu","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2038","������","tianxinqu","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2039","��´��","yueluqu","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2040","������","kaifuqu","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2041","�껨��","yuhuaqu","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2042","��ɳ��","changshaxian","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2043","������","wangchengxian","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2044","������","ningxiangxian","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2045","�����","yangshi","2035","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2046","����","zhuzhou","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2047","��Ͻ��","shixiaqu","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2048","������","hetangqu","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2049","«����","luqu","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2050","ʯ����","shifengqu","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2051","��Ԫ��","tianyuanqu","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2052","������","zhuzhouxian","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2053","����","xian","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2054","������","chalingxian","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2055","������","yanlingxian","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2056","������","lingshi","2046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2057","��̶","xiangtan","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2058","��Ͻ��","shixiaqu","2057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2059","�����","yuhuqu","2057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2060","������","yuetangqu","2057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2061","��̶��","xiangtanxian","2057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2062","������","xiangxiangshi","2057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2063","��ɽ��","shaoshanshi","2057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2064","����","hengyang","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2065","��Ͻ��","shixiaqu","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2066","������","zhuqu","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2067","�����","yanfengqu","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2068","ʯ����","shiguqu","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2069","������","zhengxiangqu","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2070","������","nanyuequ","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2071","������","hengyangxian","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2072","������","hengnanxian","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2073","��ɽ��","hengshanxian","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2074","�ⶫ��","hengdongxian","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2075","���","qidongxian","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2076","������","yangshi","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2077","������","changningshi","2064","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2078","����","shaoyang","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2079","��Ͻ��","shixiaqu","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2080","˫����","shuangqingqu","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2081","������","daxiangqu","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2082","������","beitaqu","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2083","�۶���","shaodongxian","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2084","������","xinshaoxian","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2085","������","shaoyangxian","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2086","¡����","longhuixian","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2087","������","dongkouxian","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2088","������","suiningxian","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2089","������","xinningxian","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2090","�ǲ�����������","chengbumiaozuzizhixian","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2091","�����","wugangshi","2078","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2092","����","yueyang","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2093","��Ͻ��","shixiaqu","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2094","����¥��","yueyanglouqu","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2095","��Ϫ��","yunxiqu","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2096","��ɽ��","junshanqu","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2097","������","yueyangxian","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2098","������","huarongxian","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2099","������","xiangyinxian","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2100","ƽ����","pingjiangxian","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2101","������","luoshi","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2102","������","linxiangshi","2092","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2103","����","changde","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2104","��Ͻ��","shixiaqu","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2105","������","wulingqu","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2106","������","dingchengqu","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2107","������","anxiangxian","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2108","������","hanshouxian","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2109","���","xian","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2110","�����","linxian","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2111","��Դ��","taoyuanxian","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2112","ʯ����","shimenxian","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2113","������","jinshishi","2103","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2114","�żҽ�","zhangjiajie","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2115","��Ͻ��","shixiaqu","2114","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2116","������","yongdingqu","2114","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2117","����Դ��","wulingyuanqu","2114","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2118","������","cilixian","2114","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2119","ɣֲ��","sangzhixian","2114","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2120","����","yiyang","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2121","��Ͻ��","shixiaqu","2120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2122","������","ziyangqu","2120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2123","��ɽ��","heshanqu","2120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2124","����","nanxian","2120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2125","�ҽ���","taojiangxian","2120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2126","������","anhuaxian","2120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2127","�佭��","jiangshi","2120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2128","����","chenzhou","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2129","��Ͻ��","shixiaqu","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2130","������","beihuqu","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2131","������","suxianqu","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2132","������","guiyangxian","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2133","������","yizhangxian","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2134","������","yongxingxian","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2135","�κ���","jiahexian","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2136","������","linwuxian","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2137","�����","ruchengxian","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2138","����","guidongxian","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2139","������","anrenxian","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2140","������","zixingshi","2128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2141","����","yongzhou","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2142","��Ͻ��","shixiaqu","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2143","֥ɽ��","zhishanqu","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2144","��ˮ̲��","lengshuitanqu","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2145","������","qiyangxian","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2146","������","donganxian","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2147","˫����","shuangpaixian","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2148","����","daoxian","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2149","������","jiangyongxian","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2150","��Զ��","ningyuanxian","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2151","��ɽ��","lanshanxian","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2152","������","xintianxian","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2153","��������������","jianghuayaozuzizhixian","2141","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2154","����","huaihua","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2155","��Ͻ��","shixiaqu","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2156","�׳���","hechengqu","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2157","�з���","zhongfangxian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2158","������","lingxian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2159","��Ϫ��","chenxixian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2160","������","puxian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2161","��ͬ��","huitongxian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2162","��������������","mayangmiaozuzizhixian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2163","�»ζ���������","xinhuangdongzuzizhixian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2164","�ƽ�����������","jiangdongzuzizhixian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2165","�������嶱��������","jingzhoumiaozudongzuzizhixian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2166","ͨ������������","tongdaodongzuzizhixian","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2167","�齭��","hongjiangshi","2154","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2168","¦��","loudi","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2169","��Ͻ��","shixiaqu","2168","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2170","¦����","louxingqu","2168","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2171","˫����","shuangfengxian","2168","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2172","�»���","xinhuaxian","2168","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2173","��ˮ����","lengshuijiangshi","2168","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2174","��Դ��","lianyuanshi","2168","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2175","����������","xiangxizizhizhou","2034","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2176","������","jishoushi","2175","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2177","��Ϫ��","xixian","2175","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2178","�����","fenghuangxian","2175","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2179","��ԫ��","huayuanxian","2175","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2180","������","baojingxian","2175","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2181","������","guzhangxian","2175","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2182","��˳��","yongshunxian","2175","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2183","��ɽ��","longshanxian","2175","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2184","�㶫ʡ","guangdongsheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2185","����","guangzhou","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2186","��Ͻ��","shixiaqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2187","��ɽ��","dongshanqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2188","������","liwanqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2189","Խ����","yuexiuqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2190","������","haizhuqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2191","�����","tianhequ","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2192","������","fangcunqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2193","������","baiyunqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2194","������","huangpuqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2195","��خ��","fanqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2196","������","huaduqu","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2197","������","zengchengshi","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2198","�ӻ���","conghuashi","2185","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2199","�ع�","shaoguan","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2200","��Ͻ��","shixiaqu","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2201","�佭��","wujiangqu","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2202","䥽���","jiangqu","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2203","������","qujiangqu","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2204","ʼ����","shixingxian","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2205","�ʻ���","renhuaxian","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2206","��Դ��","wengyuanxian","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2207","��Դ����������","ruyuanyaozuzizhixian","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2208","�·���","xinfengxian","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2209","�ֲ���","lechangshi","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2210","������","nanxiongshi","2199","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2211","����","shen","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2212","��Ͻ��","shixiaqu","2211","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2213","�޺���","luohuqu","2211","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2214","������","futianqu","2211","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2215","��ɽ��","nanshanqu","2211","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2216","������","baoanqu","2211","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2217","������","longgangqu","2211","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2218","������","yantianqu","2211","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2219","�麣","zhuhai","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2220","��Ͻ��","shixiaqu","2219","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2221","������","xiangzhouqu","2219","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2222","������","doumenqu","2219","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2223","������","jinwanqu","2219","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2224","��ͷ","shantou","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2225","��Ͻ��","shixiaqu","2224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2226","������","longhuqu","2224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2227","��ƽ��","jinpingqu","2224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2228","婽���","jiangqu","2224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2229","������","chaoyangqu","2224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2230","������","chaonanqu","2224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2231","�κ���","chenghaiqu","2224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2232","�ϰ���","nanaoxian","2224","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2233","��ɽ","foshan","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2234","��Ͻ��","shixiaqu","2233","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2235","������","chengqu","2233","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2236","�Ϻ���","nanhaiqu","2233","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2237","˳����","shundequ","2233","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2238","��ˮ��","sanshuiqu","2233","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2239","������","gaomingqu","2233","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2240","����","jiangmen","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2241","��Ͻ��","shixiaqu","2240","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2242","���","pengjiangqu","2240","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2243","������","jianghaiqu","2240","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2244","�»���","xinhuiqu","2240","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2245","̨ɽ��","taishanshi","2240","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2246","��ƽ��","kaipingshi","2240","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2247","��ɽ��","heshanshi","2240","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2248","��ƽ��","enpingshi","2240","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2249","տ��","zhanjiang","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2250","��Ͻ��","shixiaqu","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2251","�࿲��","chikanqu","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2252","ϼɽ��","xiashanqu","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2253","��ͷ��","potouqu","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2254","������","mazhangqu","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2255","��Ϫ��","suixixian","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2256","������","xuwenxian","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2257","������","lianjiangshi","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2258","������","leizhoushi","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2259","�⴨��","wuchuanshi","2249","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2260","ï��","maoming","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2261","��Ͻ��","shixiaqu","2260","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2262","ï����","maonanqu","2260","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2263","ï����","maogangqu","2260","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2264","�����","dianbaixian","2260","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2265","������","gaozhoushi","2260","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2266","������","huazhoushi","2260","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2267","������","xinyishi","2260","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2268","����","zhaoqing","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2269","��Ͻ��","shixiaqu","2268","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2270","������","duanzhouqu","2268","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2271","������","dinghuqu","2268","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2272","������","guangningxian","2268","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2273","������","huaijixian","2268","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2274","�⿪��","fengkaixian","2268","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2275","������","deqingxian","2268","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2276","��Ҫ��","gaoyaoshi","2268","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2277","�Ļ���","sihuishi","2268","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2278","����","huizhou","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2279","��Ͻ��","shixiaqu","2278","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2280","�ݳ���","huichengqu","2278","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2281","������","huiyangqu","2278","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2282","������","boluoxian","2278","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2283","�ݶ���","huidongxian","2278","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2284","������","longmenxian","2278","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2285","÷��","meizhou","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2286","��Ͻ��","shixiaqu","2285","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2287","÷����","meijiangqu","2285","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2288","÷��","meixian","2285","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2289","������","dapuxian","2285","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2290","��˳��","fengshunxian","2285","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2291","�廪��","wuhuaxian","2285","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2292","ƽԶ��","pingyuanxian","2285","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2293","������","jiaolingxian","2285","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2294","������","xingningshi","2285","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2295","��β","shanwei","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2296","��Ͻ��","shixiaqu","2295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2297","����","chengqu","2295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2298","������","haifengxian","2295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2299","½����","luhexian","2295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2300","½����","lufengshi","2295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2301","��Դ","heyuan","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2302","��Ͻ��","shixiaqu","2301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2303","Դ����","yuanchengqu","2301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2304","�Ͻ���","zijinxian","2301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2305","������","longchuanxian","2301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2306","��ƽ��","lianpingxian","2301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2307","��ƽ��","hepingxian","2301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2308","��Դ��","dongyuanxian","2301","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2309","����","yangjiang","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2310","��Ͻ��","shixiaqu","2309","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2311","������","jiangchengqu","2309","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2312","������","yangxixian","2309","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2313","������","yangdongxian","2309","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2314","������","yangchunshi","2309","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2315","��Զ","qingyuan","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2316","��Ͻ��","shixiaqu","2315","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2317","�����","qingchengqu","2315","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2318","�����","fogangxian","2315","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2319","��ɽ��","yangshanxian","2315","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2320","��ɽ׳������������","lianshanzhuangzuyaozuzizhixian","2315","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2321","��������������","liannanyaozuzizhixian","2315","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2322","������","qingxinxian","2315","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2323","Ӣ����","yingdeshi","2315","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2324","������","lianzhoushi","2315","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2325","��ݸ��","dongshi","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2326","��Ͻ��","shixiaqu","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2327","��ľͷ","zhangmutou","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2328","���","houjie","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2329","������","dongchengqu","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2330","�ϳ���","nanchengqu","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2331","������","xichengqu","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2332","��ƽ","changping","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2333","����","changan","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2334","ʯ��","shi","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2335","ʯ��","shilong","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2336","���","fenggang","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2337","�ƽ�","huangjiang","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2338","����","tangxia","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2339","��Ϫ","qingxi","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2340","��ɽ","chashan","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2341","ʯ��","shipai","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2342","��ʯ","qishi","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2343","��ͷ","qiaotou","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2344","л��","xiegang","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2345","����","dalang","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2346","弲�","bu","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2347","����","dongkeng","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2348","����","hengli","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2349","����ɽ","dalingshan","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2350","ɳ��","shatian","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2351","����","dao","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2352","�߈�","gao�die","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2353","��ţ��","wangniudun","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2354","����","zhongtang","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2355","��ӿ","mayong","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2356","��÷","hongmei","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2357","����","humen","2325","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2358","��ɽ��","zhongshanshi","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2359","��Ͻ��","shixiaqu","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2360","ʯ�","shi","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2361","����","xiqu","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2362","����","dongqu","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2363","����","nanqu","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2364","���","huoju","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2365","����","huangpu","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2366","��ɳ","fusha","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2367","����","sanjiao","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2368","����","minzhong","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2369","����","nanlang","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2370","���ɽ","wuguishan","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2371","��ܽ","ban","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2372","����","shenwan","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2373","̹��","tanzhou","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2374","����","guzhen","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2375","С�","xiao","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2376","����","dongsheng","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2377","����","dongfeng","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2378","��ͷ","nantou","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2379","����","henglan","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2380","��ӿ","dayong","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2381","ɳϪ","shaxi","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2382","����","sanxiang","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2383","�ۿ�","gangkou","2358","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2384","����","chaozhou","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2385","��Ͻ��","shixiaqu","2384","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2386","������","xiangqiaoqu","2384","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2387","������","chaoanxian","2384","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2388","��ƽ��","raopingxian","2384","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2389","����","jieyang","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2390","��Ͻ��","shixiaqu","2389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2391","�ų���","chengqu","2389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2392","�Ҷ���","jiedongxian","2389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2393","������","jiexixian","2389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2394","������","huilaixian","2389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2395","������","puningshi","2389","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2396","�Ƹ�","yunfu","2184","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2397","��Ͻ��","shixiaqu","2396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2398","�Ƴ���","yunchengqu","2396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2399","������","xinxingxian","2396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2400","������","yunanxian","2396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2401","�ư���","yunanxian","2396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2402","�޶���","luodingshi","2396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2403","������","guangxiqu","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2404","����","nanning","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2405","��Ͻ��","shixiaqu","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2406","������","xingningqu","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2407","������","qingxiuqu","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2408","������","jiangnanqu","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2409","��������","xixiangtangqu","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2410","������","liangqingqu","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2411","������","ningqu","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2412","������","wumingxian","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2413","¡����","longanxian","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2414","��ɽ��","mashanxian","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2415","������","shanglinxian","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2416","������","binyangxian","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2417","����","hengxian","2404","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2418","����","liuzhou","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2419","��Ͻ��","shixiaqu","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2420","������","chengzhongqu","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2421","�����","yufengqu","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2422","������","liunanqu","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2423","������","liubeiqu","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2424","������","liujiangxian","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2425","������","liuchengxian","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2426","¹կ��","luzhaixian","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2427","�ڰ���","ronganxian","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2428","��ˮ����������","rongshuimiaozuzizhixian","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2429","��������������","sanjiangdongzuzizhixian","2418","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2430","����","guilin","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2431","��Ͻ��","shixiaqu","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2432","�����","xiufengqu","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2433","������","diecaiqu","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2434","��ɽ��","xiangshanqu","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2435","������","qixingqu","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2436","��ɽ��","yanshanqu","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2437","��˷��","yangshuoxian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2438","�ٹ���","linguixian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2439","�鴨��","lingchuanxian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2440","ȫ����","quanzhouxian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2441","�˰���","xinganxian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2442","������","yongfuxian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2443","������","guanyangxian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2444","��ʤ����������","longshenggezuzizhixian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2445","��Դ��","ziyuanxian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2446","ƽ����","pinglexian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2447","������","lipuxian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2448","��������������","gongchengyaozuzizhixian","2430","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2449","����","wuzhou","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2450","��Ͻ��","shixiaqu","2449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2451","������","wanxiuqu","2449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2452","��ɽ��","dieshanqu","2449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2453","������","changzhouqu","2449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2454","������","cangwuxian","2449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2455","����","tengxian","2449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2456","��ɽ��","mengshanxian","2449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2457","�Ϫ��","xishi","2449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2458","����","beihai","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2459","��Ͻ��","shixiaqu","2458","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2460","������","haichengqu","2458","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2461","������","yinhaiqu","2458","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2462","��ɽ����","tieshangangqu","2458","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2463","������","hepuxian","2458","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2464","���Ǹ�","fangchenggang","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2465","��Ͻ��","shixiaqu","2464","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2466","�ۿ���","gangkouqu","2464","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2467","������","fangchengqu","2464","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2468","��˼��","shangsixian","2464","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2469","������","dongxingshi","2464","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2470","����","qinzhou","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2471","��Ͻ��","shixiaqu","2470","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2472","������","qinnanqu","2470","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2473","�ձ���","qinbeiqu","2470","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2474","��ɽ��","lingshanxian","2470","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2475","�ֱ���","pubeixian","2470","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2476","���","guigang","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2477","��Ͻ��","shixiaqu","2476","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2478","�۱���","gangbeiqu","2476","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2479","������","gangnanqu","2476","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2480","������","tangqu","2476","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2481","ƽ����","pingnanxian","2476","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2482","��ƽ��","guipingshi","2476","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2483","����","yulin","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2484","��Ͻ��","shixiaqu","2483","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2485","������","yuzhouqu","2483","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2486","����","rongxian","2483","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2487","½����","luchuanxian","2483","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2488","������","bobaixian","2483","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2489","��ҵ��","xingyexian","2483","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2490","������","beiliushi","2483","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2491","��ɫ","baise","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2492","��Ͻ��","shixiaqu","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2493","�ҽ���","youjiangqu","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2494","������","tianyangxian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2495","�ﶫ��","tiandongxian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2496","ƽ����","pingguoxian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2497","�±���","debaoxian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2498","������","jingxixian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2499","������","napoxian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2500","������","lingyunxian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2501","��ҵ��","leyexian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2502","������","tianlinxian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2503","������","xilinxian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2504","¡�ָ���������","longlingezuzizhixian","2491","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2505","����","hezhou","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2506","��Ͻ��","shixiaqu","2505","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2507","�˲���","babuqu","2505","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2508","��ƽ��","zhaopingxian","2505","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2509","��ɽ��","zhongshanxian","2505","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2510","��������������","fuchuanyaozuzizhixian","2505","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2511","�ӳ�","hechi","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2512","��Ͻ��","shixiaqu","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2513","��ǽ���","jinchengjiangqu","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2514","�ϵ���","nandanxian","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2515","�����","tianexian","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2516","��ɽ��","fengshanxian","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2517","������","donglanxian","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2518","�޳�������������","luochenglaozuzizhixian","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2519","����ë����������","huanjiangmaonanzuzizhixian","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2520","��������������","bamayaozuzizhixian","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2521","��������������","duanyaozuzizhixian","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2522","������������","dahuayaozuzizhixian","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2523","������","yizhoushi","2511","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2524","����","laibin","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2525","��Ͻ��","shixiaqu","2524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2526","�˱���","xingbinqu","2524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2527","�ó���","xinchengxian","2524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2528","������","xiangzhouxian","2524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2529","������","wuxuanxian","2524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2530","��������������","jinxiuyaozuzizhixian","2524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2531","��ɽ��","heshanshi","2524","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2532","����","chongzuo","2403","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2533","��Ͻ��","shixiaqu","2532","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2534","������","jiangzhouqu","2532","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2535","������","fusuixian","2532","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2536","������","ningmingxian","2532","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2537","������","longzhouxian","2532","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2538","������","daxinxian","2532","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2539","�����","tiandengxian","2532","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2540","ƾ����","pingxiangshi","2532","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2541","����ʡ","hainansheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2542","����","haikou","2541","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2543","��Ͻ��","shixiaqu","2542","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2544","��Ӣ��","xiuyingqu","2542","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2545","������","longhuaqu","2542","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2546","��ɽ��","qiongshanqu","2542","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2547","������","meilanqu","2542","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2548","����","sanya","2541","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2549","��Ͻ��","shixiaqu","2548","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2550","����ֱϽ��","hainanzhixiaxian","2541","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2551","��ָɽ��","wuzhishanshi","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2552","������","qionghaishi","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2553","������","zhoushi","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2554","�Ĳ���","wenchangshi","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2555","������","wanningshi","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2556","������","dongfangshi","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2557","������","dinganxian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2558","�Ͳ���","tunchangxian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2559","������","chengmaixian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2560","�ٸ���","lingaoxian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2561","��ɳ����������","baishalizuzizhixian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2562","��������������","changjianglizuzizhixian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2563","�ֶ�����������","ledonglizuzizhixian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2564","��ˮ����������","lingshuilizuzizhixian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2565","��ͤ��������������","baotinglizumiaozuzizhixian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2566","������������������","qiongzhonglizumiaozuzizhixian","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2567","��ɳȺ��","xishaqundao","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2568","��ɳȺ��","nanshaqundao","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2569","��ɳȺ���ĵ������亣��","zhongshaqundaodedaojiaojiqihaiyu","2550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2570","�Ĵ�ʡ","sichuansheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2571","�ɶ�","chengdu","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2572","��Ͻ��","shixiaqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2573","������","jinjiangqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2574","������","qingyangqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2575","��ţ��","jinniuqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2576","�����","wuhouqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2577","�ɻ���","chenghuaqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2578","��Ȫ����","longquanqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2579","��׽���","qingbaijiangqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2580","�¶���","xinduqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2581","�½���","wenjiangqu","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2582","������","jintangxian","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2583","˫����","shuangliuxian","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2584","ۯ��","xian","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2585","������","dayixian","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2586","�ѽ���","pujiangxian","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2587","�½���","xinjinxian","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2588","��������","dujiangyanshi","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2589","������","pengzhoushi","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2590","������","shi","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2591","������","chongzhoushi","2571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2592","�Թ�","zigong","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2593","��Ͻ��","shixiaqu","2592","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2594","��������","ziliujingqu","2592","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2595","������","gongjingqu","2592","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2596","����","daanqu","2592","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2597","��̲��","yantanqu","2592","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2598","����","rongxian","2592","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2599","��˳��","fushunxian","2592","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2600","��֦��","panzhihua","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2601","��Ͻ��","shixiaqu","2600","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2602","����","dongqu","2600","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2603","����","xiqu","2600","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2604","�ʺ���","renhequ","2600","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2605","������","miyixian","2600","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2606","�α���","yanbianxian","2600","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2607","����","zhou","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2608","��Ͻ��","shixiaqu","2607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2609","������","jiangyangqu","2607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2610","��Ϫ��","naxiqu","2607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2611","����̶��","longmatanqu","2607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2612","����","xian","2607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2613","�Ͻ���","hejiangxian","2607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2614","������","xuyongxian","2607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2615","������","guxian","2607","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2616","����","deyang","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2617","��Ͻ��","shixiaqu","2616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2618","�����","yangqu","2616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2619","�н���","zhongjiangxian","2616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2620","�޽���","luojiangxian","2616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2621","�㺺��","guanghanshi","2616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2622","ʲ����","shishi","2616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2623","������","mianzhushi","2616","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2624","����","mianyang","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2625","��Ͻ��","shixiaqu","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2626","������","fuchengqu","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2627","������","youxianqu","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2628","��̨��","santaixian","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2629","��ͤ��","yantingxian","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2630","����","anxian","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2631","������","xian","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2632","����Ǽ��������","beichuanqiangzuzizhixian","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2633","ƽ����","pingwuxian","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2634","������","jiangyoushi","2624","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2635","��Ԫ","guangyuan","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2636","��Ͻ��","shixiaqu","2635","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2637","������","shizhongqu","2635","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2638","Ԫ����","yuanbaqu","2635","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2639","������","chaotianqu","2635","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2640","������","wangcangxian","2635","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2641","�ന��","qingchuanxian","2635","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2642","������","jiangexian","2635","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2643","��Ϫ��","cangxixian","2635","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2644","����","suining","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2645","��Ͻ��","shixiaqu","2644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2646","��ɽ��","chuanshanqu","2644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2647","������","anjuqu","2644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2648","��Ϫ��","pengxixian","2644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2649","�����","shehongxian","2644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2650","��Ӣ��","dayingxian","2644","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2651","�ڽ�","neijiang","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2652","��Ͻ��","shixiaqu","2651","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2653","������","shizhongqu","2651","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2654","������","dongxingqu","2651","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2655","��Զ��","weiyuanxian","2651","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2656","������","zizhongxian","2651","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2657","¡����","longchangxian","2651","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2658","��ɽ","leshan","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2659","��Ͻ��","shixiaqu","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2660","������","shizhongqu","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2661","ɳ����","shawanqu","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2662","��ͨ����","wutongqiaoqu","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2663","��ں���","jinkouhequ","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2664","��Ϊ��","weixian","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2665","������","jingyanxian","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2666","�н���","jiajiangxian","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2667","�崨��","chuanxian","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2668","�������������","ebianyizuzizhixian","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2669","��������������","mabianyizuzizhixian","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2670","��üɽ��","emeishanshi","2658","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2671","�ϳ�","nanchong","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2672","��Ͻ��","shixiaqu","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2673","˳����","shunqingqu","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2674","��ƺ��","gaopingqu","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2675","������","jialingqu","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2676","�ϲ���","nanbuxian","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2677","Ӫɽ��","yingshanxian","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2678","���","penganxian","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2679","��¤��","yilongxian","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2680","������","xichongxian","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2681","������","zhongshi","2671","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2682","üɽ","meishan","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2683","��Ͻ��","shixiaqu","2682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2684","������","dongpoqu","2682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2685","������","renshouxian","2682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2686","��ɽ��","pengshanxian","2682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2687","������","hongyaxian","2682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2688","������","danlengxian","2682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2689","������","qingshenxian","2682","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2690","�˱�","yibin","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2691","��Ͻ��","shixiaqu","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2692","������","cuipingqu","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2693","�˱���","yibinxian","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2694","��Ϫ��","nanxixian","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2695","������","jianganxian","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2696","������","changningxian","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2697","����","gaoxian","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2698","����","xian","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2699","������","lianxian","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2700","������","xingwenxian","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2701","��ɽ��","pingshanxian","2690","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2702","�㰲","guangan","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2703","��Ͻ��","shixiaqu","2702","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2704","�㰲��","guanganqu","2702","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2705","������","yuechixian","2702","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2706","��ʤ��","wushengxian","2702","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2707","��ˮ��","linshuixian","2702","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2708","��Ө��","huayingshi","2702","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2709","����","dazhou","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2710","��Ͻ��","shixiaqu","2709","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2711","ͨ����","tongchuanqu","2709","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2712","����","daxian","2709","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2713","������","xuanhanxian","2709","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2714","������","kaijiangxian","2709","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2715","������","dazhuxian","2709","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2716","����","quxian","2709","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2717","��Դ��","wanyuanshi","2709","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2718","�Ű�","yaan","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2719","��Ͻ��","shixiaqu","2718","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2720","�����","yuchengqu","2718","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2721","��ɽ��","mingshanxian","2718","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2722","������","jingxian","2718","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2723","��Դ��","hanyuanxian","2718","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2724","ʯ����","shimianxian","2718","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2725","��ȫ��","tianquanxian","2718","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2726","«ɽ��","lushanxian","2718","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2727","������","baoxingxian","2718","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2728","����","bazhong","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2729","��Ͻ��","shixiaqu","2728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2730","������","bazhouqu","2728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2731","ͨ����","tongjiangxian","2728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2732","�Ͻ���","nanjiangxian","2728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2733","ƽ����","pingchangxian","2728","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2734","����","ziyang","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2735","��Ͻ��","shixiaqu","2734","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2736","�㽭��","yanjiangqu","2734","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2737","������","anyuexian","2734","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2738","������","lezhixian","2734","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2739","������","jianyangshi","2734","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2740","����������","abazizhizhou","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2741","�봨��","chuanxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2742","����","lixian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2743","ï��","maoxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2744","������","songpanxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2745","��կ����","jiuzhaigouxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2746","����","jinchuanxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2747","С����","xiaojinxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2748","��ˮ��","heishuixian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2749","��������","maerkangxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2750","������","rangtangxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2751","������","abaxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2752","��������","ruoergaixian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2753","��ԭ��","hongyuanxian","2740","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2754","����������","ganzizizhizhou","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2755","������","kangdingxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2756","����","dingxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2757","������","danbaxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2758","������","jiulongxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2759","�Ž���","yajiangxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2760","������","daoxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2761","¯����","luhuoxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2762","������","ganzixian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2763","������","xinlongxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2764","�¸���","degexian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2765","������","baiyuxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2766","ʯ����","shiquxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2767","ɫ����","sedaxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2768","������","litangxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2769","������","batangxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2770","�����","xiangchengxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2771","������","daochengxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2772","������","derongxian","2754","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2773","��ɽ������","liangshanzizhizhou","2570","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2774","������","xichangshi","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2775","ľ�����������","mulicangzuzizhixian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2776","��Դ��","yanyuanxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2777","�²���","dechangxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2778","������","huilixian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2779","�ᶫ��","huidongxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2780","������","ningnanxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2781","�ո���","pugexian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2782","������","butuoxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2783","������","jinyangxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2784","�Ѿ���","zhaojuexian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2785","ϲ����","xidexian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2786","������","mianningxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2787","Խ����","yuexixian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2788","������","ganluoxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2789","������","meiguxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2790","�ײ���","leiboxian","2773","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2791","����ʡ","guizhousheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2792","����","guiyang","2791","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2793","��Ͻ��","shixiaqu","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2794","������","nanmingqu","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2795","������","yunyanqu","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2796","��Ϫ��","huaxiqu","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2797","�ڵ���","wudangqu","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2798","������","baiyunqu","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2799","С����","xiaohequ","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2800","������","kaiyangxian","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2801","Ϣ����","xifengxian","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2802","������","xiuwenxian","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2803","������","qingzhenshi","2792","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2804","����ˮ","liupanshui","2791","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2805","��ɽ��","zhongshanqu","2804","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2806","��֦����","liuzhitequ","2804","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2807","ˮ����","shuichengxian","2804","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2808","����","panxian","2804","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2809","����","zunyi","2791","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2810","��Ͻ��","shixiaqu","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2811","�컨����","honghuagangqu","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2812","�㴨��","huichuanqu","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2813","������","zunyixian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2814","ͩ����","tongxian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2815","������","suiyangxian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2816","������","zhenganxian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2817","��������������������","daozhenlaozumiaozuzizhixian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2818","������������������","wuchuanlaozumiaozuzizhixian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2819","�����","fenggangxian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2820","��̶��","tanxian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2821","������","yuqingxian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2822","ϰˮ��","xishuixian","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2823","��ˮ��","chishuishi","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2824","�ʻ���","renhuaishi","2809","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2825","��˳","anshun","2791","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2826","��Ͻ��","shixiaqu","2825","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2827","������","xixiuqu","2825","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2828","ƽ����","pingbaxian","2825","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2829","�ն���","pudingxian","2825","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2830","��������������������","zhenningbuyizumiaozuzizhixian","2825","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2831","���벼��������������","guanlingbuyizumiaozuzizhixian","2825","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2832","�������岼����������","ziyunmiaozubuyizuzizhixian","2825","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2833","ͭ�ʵ���","tongrendiqu","2791","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2834","ͭ����","tongrenshi","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2835","������","jiangkouxian","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2836","��������������","yupingdongzuzizhixian","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2837","ʯ����","shixian","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2838","˼����","sinanxian","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2839","ӡ������������������","yinjiangtujiazumiaozuzizhixian","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2840","�½���","dejiangxian","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2841","�غ�������������","yanhetujiazuzizhixian","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2842","��������������","songtaomiaozuzizhixian","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2843","��ɽ����","wanshantequ","2833","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2844","ǭ����������","qianxinanzizhizhou","2791","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2845","������","xingyishi","2844","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2846","������","xingrenxian","2844","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2847","�հ���","puanxian","2844","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2848","��¡��","qinglongxian","2844","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2849","�����","zhenfengxian","2844","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2850","������","wangxian","2844","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2851","�����","cehengxian","2844","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2852","������","anlongxian","2844","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2853","�Ͻڵ���","bijiediqu","2791","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2854","�Ͻ���","bijieshi","2853","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2855","����","dafangxian","2853","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2856","ǭ����","qianxixian","2853","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2857","��ɳ��","jinshaxian","2853","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2858","֯����","zhijinxian","2853","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2859","��Ӻ��","nayongxian","2853","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2860","���������������������","weiningyizuhuizumiaozuzizhixian","2853","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2861","������","hezhangxian","2853","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2862","ǭ����������","qiandongnanzizhizhou","2791","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2863","������","kailishi","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2864","��ƽ��","huangpingxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2865","ʩ����","shibingxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2866","������","sansuixian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2867","��Զ��","zhenyuanxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2868","᯹���","gongxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2869","������","tianzhuxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2870","������","jinpingxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2871","������","jianhexian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2872","̨����","taijiangxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2873","��ƽ��","lipingxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2874","�Ž���","jiangxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2875","�ӽ���","congjiangxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2876","��ɽ��","leishanxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2877","�齭��","majiangxian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2878","��կ��","danzhaixian","2862","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2879","ǭ��������","qiannanzizhizhou","2791","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2880","������","duyunshi","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2881","��Ȫ��","fuquanshi","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2882","����","liboxian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2883","����","guidingxian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2884","�Ͱ���","wenganxian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2885","��ɽ��","dushanxian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2886","ƽ����","pingtangxian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2887","�޵���","luodianxian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2888","��˳��","changshunxian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2889","������","longlixian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2890","��ˮ��","huishuixian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2891","����ˮ��������","sandushuizuzizhixian","2879","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2892","����ʡ","yunnansheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2893","����","kunming","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2894","��Ͻ��","shixiaqu","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2895","�廪��","wuhuaqu","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2896","������","panlongqu","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2897","�ٶ���","guanduqu","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2898","��ɽ��","xishanqu","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2899","������","dongchuanqu","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2900","�ʹ���","chenggongxian","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2901","������","jinningxian","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2902","������","fuminxian","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2903","������","yiliangxian","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2904","ʯ������������","shilinyizuzizhixian","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2905","������","mingxian","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2906","»Ȱ��������������","luquanyizumiaozuzizhixian","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2907","Ѱ���������������","xundianhuizuyizuzizhixian","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2908","������","anningshi","2893","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2909","����","qujing","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2910","��Ͻ��","shixiaqu","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2911","������","qu","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2912","������","malongxian","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2913","½����","luliangxian","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2914","ʦ����","shizongxian","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2915","��ƽ��","luopingxian","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2916","��Դ��","fuyuanxian","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2917","������","huizexian","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2918","մ����","zhanyixian","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2919","������","xuanweishi","2909","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2920","��Ϫ","yuxi","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2921","��Ͻ��","shixiaqu","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2922","������","hongtaqu","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2923","������","jiangchuanxian","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2924","�ν���","chengjiangxian","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2925","ͨ����","tonghaixian","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2926","������","huaningxian","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2927","������","yimenxian","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2928","��ɽ����������","eshanyizuzizhixian","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2929","��ƽ�������������","xinpingyizudaizuzizhixian","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2930","Ԫ���������������������","yuanjianghanizuyizudaizuzizhixian","2920","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2931","��ɽ","baoshan","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2932","��Ͻ��","shixiaqu","2931","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2933","¡����","longyangqu","2931","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2934","ʩ����","shidianxian","2931","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2935","�ڳ���","tengchongxian","2931","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2936","������","longlingxian","2931","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2937","������","changningxian","2931","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2938","��ͨ","zhaotong","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2939","��Ͻ��","shixiaqu","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2940","������","zhaoyangqu","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2941","³����","ludianxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2942","�ɼ���","qiaojiaxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2943","�ν���","yanjinxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2944","�����","daguanxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2945","������","yongshanxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2946","�罭��","suijiangxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2947","������","zhenxiongxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2948","������","yiliangxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2949","������","weixinxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2950","ˮ����","shuifuxian","2938","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2951","����","lijiang","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2952","��Ͻ��","shixiaqu","2951","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2953","�ų���","guchengqu","2951","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2954","����������������","yulongnaxizuzizhixian","2951","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2955","��ʤ��","yongshengxian","2951","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2956","��ƺ��","huapingxian","2951","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2957","��������������","ningyizuzizhixian","2951","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2958","˼é","simao","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2959","��Ͻ��","shixiaqu","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2960","������","cuiyunqu","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2961","�ն�����������������","puerhanizuyizuzizhixian","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2962","ī��������������","mojianghanizuzizhixian","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2963","��������������","jingdongyizuzizhixian","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2964","���ȴ�������������","jinggudaizuyizuzizhixian","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2965","�������������������������","zhenyizuhanizulazuzizhixian","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2966","���ǹ���������������","jiangchenghanizuyizuzizhixian","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2967","������������������������","mengliandaizulazuzuzizhixian","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2968","����������������","lancanglazuzizhixian","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2969","��������������","ximengzuzizhixian","2958","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2970","�ٲ�","lincang","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2971","��Ͻ��","shixiaqu","2970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2972","������","linxiangqu","2970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2973","������","fengqingxian","2970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2974","����","yunxian","2970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2975","������","yongdexian","2970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2976","����","zhenkangxian","2970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2977","˫�����������岼�������������","shuangjianglazuzubulangzudaizuzizhixian","2970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2978","������������������","gengmadaizuzuzizhixian","2970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2979","��Դ����������","cangyuanzuzizhixian","2970","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2980","����������","chuxiongzizhizhou","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2981","������","chuxiongshi","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2982","˫����","shuangbaixian","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2983","Ĳ����","moudingxian","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2984","�ϻ���","nanhuaxian","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2985","Ҧ����","yaoanxian","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2986","��Ҧ��","dayaoxian","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2987","������","yongrenxian","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2988","Ԫı��","yuanmouxian","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2989","�䶨��","wudingxian","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2990","»����","lufengxian","2980","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2991","���������","honghezizhizhou","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2992","������","gejiushi","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2993","��Զ��","kaiyuanshi","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2994","������","mengzixian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2995","��������������","pingbianmiaozuzizhixian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2996","��ˮ��","jianshuixian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2997","ʯ����","shipingxian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2998","������","milexian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("2999","������","xixian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3000","Ԫ����","yuanyangxian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3001","�����","honghexian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3002","��ƽ�����������������","jinpingmiaozuyaozudaizuzizhixian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3003","�̴���","lvchunxian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3004","�ӿ�����������","hekouyaozuzizhixian","2991","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3005","��ɽ������","wenshanzizhizhou","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3006","��ɽ��","wenshanxian","3005","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3007","��ɽ��","yanshanxian","3005","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3008","������","xichouxian","3005","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3009","��������","malipoxian","3005","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3010","������","maguanxian","3005","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3011","����","qiubeixian","3005","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3012","������","guangnanxian","3005","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3013","������","funingxian","3005","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3014","��˫������","xishuangbannazhou","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3015","������","jinghongshi","3014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3016","�º���","haixian","3014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3017","������","laxian","3014","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3018","����������","dalizizhizhou","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3019","������","dalishi","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3020","�������������","yangyizuzizhixian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3021","������","xiangyunxian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3022","������","binchuanxian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3023","�ֶ���","miduxian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3024","�Ͻ�����������","nanjianyizuzizhixian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3025","Ρɽ�������������","weishanyizuhuizuzizhixian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3026","��ƽ��","yongpingxian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3027","������","yunlongxian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3028","��Դ��","eryuanxian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3029","������","jianchuanxian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3030","������","heqingxian","3018","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3031","�º�������","dehongzizhizhou","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3032","������","ruilishi","3031","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3033","º����","luxishi","3031","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3034","������","lianghexian","3031","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3035","ӯ����","yingjiangxian","3031","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3036","¤����","longchuanxian","3031","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3037","ŭ����������","nujianglizizhizhou","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3038","��ˮ��","shuixian","3037","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3039","������","fugongxian","3037","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3040","��ɽ������ŭ��������","gongshandulongzunuzuzizhixian","3037","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3041","��ƺ����������������","lanpingbaizupumizuzizhixian","3037","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3042","����������","diqingzizhizhou","2892","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3043","���������","xianggelilaxian","3042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3044","������","deqinxian","3042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3045","ά��������������","weixilisuzuzizhixian","3042","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3046","������","xicangqu","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3047","����","lasa","3046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3048","��Ͻ��","shixiaqu","3047","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3049","�ǹ���","chengguanqu","3047","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3050","������","linzhouxian","3047","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3051","������","dangxiongxian","3047","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3052","��ľ��","nimuxian","3047","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3053","��ˮ��","qushuixian","3047","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3054","����������","duilongdeqingxian","3047","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3055","������","dazixian","3047","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3056","ī�񹤿���","mozhugongkaxian","3047","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3057","��������","changdudiqu","3046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3058","������","changduxian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3059","������","jiangdaxian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3060","������","gongjuexian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3061","��������","leiwuqixian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3062","������","dingqingxian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3063","������","chayaxian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3064","������","basuxian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3065","����","zuogongxian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3066","â����","mangkangxian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3067","��¡��","luolongxian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3068","�߰���","bianbaxian","3057","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3069","ɽ�ϵ���","shannandiqu","3046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3070","�˶���","naidongxian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3071","������","zhanangxian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3072","������","gonggaxian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3073","ɣ����","sangrixian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3074","������","qiongjiexian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3075","������","qusongxian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3076","������","cuomeixian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3077","������","luozhaxian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3078","�Ӳ���","jiachaxian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3079","¡����","longzixian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3080","������","cuonaxian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3081","�˿�����","langkazixian","3069","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3082","�տ������","rikazediqu","3046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3083","�տ�����","rikazeshi","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3084","��ľ����","nanmulinxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3085","������","jiangzixian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3086","������","dingrixian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3087","������","saxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3088","������","lazixian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3089","������","angrenxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3090","лͨ����","xietongmenxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3091","������","bailangxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3092","�ʲ���","renbuxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3093","������","kangmaxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3094","������","dingjiexian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3095","�ٰ���","zhongbaxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3096","�Ƕ���","yadongxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3097","��¡��","jilongxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3098","����ľ��","nielamuxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3099","������","sagaxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3100","�ڰ���","gangbaxian","3082","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3101","��������","naqudiqu","3046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3102","������","naquxian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3103","������","jialixian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3104","������","biruxian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3105","������","nierongxian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3106","������","anduoxian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3107","������","shenzhaxian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3108","����","suoxian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3109","�����","bangexian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3110","������","baqingxian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3111","������","nimaxian","3101","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3112","�������","alidiqu","3046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3113","������","pulanxian","3112","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3114","������","zhadaxian","3112","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3115","������","gaerxian","3112","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3116","������","rituxian","3112","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3117","�Ｊ��","gejixian","3112","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3118","������","gaizexian","3112","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3119","������","cuoqinxian","3112","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3120","��֥����","linzhidiqu","3046","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3121","��֥��","linzhixian","3120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3122","����������","gongbujiangdaxian","3120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3123","������","milinxian","3120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3124","ī����","motuoxian","3120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3125","������","bomixian","3120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3126","������","chayuxian","3120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3127","����","langxian","3120","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3128","����ʡ","shanxisheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3129","����","xian","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3130","��Ͻ��","shixiaqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3131","�³���","xinchengqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3132","������","beilinqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3133","������","lianhuqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3134","�����","qiaoqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3135","δ����","weiyangqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3136","������","yantaqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3137","������","yanliangqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3138","������","linqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3139","������","changanqu","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3140","������","lantianxian","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3141","������","zhouzhixian","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3142","����","huxian","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3143","������","gaolingxian","3129","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3144","ͭ��","tongchuan","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3145","��Ͻ��","shixiaqu","3144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3146","������","wangyiqu","3144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3147","ӡ̨��","yintaiqu","3144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3148","ҫ����","yaozhouqu","3144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3149","�˾���","yijunxian","3144","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3150","����","baoji","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3151","��Ͻ��","shixiaqu","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3152","μ����","weibinqu","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3153","��̨��","jintaiqu","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3154","�²���","chencangqu","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3155","������","fengxiangxian","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3156","�ɽ��","shanxian","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3157","������","fufengxian","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3158","ü��","meixian","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3159","¤��","longxian","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3160","ǧ����","qianyangxian","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3161","������","youxian","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3162","����","fengxian","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3163","̫����","taibaixian","3150","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3164","����","xianyang","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3165","��Ͻ��","shixiaqu","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3166","�ض���","qinduqu","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3167","������","yanglingqu","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3168","μ����","weichengqu","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3169","��ԭ��","sanyuanxian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3170","������","yangxian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3171","Ǭ��","qianxian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3172","��Ȫ��","liquanxian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3173","������","yongshouxian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3174","����","binxian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3175","������","changwuxian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3176","Ѯ����","xunyixian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3177","������","chunhuaxian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3178","�书��","wugongxian","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3179","��ƽ��","xingpingshi","3164","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3180","μ��","weinan","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3181","��Ͻ��","shixiaqu","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3182","��μ��","linweiqu","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3183","����","huaxian","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3184","������","guanxian","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3185","������","dalixian","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3186","������","heyangxian","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3187","�γ���","chengchengxian","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3188","�ѳ���","puchengxian","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3189","��ˮ��","baishuixian","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3190","��ƽ��","fupingxian","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3191","������","hanchengshi","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3192","������","huayinshi","3180","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3193","�Ӱ�","yanan","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3194","��Ͻ��","shixiaqu","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3195","������","baotaqu","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3196","�ӳ���","yanchangxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3197","�Ӵ���","yanchuanxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3198","�ӳ���","zichangxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3199","������","ansaixian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3200","־����","zhidanxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3201","������","wuqixian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3202","��Ȫ��","ganquanxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3203","����","fuxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3204","�崨��","luochuanxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3205","�˴���","yichuanxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3206","������","huanglongxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3207","������","huanglingxian","3193","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3208","����","hanzhong","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3209","��Ͻ��","shixiaqu","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3210","��̨��","hantaiqu","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3211","��֣��","nanzhengxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3212","�ǹ���","chengguxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3213","����","yangxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3214","������","xixiangxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3215","����","mianxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3216","��ǿ��","ningqiangxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3217","������","lueyangxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3218","�����","zhenbaxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3219","������","liubaxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3220","��ƺ��","fopingxian","3208","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3221","����","yulin","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3222","��Ͻ��","shixiaqu","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3223","������","yuyangqu","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3224","��ľ��","shenmuxian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3225","������","fuguxian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3226","��ɽ��","hengshanxian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3227","������","jingbianxian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3228","������","dingbianxian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3229","�����","suidexian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3230","��֬��","mizhixian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3231","����","jiaxian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3232","�Ɽ��","wubaoxian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3233","�彧��","qingjianxian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3234","������","zizhouxian","3221","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3235","����","ankang","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3236","��Ͻ��","shixiaqu","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3237","������","hanbinqu","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3238","������","hanyinxian","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3239","ʯȪ��","shiquanxian","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3240","������","ningshanxian","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3241","������","ziyangxian","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3242","᰸���","gaoxian","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3243","ƽ����","pinglixian","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3244","��ƺ��","zhenpingxian","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3245","Ѯ����","xunyangxian","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3246","�׺���","baihexian","3235","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3247","����","shangluo","3128","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3248","��Ͻ��","shixiaqu","3247","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3249","������","shangzhouqu","3247","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3250","������","luonanxian","3247","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3251","������","danfengxian","3247","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3252","������","shangnanxian","3247","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3253","ɽ����","shanyangxian","3247","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3254","����","zhenanxian","3247","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3255","��ˮ��","zuoshuixian","3247","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3256","����ʡ","gansusheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3257","����","lanzhou","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3258","��Ͻ��","shixiaqu","3257","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3259","�ǹ���","chengguanqu","3257","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3260","�������","qilihequ","3257","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3261","������","xiguqu","3257","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3262","������","anningqu","3257","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3263","�����","hongguqu","3257","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3264","������","yongdengxian","3257","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3265","������","gaolanxian","3257","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3266","������","yuzhongxian","3257","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3267","������","jiayuguan","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3268","��Ͻ��","shixiaqu","3267","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3269","���","jinchang","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3270","��Ͻ��","shixiaqu","3269","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3271","����","jinchuanqu","3269","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3272","������","yongchangxian","3269","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3273","����","baiyin","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3274","��Ͻ��","shixiaqu","3273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3275","������","baiyinqu","3273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3276","ƽ����","pingchuanqu","3273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3277","��Զ��","jingyuanxian","3273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3278","������","huiningxian","3273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3279","��̩��","jingtaixian","3273","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3280","��ˮ","tianshui","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3281","��Ͻ��","shixiaqu","3280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3282","�س���","qinchengqu","3280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3283","������","beidaoqu","3280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3284","��ˮ��","qingshuixian","3280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3285","�ذ���","qinanxian","3280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3286","�ʹ���","ganguxian","3280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3287","��ɽ��","wushanxian","3280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3288","�żҴ�����������","zhangjiachuanhuizuzizhixian","3280","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3289","����","wuwei","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3290","��Ͻ��","shixiaqu","3289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3291","������","liangzhouqu","3289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3292","������","minqinxian","3289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3293","������","gulangxian","3289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3294","��ף����������","tianzhucangzuzizhixian","3289","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3295","��Ҵ","zhangye","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3296","��Ͻ��","shixiaqu","3295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3297","������","ganzhouqu","3295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3298","����ԣ����������","sunanyuguzuzizhixian","3295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3299","������","minlexian","3295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3300","������","linzexian","3295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3301","��̨��","gaotaixian","3295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3302","ɽ����","shandanxian","3295","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3303","ƽ��","pingliang","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3304","��Ͻ��","shixiaqu","3303","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3305","�����","qu","3303","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3306","������","chuanxian","3303","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3307","��̨��","lingtaixian","3303","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3308","������","chongxinxian","3303","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3309","��ͤ��","huatingxian","3303","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3310","ׯ����","zhuanglangxian","3303","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3311","������","jingningxian","3303","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3312","��Ȫ","jiuquan","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3313","��Ͻ��","shixiaqu","3312","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3314","������","suzhouqu","3312","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3315","������","jintaxian","3312","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3316","������","anxixian","3312","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3317","�౱�ɹ���������","subeimengguzuzizhixian","3312","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3318","��������������������","akesaihasakezuzizhixian","3312","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3319","������","yumenshi","3312","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3320","�ػ���","dunhuangshi","3312","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3321","����","qingyang","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3322","��Ͻ��","shixiaqu","3321","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3323","������","xifengqu","3321","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3324","�����","qingchengxian","3321","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3325","����","huanxian","3321","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3326","������","huachixian","3321","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3327","��ˮ��","heshuixian","3321","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3328","������","zhengningxian","3321","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3329","����","ningxian","3321","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3330","��ԭ��","zhenyuanxian","3321","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3331","����","dingxi","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3332","��Ͻ��","shixiaqu","3331","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3333","������","andingqu","3331","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3334","ͨμ��","tongweixian","3331","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3335","¤����","longxixian","3331","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3336","μԴ��","weiyuanxian","3331","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3337","�����","linxian","3331","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3338","����","zhangxian","3331","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3339","���","xian","3331","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3340","¤��","longnan","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3341","��Ͻ��","shixiaqu","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3342","�䶼��","wuduqu","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3343","����","chengxian","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3344","����","wenxian","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3345","崲���","changxian","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3346","����","kangxian","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3347","������","xihexian","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3348","����","lixian","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3349","����","huixian","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3350","������","liangdangxian","3340","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3351","����������","linxiazizhizhou","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3352","������","linxiashi","3351","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3353","������","linxiaxian","3351","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3354","������","kanglexian","3351","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3355","������","yongjingxian","3351","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3356","�����","guanghexian","3351","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3357","������","hezhengxian","3351","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3358","������������","dongxiangzuzizhixian","3351","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3359","��ʯɽ�����嶫����������������","jishishanbaoanzudongxiangzusalazuzizhixian","3351","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3360","����������","gannanzizhizhou","3256","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3361","������","hezuoshi","3360","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3362","��̶��","lintanxian","3360","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3363","׿����","zhuonixian","3360","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3364","������","zhouquxian","3360","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3365","������","diebuxian","3360","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3366","������","maquxian","3360","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3367","µ����","luquxian","3360","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3368","�ĺ���","xiahexian","3360","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3369","�ຣʡ","qinghaisheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3370","����","xining","3369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3371","��Ͻ��","shixiaqu","3370","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3372","�Ƕ���","chengdongqu","3370","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3373","������","chengzhongqu","3370","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3374","������","chengxiqu","3370","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3375","�Ǳ���","chengbeiqu","3370","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3376","��ͨ��������������","datonghuizutuzuzizhixian","3370","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3377","������","zhongxian","3370","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3378","��Դ��","yuanxian","3370","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3379","��������","haidongdiqu","3369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3380","ƽ����","pinganxian","3379","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3381","��ͻ�������������","minhehuizutuzuzizhixian","3379","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3382","�ֶ���","leduxian","3379","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3383","��������������","huzhutuzuzizhixian","3379","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3384","��¡����������","hualonghuizuzizhixian","3379","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3385","ѭ��������������","xunhuasalazuzizhixian","3379","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3386","����������","haibeizizhizhou","3369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3387","��Դ����������","menyuanhuizuzizhixian","3386","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3388","������","qilianxian","3386","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3389","������","haixian","3386","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3390","�ղ���","gangchaxian","3386","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3391","����������","huangnanzizhizhou","3369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3392","ͬ����","tongrenxian","3391","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3393","������","jianzhaxian","3391","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3394","�����","zekuxian","3391","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3395","�����ɹ���������","henanmengguzuzizhixian","3391","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3396","����������","hainanzizhizhou","3369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3397","������","gonghexian","3396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3398","ͬ����","tongdexian","3396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3399","�����","guidexian","3396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3400","�˺���","xinghaixian","3396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3401","������","guinanxian","3396","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3402","����������","guoluozizhizhou","3369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3403","������","maqinxian","3402","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3404","������","banmaxian","3402","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3405","�ʵ���","gandexian","3402","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3406","������","darixian","3402","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3407","������","jiuzhixian","3402","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3408","�����","maduoxian","3402","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3409","����������","yushuzizhizhou","3369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3410","������","yushuxian","3409","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3411","�Ӷ���","zaduoxian","3409","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3412","�ƶ���","chengduoxian","3409","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3413","�ζ���","zhiduoxian","3409","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3414","��ǫ��","nangqianxian","3409","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3415","��������","qumalaixian","3409","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3416","����������","haixizizhizhou","3369","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3417","���ľ��","geermushi","3416","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3418","�������","delinghashi","3416","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3419","������","wulanxian","3416","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3420","������","dulanxian","3416","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3421","�����","tianjunxian","3416","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3422","������","ningxiaqu","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3423","����","yinchuan","3422","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3424","��Ͻ��","shixiaqu","3423","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3425","������","xingqingqu","3423","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3426","������","xixiaqu","3423","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3427","�����","jinfengqu","3423","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3428","������","yongningxian","3423","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3429","������","helanxian","3423","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3430","������","lingwushi","3423","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3431","ʯ��ɽ","shizuishan","3422","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3432","��Ͻ��","shixiaqu","3431","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3433","�������","dawukouqu","3431","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3434","��ũ��","huinongqu","3431","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3435","ƽ����","pingluoxian","3431","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3436","����","wuzhong","3422","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3437","��Ͻ��","shixiaqu","3436","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3438","��ͨ��","litongqu","3436","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3439","�γ���","yanchixian","3436","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3440","ͬ����","tongxinxian","3436","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3441","��ͭϿ��","qingtongxiashi","3436","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3442","��ԭ","guyuan","3422","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3443","��Ͻ��","shixiaqu","3442","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3444","ԭ����","yuanzhouqu","3442","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3445","������","xijixian","3442","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3446","¡����","longdexian","3442","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3447","��Դ��","yuanxian","3442","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3448","������","pengyangxian","3442","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3449","����","zhongwei","3422","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3450","��Ͻ��","shixiaqu","3449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3451","ɳ��ͷ��","shapotouqu","3449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3452","������","zhongningxian","3449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3453","��ԭ��","haiyuanxian","3449","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3454","�½���","xinjiangqu","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3455","��³ľ��","wulumuqi","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3456","��Ͻ��","shixiaqu","3455","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3457","��ɽ��","tianshanqu","3455","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3458","ɳ���Ϳ���","shayibakequ","3455","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3459","������","xinshiqu","3455","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3460","ˮĥ����","shuimogouqu","3455","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3461","ͷ�ͺ���","toutunhequ","3455","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3462","�������","dachengqu","3455","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3463","��ɽ��","dongshanqu","3455","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3464","��³ľ����","wulumuqixian","3455","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3465","��������","kelamayi","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3466","��Ͻ��","shixiaqu","3465","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3467","��ɽ����","dushanziqu","3465","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3468","����������","kelamayiqu","3465","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3469","�׼�̲��","baijiantanqu","3465","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3470","�ڶ�����","wuerhequ","3465","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3471","��³������","tulufandiqu","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3472","��³����","tulufanshi","3471","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3473","۷����","shanxian","3471","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3474","�п�ѷ��","tuokexunxian","3471","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3475","���ܵ���","hamidiqu","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3476","������","hamishi","3475","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3477","������������������","balikunhasakezizhixian","3475","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3478","������","yiwuxian","3475","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3479","����������","changjizizhizhou","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3480","������","changjishi","3479","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3481","������","fukangshi","3479","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3482","��Ȫ��","miquanshi","3479","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3483","��ͼ����","hutubixian","3479","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3484","����˹��","manasixian","3479","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3485","��̨��","qitaixian","3479","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3486","��ľ������","jimusaerxian","3479","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3487","ľ�ݹ�����������","muleihasakezizhixian","3479","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3488","����������","boertalazhou","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3489","������","boleshi","3488","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3490","������","jinghexian","3488","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3491","��Ȫ��","wenquanxian","3488","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3492","����������","bayinguolengzhou","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3493","�������","kuerleshi","3492","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3494","��̨��","luntaixian","3492","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3495","ξ����","weilixian","3492","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3496","��Ǽ��","ruoqiangxian","3492","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3497","��ĩ��","qiemoxian","3492","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3498","���Ȼ���������","yanhuizuzizhixian","3492","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3499","�;���","hejingxian","3492","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3500","��˶��","heshuoxian","3492","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3501","������","bohuxian","3492","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3502","�����յ���","akesudiqu","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3503","��������","akesushi","3502","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3504","������","wensuxian","3502","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3505","�⳵��","kuchexian","3502","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3506","ɳ����","shayaxian","3502","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3507","�º���","xinhexian","3502","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3508","�ݳ���","baichengxian","3502","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3509","��ʲ��","wushixian","3502","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3510","��������","awatixian","3502","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3511","��ƺ��","kepingxian","3502","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3512","����������","kezilesuzhou","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3513","��ͼʲ��","atushishi","3512","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3514","��������","aketaoxian","3512","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3515","��������","aheqixian","3512","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3516","��ǡ��","wuqiaxian","3512","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3517","��ʲ����","kashidiqu","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3518","��ʲ��","kashishi","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3519","�踽��","shufuxian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3520","������","shulexian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3521","Ӣ��ɳ��","yingjishaxian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3522","������","zepuxian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3523","ɯ����","shachexian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3524","Ҷ����","yechengxian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3525","�������","maigaitixian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3526","���պ���","yuepuhuxian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3527","٤ʦ��","shixian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3528","�ͳ���","bachuxian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3529","��ʲ�����������������","tashikuergantajikezizhixian","3517","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3530","�������","hetiandiqu","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3531","������","hetianshi","3530","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3532","������","hetianxian","3530","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3533","ī����","moyuxian","3530","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3534","Ƥɽ��","pishanxian","3530","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3535","������","luopuxian","3530","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3536","������","celexian","3530","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3537","������","yutianxian","3530","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3538","�����","minfengxian","3530","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3539","����������","yilizizhizhou","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3540","������","yiningshi","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3541","������","kuitunshi","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3542","������","yiningxian","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3543","�첼�������������","chabuchaerxibozizhixian","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3544","������","huochengxian","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3545","������","gongliuxian","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3546","��Դ��","xinyuanxian","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3547","������","zhaosuxian","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3548","�ؿ�˹��","tekesixian","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3549","���տ���","nilekexian","3539","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3550","���ǵ���","tachengdiqu","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3551","������","tachengshi","3550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3552","������","wusushi","3550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3553","������","eminxian","3550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3554","ɳ����","shawanxian","3550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3555","������","tuolixian","3550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3556","ԣ����","yuminxian","3550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3557","�Ͳ��������ɹ�������","hebukesaiermengguzizhixian","3550","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3558","����̩����","aletaidiqu","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3559","����̩��","aletaishi","3558","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3560","��������","buerjinxian","3558","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3561","������","fuyunxian","3558","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3562","������","fuhaixian","3558","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3563","���ͺ���","habahexian","3558","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3564","�����","qinghexian","3558","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3565","��ľ����","jimunaixian","3558","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3566","�½�ʡϽ��λ","xinjiangshengxiadanwei","3454","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3567","ʯ������","shihezishi","3566","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3568","��������","alaershi","3566","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3569","ͼľ�����","tumushukeshi","3566","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3570","�������","wujiaqushi","3566","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3571","̨��ʡ","taiwansheng","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3572","0","","3571","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3573","�������","xianggangtequ","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3574","0","","3573","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3575","��������","aomentequ","0","","10");

insert into `dw_area` ( `id`,`name`,`nid`,`pid`,`domain`,`order`) values ("3576","0","","3575","","10");

