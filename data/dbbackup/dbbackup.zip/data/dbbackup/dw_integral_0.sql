insert into `dw_integral` ( `id`,`site_id`,`name`,`need`,`number`,`ex_number`,`province`,`city`,`area`,`litpic`,`content`,`hits`,`top`,`flag`,`order`,`status`,`addtime`,`addip`) values ("1","0","���϶Է�123","12","12","0","3046","3069","3074","","123123","0","0","","10","1","1283747655","127.0.0.1");

