insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("1","1","3000.00","3000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("2","48","3000.00","3000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("3","2","3000.00","3000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("4","3","3000.00","3000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("5","4","500000.00","502820.46","-2820.46","100000.00","100000.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("6","5","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("7","6","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("8","7","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("9","8","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("10","9","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("11","10","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("12","11","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("13","12","20000.00","20177.20","-177.20","0.00","0.00","0.00","100000.00","100000.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("14","13","100000.00","60.00","99940.00","100000.00","100000.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("15","14","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("16","15","5000.00","5005.00","-5.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("17","16","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("18","17","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("19","18","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("20","19","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("21","20","20000.00","20037.00","-37.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("22","21","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("23","22","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("24","23","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("25","24","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("26","25","5000.00","4000.00","1000.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("27","26","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("28","27","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("29","28","5000.00","5063.54","-63.54","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("30","29","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("31","30","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("32","31","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("33","32","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("34","33","5000.00","5018.33","-18.33","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("35","34","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("36","35","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("37","36","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("38","37","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("39","38","10000.00","10006.25","-6.25","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("40","39","10000.00","10065.92","-65.92","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("41","40","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("42","41","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("43","42","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("44","43","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("45","44","15000.00","15050.00","-50.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("46","45","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("47","46","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("48","47","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("49","49","50000.00","50050.00","-50.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("50","50","8000.00","8036.17","-36.17","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("51","51","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("52","52","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("53","53","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("54","54","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("55","55","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("56","56","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("57","57","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("58","58","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("59","59","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("60","60","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("61","61","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("62","62","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("63","63","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("64","64","5000.00","0.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("65","65","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("66","66","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("67","67","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("68","68","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("69","69","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

insert into `dw_user_amount` ( `id`,`user_id`,`credit`,`credit_use`,`credit_nouse`,`borrow_vouch`,`borrow_vouch_use`,`borrow_vouch_nouse`,`tender_vouch`,`tender_vouch_use`,`tender_vouch_nouse`) values ("70","70","5000.00","5000.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00");

