insert into `dw_editor` ( `editor_id`,`code`,`name`,`description`,`version`,`author`,`date`,`api`) values ("1","sinaeditor","���˱༭��","���õ����˱༭��","1.0","����","2010-08-13","require_once(ROOT_PATH .\"/plugins/editor/sinaeditor/Editor.class.php\");\r\n$editor=new sinaEditor($name);\r\n	$editor->Value= \"$value\";\r\n\r\n	$editor->AutoSave=false;\r\n	echo $editor->Create();");

