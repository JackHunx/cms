insert into `dw_links` ( `id`,`site_id`,`status`,`order`,`flag`,`type_id`,`url`,`webname`,`summary`,`linkman`,`email`,`logo`,`logoimg`,`province`,`city`,`area`,`hits`,`addtime`,`addip`) values ("2","0","1","10","0","2","https://www.psbc.com","������������","�������","֧����","","","data/upfiles/images/2012-03/14/1_system_13317327483.jpg","","","","0","1287700055","222.59.180.146");

insert into `dw_links` ( `id`,`site_id`,`status`,`order`,`flag`,`type_id`,`url`,`webname`,`summary`,`linkman`,`email`,`logo`,`logoimg`,`province`,`city`,`area`,`hits`,`addtime`,`addip`) values ("6","0","1","13","0","2","http://www.abchina.com/","����ũҵ����","����ũҵ����","","","","data/upfiles/images/2012-03/14/1_system_13317326365.jpg","","","","0","1289797452","113.83.206.128");

insert into `dw_links` ( `id`,`site_id`,`status`,`order`,`flag`,`type_id`,`url`,`webname`,`summary`,`linkman`,`email`,`logo`,`logoimg`,`province`,`city`,`area`,`hits`,`addtime`,`addip`) values ("7","0","1","15","0","2","https://www.scrcu.com.cn","����������","����������","","","","data/upfiles/images/2012-03/14/1_system_13317326014.jpg","","","","0","1289797919","113.83.206.128");

insert into `dw_links` ( `id`,`site_id`,`status`,`order`,`flag`,`type_id`,`url`,`webname`,`summary`,`linkman`,`email`,`logo`,`logoimg`,`province`,`city`,`area`,`hits`,`addtime`,`addip`) values ("8","0","1","17","","2","http://www.0818168.com","�й�������","�й�������","","","","data/upfiles/images/2012-03/14/1_system_13317320923.jpg","","","","0","1291276576","113.83.201.226");

