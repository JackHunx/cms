insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("1","2","1","1","10","������֤�ɹ�","0","1313993334","58.46.172.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("2","4","1","1","10","������֤�ɹ�","0","1314060246","58.46.172.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("3","4","2","1","10","t","1","1314060660","58.46.172.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("4","4","3","1","10","t","1","1314060686","58.46.172.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("5","4","6","1","2","��ʻ֤(����С�γ���","1","1314084631","58.46.172.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("6","5","1","1","10","������֤�ɹ�","0","1314097255","118.253.4.77");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("7","6","1","1","10","������֤�ɹ�","0","1314097547","118.253.4.77");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("8","7","1","1","10","������֤�ɹ�","0","1314097705","118.253.4.77");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("9","5","7","1","10","Ͷ�ʳɹ���10��","1","1314098801","118.253.4.77");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("10","7","7","1","10","Ͷ�ʳɹ���10��","1","1314098801","118.253.4.77");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("11","6","7","1","10","Ͷ�ʳɹ���10��","1","1314098801","118.253.4.77");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("12","4","12","1","5","����ɹ���5��","4","1314098900","118.253.4.77");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("13","4","8","1","30","���ɹ���30��","4","1314098900","118.253.4.77");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("14","8","1","1","10","������֤�ɹ�","0","1314176347","122.77.43.203");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("15","9","1","1","10","������֤�ɹ�","0","1314196196","171.38.155.44");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("16","10","1","1","10","������֤�ɹ�","0","1314244267","59.49.158.45");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("17","11","1","1","10","������֤�ɹ�","0","1314245099","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("18","12","1","1","10","������֤�ɹ�","0","1314245324","58.46.182.14");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("19","12","2","1","10","2","1","1314249464","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("20","12","3","1","10","e","1","1314249484","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("21","13","1","1","10","������֤�ɹ�","0","1314254844","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("22","13","2","1","10","4","1","1314255086","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("23","13","3","1","10","2","1","1314255098","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("24","15","1","1","10","������֤�ɹ�","0","1314256511","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("25","14","1","1","10","������֤�ɹ�","0","1314256566","113.65.175.144");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("26","15","2","1","10","1","1","1314256707","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("27","15","3","1","10","1","1","1314256719","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("28","16","1","1","10","������֤�ɹ�","0","1314260321","113.65.155.250");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("29","18","1","1","10","������֤�ɹ�","0","1314262151","113.65.155.250");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("30","6","7","1","10","Ͷ�ʳɹ���10��","1","1314262691","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("31","5","7","1","10","Ͷ�ʳɹ���10��","1","1314262691","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("32","11","7","1","10","Ͷ�ʳɹ���10��","1","1314262691","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("33","12","7","2","0","Ͷ�ʳɹ���0��","1","1314262691","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("34","4","12","1","5","����ɹ���5��","4","1314262797","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("35","4","8","1","30","���ɹ���30��","4","1314262797","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("36","19","1","1","10","������֤�ɹ�","0","1314262831","113.65.155.250");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("37","6","7","1","5","Ͷ�ʳɹ���5��","1","1314262949","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("38","14","7","1","5","Ͷ�ʳɹ���5��","1","1314262951","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("39","14","7","1","10","Ͷ�ʳɹ���10��","1","1314262953","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("40","20","1","1","10","������֤�ɹ�","0","1314264477","58.46.193.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("41","22","1","1","10","������֤�ɹ�","0","1314267302","113.65.155.250");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("42","20","2","1","10","4","1","1314268814","118.253.11.171");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("43","20","3","1","10","4","1","1314268826","118.253.11.171");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("44","23","1","1","10","������֤�ɹ�","0","1314269080","113.65.155.250");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("45","24","1","1","10","������֤�ɹ�","0","1314269849","113.65.155.250");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("46","25","1","1","10","������֤�ɹ�","0","1314270080","113.142.216.204");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("47","26","1","1","10","������֤�ɹ�","0","1314270462","113.65.155.250");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("48","25","2","1","10","ͨ��","1","1314270769","118.253.11.171");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("49","5","7","1","2","Ͷ�ʳɹ���2��","1","1314272138","118.253.11.171");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("50","6","7","1","2","Ͷ�ʳɹ���2��","1","1314272138","118.253.11.171");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("51","14","7","1","5","Ͷ�ʳɹ���5��","1","1314272139","118.253.11.171");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("52","12","12","1","5","����ɹ���5��","12","1314272399","118.253.11.171");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("53","12","8","1","9","���ɹ���9��","12","1314272399","118.253.11.171");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("54","27","1","1","10","������֤�ɹ�","0","1314272903","112.3.235.81");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("55","28","1","1","10","������֤�ɹ�","0","1314283972","123.87.181.158");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("56","25","6","1","1","���ڱ�","1","1314286301","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("57","25","6","1","1","������","1","1314286330","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("58","25","6","1","2","����������ˮ","1","1314286379","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("59","25","6","1","1","��������֤","1","1314286413","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("60","25","6","2","0","ͨ��","1","1314286534","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("61","25","6","2","0","ͨ��","1","1314286549","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("62","25","6","2","0","ͨ��","1","1314286565","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("63","25","6","2","0","ͨ��","1","1314286584","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("64","25","6","2","0","ͨ��","1","1314286615","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("65","25","6","2","0","ͨ��","1","1314286630","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("66","25","6","2","0","ͨ��","1","1314286645","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("67","25","6","2","0","ͨ��","1","1314286666","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("68","25","6","2","0","ͨ��","1","1314286681","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("69","25","6","2","0","ͨ��","1","1314286697","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("70","25","6","2","0","ͨ��","1","1314286711","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("71","25","6","2","0","ͨ��","1","1314286723","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("72","25","6","2","0","ͨ��","1","1314286737","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("73","25","6","2","0","ͨ��","1","1314286749","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("74","25","6","2","0","ͨ��","1","1314286762","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("75","25","6","1","1","���ñ���","1","1314286819","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("76","25","6","2","0","ͨ��","1","1314286837","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("77","25","6","2","0","ͨ��","1","1314286858","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("78","25","6","1","2","˰��Ǽ�֤","1","1314286904","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("79","25","6","1","2","ͨ��","1","1314286954","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("80","25","6","2","0","ͨ��","1","1314286967","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("81","25","6","2","0","ͨ��","1","1314286983","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("82","25","6","1","1","��ҵ֤��","1","1314287010","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("83","25","6","1","2","Ӫҵִ��","1","1314287050","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("84","25","6","2","0","ͨ��","1","1314287065","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("85","25","6","1","2","����֤ ","1","1314287097","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("86","25","6","2","0","ͨ��","1","1314287113","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("87","25","6","2","0","ͨ��","1","1314287129","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("88","25","6","2","0","ͨ��","1","1314287140","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("89","25","6","2","0","ͨ��","1","1314287156","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("90","25","6","1","1","��ס�����޺�ͬ","1","1314287184","222.243.13.108");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("91","29","1","1","10","������֤�ɹ�","0","1314290140","113.68.193.46");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("92","6","7","1","1","Ͷ�ʳɹ���1��","1","1314325744","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("93","14","7","1","1","Ͷ�ʳɹ���1��","1","1314325745","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("94","16","7","1","1","Ͷ�ʳɹ���1��","1","1314325746","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("95","19","7","1","1","Ͷ�ʳɹ���1��","1","1314325746","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("96","18","7","1","1","Ͷ�ʳɹ���1��","1","1314325747","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("97","14","7","1","3","Ͷ�ʳɹ���3��","1","1314325766","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("98","22","7","1","10","Ͷ�ʳɹ���10��","1","1314325766","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("99","6","7","1","10","Ͷ�ʳɹ���10��","1","1314325766","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("100","24","7","1","10","Ͷ�ʳɹ���10��","1","1314325767","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("101","23","7","1","10","Ͷ�ʳɹ���10��","1","1314325767","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("102","26","7","1","10","Ͷ�ʳɹ���10��","1","1314325768","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("103","18","7","1","10","Ͷ�ʳɹ���10��","1","1314325768","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("104","12","7","1","10","Ͷ�ʳɹ���10��","1","1314325768","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("105","19","7","1","10","Ͷ�ʳɹ���10��","1","1314325769","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("106","16","7","1","6","Ͷ�ʳɹ���6��","1","1314325769","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("107","4","12","1","5","����ɹ���5��","4","1314325819","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("108","4","8","1","89","���ɹ���89��","4","1314325819","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("109","13","12","1","5","����ɹ���5��","13","1314326175","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("110","13","8","1","20","���ɹ���20��","13","1314326175","58.46.179.32");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("111","10","2","1","10","ͨ��","1","1314515149","113.218.57.207");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("112","33","1","1","10","������֤�ɹ�","0","1314523035","113.246.47.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("113","34","1","1","10","������֤�ɹ�","0","1314542692","113.219.77.148");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("114","15","12","1","5","����ɹ���5��","15","1314596258","58.46.162.87");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("115","15","8","1","5","���ɹ���5��","15","1314596258","58.46.162.87");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("116","35","1","1","10","������֤�ɹ�","0","1314598005","120.36.199.18");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("117","36","1","1","10","������֤�ɹ�","0","1314630514","180.110.202.37");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("118","6","7","1","5","Ͷ�ʳɹ���5��","1","1314665236","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("119","12","7","1","5","Ͷ�ʳɹ���5��","1","1314665236","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("120","11","7","1","5","Ͷ�ʳɹ���5��","1","1314665236","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("121","18","7","1","5","Ͷ�ʳɹ���5��","1","1314665242","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("122","14","7","1","5","Ͷ�ʳɹ���5��","1","1314665243","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("123","16","7","1","5","Ͷ�ʳɹ���5��","1","1314665243","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("124","16","7","1","15","Ͷ�ʳɹ���15��","1","1314665271","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("125","5","7","1","10","Ͷ�ʳɹ���10��","1","1314665271","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("126","11","7","1","15","Ͷ�ʳɹ���15��","1","1314665271","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("127","22","7","1","10","Ͷ�ʳɹ���10��","1","1314665273","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("128","6","7","1","5","Ͷ�ʳɹ���5��","1","1314665293","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("129","12","7","1","10","Ͷ�ʳɹ���10��","1","1314665293","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("130","5","7","1","10","Ͷ�ʳɹ���10��","1","1314665293","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("131","11","7","1","10","Ͷ�ʳɹ���10��","1","1314665293","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("132","14","7","1","10","Ͷ�ʳɹ���10��","1","1314665294","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("133","18","7","1","5","Ͷ�ʳɹ���5��","1","1314665294","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("134","6","7","1","2","Ͷ�ʳɹ���2��","1","1314665320","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("135","5","7","1","2","Ͷ�ʳɹ���2��","1","1314665320","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("136","12","7","1","6","Ͷ�ʳɹ���6��","1","1314665320","113.219.225.103");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("137","37","1","1","10","������֤�ɹ�","0","1314674814","124.165.226.198");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("138","28","2","1","10","ͨ��","1","1314676972","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("139","23","2","1","10","ͨ��","1","1314676995","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("140","16","2","1","10","ͨ��","1","1314677019","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("141","14","2","1","10","ͨ��","1","1314677047","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("142","12","12","1","5","����ɹ���5��","12","1314677262","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("143","12","8","1","50","���ɹ���50��","12","1314677262","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("144","38","1","1","10","������֤�ɹ�","0","1314679913","113.117.116.229");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("145","13","12","1","5","����ɹ���5��","13","1314680942","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("146","13","8","1","30","���ɹ���30��","13","1314680942","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("147","38","2","1","10","ͨ��","1","1314681029","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("148","38","3","1","10","tongguo ","1","1314681932","58.46.184.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("149","22","2","1","10","ͨ��","1","1314713559","113.219.166.91");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("150","39","1","1","10","������֤�ɹ�","0","1314715138","113.219.166.91");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("151","39","2","1","10","ͨ��","1","1314716749","113.219.166.91");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("152","39","3","1","10","1","1","1314716779","113.219.166.91");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("153","20","12","1","5","����ɹ���5��","20","1314717525","113.219.166.91");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("154","20","8","1","50","���ɹ���50��","20","1314717525","113.219.166.91");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("155","40","1","1","10","������֤�ɹ�","0","1314717871","113.219.166.91");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("156","41","1","1","10","������֤�ɹ�","0","1314720674","113.219.166.91");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("157","42","1","1","10","������֤�ɹ�","0","1314753123","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("158","23","7","1","5","Ͷ�ʳɹ���5��","1","1314753325","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("159","26","2","1","10","ͨ��","1","1314753478","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("160","24","2","1","10","ͨ��","1","1314753500","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("161","19","2","1","10","ͨ��","1","1314753522","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("162","18","2","1","10","ͨ��","1","1314753557","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("163","33","6","1","1","�ֻ�ͨ����¼�嵥","1","1314753597","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("164","33","6","2","0","�����","1","1314753615","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("165","33","6","2","0","�����","1","1314753630","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("166","33","6","2","0","�����","1","1314753646","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("167","33","6","2","0","�����","1","1314753659","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("168","33","6","2","0","�����","1","1314753670","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("169","33","6","2","0","�����","1","1314753682","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("170","33","6","2","0","�����","1","1314753694","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("171","33","6","2","0","�����","1","1314753705","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("172","33","6","1","2","�������ñ���","1","1314753721","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("173","33","6","1","2","���ڱ�","1","1314753744","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("174","33","6","2","0","�����","1","1314753755","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("175","33","6","2","0","�����","1","1314753766","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("176","33","6","1","1","���д���������ˮ","1","1314753793","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("177","33","6","2","0","�����","1","1314753805","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("178","33","6","2","0","�����","1","1314753816","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("179","33","6","1","1","����֤��","1","1314753838","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("180","33","6","1","1","ˮ�緢Ʊ","1","1314753857","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("181","33","6","1","1","��ƾ��ͬ","1","1314753873","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("182","0","6","2","0","�����","1","1314753885","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("183","33","6","2","0","�����","1","1314753897","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("184","33","6","2","0","�����","1","1314753908","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("185","33","6","1","2","����֤","1","1314753924","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("186","33","6","1","1","������","1","1314753939","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("187","33","6","2","0","�����","1","1314753950","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("188","33","6","1","1","��ʻ֤","1","1314753969","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("189","28","6","2","0","�����","1","1314753984","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("190","28","6","2","0","�����","1","1314753995","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("191","28","6","1","2","���ñ���","1","1314754011","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("192","28","6","1","1","�籣","1","1314754026","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("193","28","6","2","0","�����","1","1314754038","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("194","28","6","2","0","�����","1","1314754048","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("195","43","1","1","10","������֤�ɹ�","0","1314754452","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("196","33","2","1","10","ͨ��","1","1314755033","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("197","33","3","1","10","ͨ��","1","1314755211","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("198","44","1","1","10","������֤�ɹ�","0","1314758449","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("199","44","2","1","10","","1","1314758942","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("200","44","3","1","10","","1","1314758954","58.46.178.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("201","45","1","1","10","������֤�ɹ�","0","1314761355","180.110.4.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("202","46","1","1","10","������֤�ɹ�","0","1314761917","180.110.4.119");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("203","47","1","1","10","������֤�ɹ�","0","1314788873","183.62.126.193");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("204","22","7","1","6","Ͷ�ʳɹ���6��","1","1314789582","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("205","16","7","1","4","Ͷ�ʳɹ���4��","1","1314789582","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("206","5","7","1","20","Ͷ�ʳɹ���20��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("207","12","7","1","20","Ͷ�ʳɹ���20��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("208","6","7","1","20","Ͷ�ʳɹ���20��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("209","11","7","1","20","Ͷ�ʳɹ���20��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("210","34","7","1","20","Ͷ�ʳɹ���20��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("211","12","7","1","30","Ͷ�ʳɹ���30��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("212","40","7","1","50","Ͷ�ʳɹ���50��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("213","41","7","1","50","Ͷ�ʳɹ���50��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("214","42","7","1","50","Ͷ�ʳɹ���50��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("215","43","7","1","50","Ͷ�ʳɹ���50��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("216","5","7","1","30","Ͷ�ʳɹ���30��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("217","27","7","1","50","Ͷ�ʳɹ���50��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("218","16","7","1","14","Ͷ�ʳɹ���14��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("219","45","7","1","50","Ͷ�ʳɹ���50��","1","1314789682","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("220","14","7","1","19","Ͷ�ʳɹ���19��","1","1314789683","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("221","18","7","1","7","Ͷ�ʳɹ���7��","1","1314789683","113.219.34.69");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("222","4","12","1","5","����ɹ���5��","4","1314798827","113.219.199.111");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("223","4","8","1","500","���ɹ���500��","4","1314798827","113.219.199.111");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("224","46","2","1","10","ͨ��","1","1314799064","113.219.199.111");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("225","45","2","1","10","ͨ��","1","1314799083","113.219.199.111");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("226","27","2","1","10","ͨ��","1","1314799101","113.219.199.111");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("227","38","12","1","5","����ɹ���5��","38","1314826284","113.117.117.22");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("228","38","8","1","5","���ɹ���5��","38","1314826284","113.117.117.22");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("229","16","7","1","5","Ͷ�ʳɹ���5��","1","1314849365","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("230","23","7","1","5","Ͷ�ʳɹ���5��","1","1314849366","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("231","24","7","1","5","Ͷ�ʳɹ���5��","1","1314849366","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("232","26","7","1","5","Ͷ�ʳɹ���5��","1","1314849366","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("233","19","7","1","5","Ͷ�ʳɹ���5��","1","1314849367","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("234","22","7","1","4","Ͷ�ʳɹ���4��","1","1314849367","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("235","38","6","1","1","�ֻ�ͨ����¼�嵥","1","1314855571","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("236","38","6","1","2","����֤ ","1","1314855594","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("237","38","6","2","0","�����","1","1314855615","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("238","38","6","2","0","�����","1","1314855634","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("239","38","6","2","0","�����","1","1314855645","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("240","38","6","1","1","������","1","1314855665","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("241","38","6","1","2","���֤","1","1314855685","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("242","38","6","1","1","��������֤","1","1314855703","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("243","38","6","2","0","�����","1","1314855717","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("244","38","6","1","2","���ڱ�","1","1314855736","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("245","0","6","2","0","�����","1","1314855748","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("246","38","6","2","0","�����","1","1314855763","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("247","28","6","2","0","�����","1","1314855793","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("248","28","6","2","0","�����","1","1314855814","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("249","28","6","1","1","ˮ�緢Ʊ","1","1314855830","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("250","28","6","2","0","�����","1","1314855846","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("251","28","6","1","1","��������֤","1","1314855866","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("252","28","6","1","2","���д������ʼ�¼�����ת�˴���¼","1","1314855886","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("253","28","6","2","0","�����","1","1314855898","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("254","28","6","2","0","�����","1","1314855912","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("255","28","6","2","0","�����","1","1314855922","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("256","28","6","2","0","�����","1","1314855936","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("257","28","6","1","2","��λ֤��","1","1314855960","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("258","28","6","1","2","���֤","1","1314856010","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("259","28","6","2","0","�����","1","1314856026","58.46.183.83");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("260","49","1","1","10","������֤�ɹ�","0","1314865744","119.147.32.16");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("261","50","1","1","10","������֤�ɹ�","0","1314865979","113.219.247.72");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("262","50","2","1","10","1","1","1314867167","113.219.247.72");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("263","50","3","1","10","2","1","1314867178","113.219.247.72");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("264","49","2","1","10","e","1","1314867208","113.219.247.72");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("265","49","3","1","10","a","1","1314867227","113.219.247.72");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("266","39","12","1","5","����ɹ���5��","39","1314872500","113.219.247.72");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("267","39","8","1","29","���ɹ���29��","39","1314872500","113.219.247.72");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("268","33","12","1","5","����ɹ���5��","33","1314928141","118.250.168.196");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("269","33","8","1","10","���ɹ���10��","33","1314928141","118.250.168.196");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("270","28","3","1","10","tongguo","1","1314929408","113.219.121.221");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("271","52","1","1","10","������֤�ɹ�","0","1315287273","172.16.135.1");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("272","53","1","1","10","������֤�ɹ�","0","1315310613","172.16.135.1");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("273","51","1","1","10","������֤�ɹ�","0","1315316889","117.136.22.78");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("274","27","7","1","50","Ͷ�ʳɹ���50��","1","1315441757","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("275","46","7","1","39","Ͷ�ʳɹ���39��","1","1315441757","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("276","34","7","1","5","Ͷ�ʳɹ���5��","1","1315441770","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("277","6","7","1","5","Ͷ�ʳɹ���5��","1","1315441818","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("278","5","7","1","5","Ͷ�ʳɹ���5��","1","1315441818","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("279","14","7","1","5","Ͷ�ʳɹ���5��","1","1315441819","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("280","18","7","1","5","Ͷ�ʳɹ���5��","1","1315441819","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("281","16","7","1","5","Ͷ�ʳɹ���5��","1","1315441819","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("282","23","7","1","5","Ͷ�ʳɹ���5��","1","1315441820","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("283","24","7","1","5","Ͷ�ʳɹ���5��","1","1315441820","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("284","26","7","1","5","Ͷ�ʳɹ���5��","1","1315441820","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("285","22","7","1","4","Ͷ�ʳɹ���4��","1","1315441821","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("286","19","7","1","5","Ͷ�ʳɹ���5��","1","1315441821","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("287","27","7","1","1","Ͷ�ʳɹ���1��","1","1315441821","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("288","43","7","1","5","Ͷ�ʳɹ���5��","1","1315441851","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("289","18","7","1","4","Ͷ�ʳɹ���4��","1","1315441852","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("290","19","7","1","5","Ͷ�ʳɹ���5��","1","1315441852","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("291","24","7","1","5","Ͷ�ʳɹ���5��","1","1315441853","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("292","26","7","1","5","Ͷ�ʳɹ���5��","1","1315441853","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("293","14","7","1","5","Ͷ�ʳɹ���5��","1","1315441853","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("294","46","7","1","5","Ͷ�ʳɹ���5��","1","1315441853","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("295","27","7","1","5","Ͷ�ʳɹ���5��","1","1315441853","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("296","45","7","1","5","Ͷ�ʳɹ���5��","1","1315441853","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("297","18","7","1","1","Ͷ�ʳɹ���1��","1","1315441854","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("298","16","7","1","5","Ͷ�ʳɹ���5��","1","1315441854","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("299","12","12","1","5","����ɹ���5��","12","1315442653","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("300","12","8","1","89","���ɹ���89��","12","1315442653","113.218.152.110");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("301","36","2","1","10","ͨ��","1","1315484544","113.218.53.251");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("302","6","7","1","5","Ͷ�ʳɹ���5��","1","1315611154","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("303","5","7","1","5","Ͷ�ʳɹ���5��","1","1315611154","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("304","27","7","1","5","Ͷ�ʳɹ���5��","1","1315611154","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("305","46","7","1","5","Ͷ�ʳɹ���5��","1","1315611154","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("306","45","7","1","5","Ͷ�ʳɹ���5��","1","1315611154","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("307","14","7","1","5","Ͷ�ʳɹ���5��","1","1315611155","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("308","18","7","1","1","Ͷ�ʳɹ���1��","1","1315611156","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("309","16","7","1","5","Ͷ�ʳɹ���5��","1","1315611156","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("310","23","7","1","5","Ͷ�ʳɹ���5��","1","1315611157","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("311","19","7","1","1","Ͷ�ʳɹ���1��","1","1315611157","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("312","42","7","1","1","Ͷ�ʳɹ���1��","1","1315611157","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("313","22","7","1","5","Ͷ�ʳɹ���5��","1","1315611158","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("314","12","7","2","0","Ͷ�ʳɹ���0��","1","1315611158","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("315","34","7","1","10","Ͷ�ʳɹ���10��","1","1315611209","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("316","40","7","1","20","Ͷ�ʳɹ���20��","1","1315611209","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("317","43","7","1","8","Ͷ�ʳɹ���8��","1","1315611209","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("318","5","7","1","12","Ͷ�ʳɹ���12��","1","1315611209","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("319","43","7","1","50","Ͷ�ʳɹ���50��","1","1315611209","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("320","44","12","1","5","����ɹ���5��","44","1315611657","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("321","44","8","1","50","���ɹ���50��","44","1315611657","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("322","49","12","1","5","����ɹ���5��","49","1315612283","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("323","49","8","1","50","���ɹ���50��","49","1315612283","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("324","49","4","1","5","w","1","1315612513","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("325","49","5","1","20","t","1","1315612523","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("326","13","5","1","20","t","1","1315612539","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("327","20","5","1","20","t","1","1315613050","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("328","46","7","1","5","Ͷ�ʳɹ���5��","1","1315614183","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("329","45","7","1","5","Ͷ�ʳɹ���5��","1","1315614183","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("330","14","7","1","5","Ͷ�ʳɹ���5��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("331","34","7","1","5","Ͷ�ʳɹ���5��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("332","43","7","1","5","Ͷ�ʳɹ���5��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("333","27","7","1","3","Ͷ�ʳɹ���3��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("334","22","7","1","2","Ͷ�ʳɹ���2��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("335","16","7","1","5","Ͷ�ʳɹ���5��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("336","6","7","1","5","Ͷ�ʳɹ���5��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("337","7","7","1","5","Ͷ�ʳɹ���5��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("338","5","7","1","5","Ͷ�ʳɹ���5��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("339","11","7","2","0","Ͷ�ʳɹ���0��","1","1315614184","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("340","50","12","1","5","����ɹ���5��","50","1315614386","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("341","50","8","1","49","���ɹ���49��","50","1315614386","113.218.120.128");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("342","28","12","1","5","����ɹ���5��","28","1315616967","123.87.177.3");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("343","28","8","1","5","���ɹ���5��","28","1315616967","123.87.177.3");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("344","34","7","1","30","Ͷ�ʳɹ���30��","1","1315627021","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("345","28","12","1","5","����ɹ���5��","28","1315627325","123.87.177.3");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("346","28","12","1","5","����ɹ���5��","28","1315627345","123.87.177.3");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("347","34","7","1","189","Ͷ�ʳɹ���189��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("348","27","7","1","96","Ͷ�ʳɹ���96��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("349","46","7","1","90","Ͷ�ʳɹ���90��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("350","45","7","1","94","Ͷ�ʳɹ���94��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("351","6","7","1","44","Ͷ�ʳɹ���44��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("352","12","7","1","70","Ͷ�ʳɹ���70��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("353","7","7","1","65","Ͷ�ʳɹ���65��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("354","43","7","1","68","Ͷ�ʳɹ���68��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("355","5","7","1","50","Ͷ�ʳɹ���50��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("356","41","7","1","21","Ͷ�ʳɹ���21��","1","1315629496","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("357","22","7","1","9","Ͷ�ʳɹ���9��","1","1315629497","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("358","14","7","1","20","Ͷ�ʳɹ���20��","1","1315629497","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("359","18","7","1","12","Ͷ�ʳɹ���12��","1","1315629498","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("360","16","7","1","18","Ͷ�ʳɹ���18��","1","1315629498","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("361","23","7","1","10","Ͷ�ʳɹ���10��","1","1315629499","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("362","19","7","1","11","Ͷ�ʳɹ���11��","1","1315629499","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("363","24","7","1","10","Ͷ�ʳɹ���10��","1","1315629499","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("364","26","7","1","10","Ͷ�ʳɹ���10��","1","1315629500","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("365","53","2","1","10","w","1","1315630983","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("366","36","3","1","10","ͨ��","1","1315631044","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("367","25","3","1","10","ͨ��","1","1315631082","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("368","13","4","1","5","d","1","1315631150","113.218.36.55");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("369","12","7","1","300","Ͷ�ʳɹ���300��","1","1315651473","113.218.125.86");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("370","11","7","1","352","Ͷ�ʳɹ���352��","1","1315651473","113.218.125.86");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("371","4","7","1","248","Ͷ�ʳɹ���248��","1","1315651473","113.218.125.86");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("372","39","12","1","5","����ɹ���5��","39","1315651533","113.218.125.86");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("373","39","8","1","50","���ɹ���50��","39","1315651533","113.218.125.86");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("374","54","1","1","10","������֤�ɹ�","0","1315653661","123.68.11.26");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("375","4","12","1","5","����ɹ���5��","4","1315657360","113.218.125.86");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("376","4","8","1","889","���ɹ���889��","4","1315657360","113.218.125.86");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("377","28","12","1","5","����ɹ���5��","28","1315703618","123.87.178.188");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("378","28","8","1","30","���ɹ���30��","28","1315703618","123.87.178.188");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("379","55","1","1","10","������֤�ɹ�","0","1315717369","113.218.4.79");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("380","60","1","1","10","������֤�ɹ�","0","1315720719","117.65.22.101");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("381","57","1","1","10","������֤�ɹ�","0","1315823163","113.218.198.239");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("382","58","1","1","10","������֤�ɹ�","0","1315823685","113.218.198.239");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("383","56","1","1","10","������֤�ɹ�","0","1315825708","183.60.61.199");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("384","61","1","1","10","������֤�ɹ�","0","1316001134","183.210.195.90");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("385","62","1","1","10","������֤�ɹ�","0","1316583582","60.10.40.186");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("386","63","1","1","10","������֤�ɹ�","0","1317701229","58.219.249.184");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("387","64","1","1","10","������֤�ɹ�","0","1318591387","117.93.16.227");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("388","65","1","1","10","������֤�ɹ�","0","1318597319","49.83.107.34");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("389","66","1","1","10","������֤�ɹ�","0","1318642409","221.231.116.22");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("390","64","2","1","10","","1","1318663558","58.219.248.170");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("391","64","3","1","10","","1","1318663597","58.219.248.170");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("392","67","1","1","10","������֤�ɹ�","0","1318759810","183.62.126.30");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("393","65","3","1","10","","1","1318814100","117.93.22.200");

insert into `dw_credit_log` ( `id`,`user_id`,`type_id`,`op`,`value`,`remark`,`op_user`,`addtime`,`addip`) values ("394","65","7","1","50","Ͷ�ʳɹ���50��","1","1318814706","117.93.22.200");

