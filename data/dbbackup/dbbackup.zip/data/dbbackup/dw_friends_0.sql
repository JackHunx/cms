insert into `dw_friends` ( `id`,`user_id`,`friends_userid`,`friends_username`,`status`,`type`,`content`,`addtime`,`addip`) values ("1","9","4","","1","1","","1314198890","171.38.155.44");

insert into `dw_friends` ( `id`,`user_id`,`friends_userid`,`friends_username`,`status`,`type`,`content`,`addtime`,`addip`) values ("2","4","9","","1","1","","1314542963","113.219.77.148");

insert into `dw_friends` ( `id`,`user_id`,`friends_userid`,`friends_username`,`status`,`type`,`content`,`addtime`,`addip`) values ("3","28","4","","0","1","","1315631340","123.87.177.3");

insert into `dw_friends` ( `id`,`user_id`,`friends_userid`,`friends_username`,`status`,`type`,`content`,`addtime`,`addip`) values ("4","25","13","","0","1","","1315643622","124.114.177.90");

