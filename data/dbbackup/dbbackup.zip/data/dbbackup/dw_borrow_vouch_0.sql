insert into `dw_borrow_vouch` ( `id`,`user_id`,`borrow_id`,`status`,`account`,`vouch_account`,`content`,`award_fund`,`award_account`,`addtime`,`addip`) values ("1","12","39","2","30000","30000.00","","","0.00","1315630698","113.218.36.55");

insert into `dw_borrow_vouch` ( `id`,`user_id`,`borrow_id`,`status`,`account`,`vouch_account`,`content`,`award_fund`,`award_account`,`addtime`,`addip`) values ("2","12","39","2","20000","20000.00","???????","","0.00","1315657670","113.218.125.86");

