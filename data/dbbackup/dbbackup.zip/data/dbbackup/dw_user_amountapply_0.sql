insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("1","4","credit","50000.00","500000.00","3000.00","1","1314262737","","4","a","1315700642","1","58.46.193.18");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("2","25","credit","10000.00","0.00","5000.00","2","1314354002","","","","","","219.144.103.236");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("3","13","credit","10000.00","100000.00","5000.00","1","1314680963","","d","e","1315612704","1","58.46.184.119");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("4","20","credit","20000.00","20000.00","5000.00","1","1314717565","","e","e","1314717578","1","113.219.166.91");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("5","12","credit","20000.00","20000.00","5000.00","1","1314872636","","d","x","1314872649","1","113.219.247.72");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("6","38","credit","15000.00","10000.00","5000.00","1","1315354616","����߶�ȣ�лл","","ͨ��","1315630743","1","113.117.119.47");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("7","44","credit","20000.00","15000.00","5000.00","1","1315612249","","s","w","1315612476","1","113.218.120.128");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("8","49","credit","30000.00","50000.00","5000.00","1","1315612308","","","e","1315612495","1","113.218.120.128");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("9","13","borrow_vouch","100000.00","100000.00","0.00","1","1315612674","","s","r","1315612712","1","113.218.120.128");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("10","50","credit","18000.00","8000.00","5000.00","1","1315614408","","e","r","1315614446","1","113.218.120.128");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("11","28","credit","10000.00","0.00","5000.00","2","1315618430","�Ѿ�����1�Σ����뻹��ϣ����������ȣ�лл","","","","","123.87.177.3");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("12","4","borrow_vouch","100000.00","100000.00","0.00","1","1315630080","","f","d","1315630109","1","113.218.36.55");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("13","12","tender_vouch","30000.00","100000.00","0.00","1","1315630619","","","s","1315657611","1","113.218.36.55");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("14","46","tender_vouch","10000.00","0.00","0.00","2","1315631095","","","","","","112.21.58.168");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("15","39","credit","10000.00","10000.00","5000.00","1","1315651558","","","ws","1315651578","1","113.218.125.86");

insert into `dw_user_amountapply` ( `id`,`user_id`,`type`,`account`,`account_new`,`account_old`,`status`,`addtime`,`content`,`remark`,`verify_remark`,`verify_time`,`verify_user`,`addip`) values ("16","38","borrow_vouch","15000.00","0.00","0.00","2","1315828818","����赣����ȣ�лл","","","","","113.117.63.145");

