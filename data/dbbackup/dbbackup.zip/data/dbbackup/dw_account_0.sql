insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("1","4","104711.21","79498.58","0.00","25212.63");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("2","5","60318.68","56080.06","2800.00","1438.62");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("3","6","10195.54","5992.50","4000.00","203.04");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("4","7","60140.12","15140.12","45000.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("5","11","61709.80","21572.43","4300.00","35837.37");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("6","12","61048.18","22082.07","7832.00","31134.11");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("7","13","50390.00","40390.00","10000.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("8","15","115.00","115.00","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("9","14","2561.39","2561.80","-0.41","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("10","16","2367.93","2368.00","-0.07","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("11","18","1184.62","1184.62","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("12","19","1162.22","1162.00","0.22","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("13","20","873.00","873.00","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("14","22","1075.57","1076.07","-0.50","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("15","23","1061.18","1061.00","0.18","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("16","24","1056.64","1057.00","-0.36","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("17","25","814.75","14.75","800.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("18","26","1056.29","1057.00","-0.71","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("19","10","0.89","0.89","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("20","34","35400.19","27125.94","7209.13","1065.12");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("21","35","10.89","10.89","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("22","28","326.10","6.10","320.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("23","33","102.56","102.56","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("24","38","-121.11","-121.11","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("25","39","516.32","516.32","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("26","40","40287.80","36977.50","1180.00","2130.30");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("27","41","10157.58","2157.58","8000.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("28","42","10118.17","7118.17","3000.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("29","43","60750.96","47918.52","6612.00","6220.44");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("30","44","870.00","870.00","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("31","27","33490.82","0.01","33490.81","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("32","45","-0.40","0.00","-0.40","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("33","46","0.22","0.00","0.22","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("34","50","956.07","956.07","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("35","49","880.00","880.00","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("36","36","-5.00","-5.00","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("37","53","-5.00","-5.00","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("38","30","10000.00","10000.00","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("39","55","20000.00","20000.00","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("40","57","49950.00","47270.00","2680.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("41","58","50000.00","50000.00","0.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("42","64","6665.00","5865.00","800.00","0.00");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("43","65","10659.32","5315.00","0.00","5344.32");

insert into `dw_account` ( `id`,`user_id`,`total`,`use_money`,`no_use_money`,`collection`) values ("44","1","50.00","50.00","0.00","0.00");

