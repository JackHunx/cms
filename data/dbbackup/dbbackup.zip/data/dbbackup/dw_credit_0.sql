insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("2","10","0","1313993334","58.46.172.103","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("4","1843","4","1314060246","58.46.172.103","1315657360","113.218.125.86");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("5","181","1","1314097255","118.253.4.77","1315629496","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("6","139","1","1314097547","118.253.4.77","1315629496","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("7","90","1","1314097705","118.253.4.77","1315629496","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("8","10","0","1314176347","122.77.43.203","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("9","10","0","1314196196","171.38.155.44","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("10","20","1","1314244267","59.49.158.45","1314515149","113.218.57.207");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("11","424","1","1314245099","58.46.193.18","1315651473","113.218.125.86");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("12","648","1","1314245324","58.46.182.14","1315651473","113.218.125.86");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("13","115","1","1314254844","58.46.193.18","1315631150","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("15","40","15","1314256511","58.46.193.18","1314596258","58.46.162.87");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("14","118","1","1314256566","113.65.175.144","1315629497","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("16","108","1","1314260321","113.65.155.250","1315629498","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("18","71","1","1314262151","113.65.155.250","1315629498","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("19","58","1","1314262831","113.65.155.250","1315629499","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("20","105","1","1314264476","58.46.193.18","1315613050","113.218.120.128");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("22","70","1","1314267302","113.65.155.250","1315629497","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("23","60","1","1314269080","113.65.155.250","1315629499","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("24","55","1","1314269849","113.65.155.250","1315629499","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("25","46","1","1314270080","113.142.216.204","1315631082","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("26","55","1","1314270462","113.65.155.250","1315629500","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("27","230","1","1314272903","112.3.235.81","1315629496","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("28","96","28","1314283972","123.87.181.158","1315703618","123.87.178.188");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("29","10","0","1314290140","113.68.193.46","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("33","58","33","1314523035","113.246.47.69","1314928141","118.250.168.196");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("34","269","1","1314542692","113.219.77.148","1315629496","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("35","10","0","1314598005","120.36.199.18","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("36","30","1","1314630514","180.110.202.37","1315631044","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("38","49","1","1314679913","113.117.116.229","1314855763","58.46.183.83");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("37","10","0","1314674814","124.165.226.198","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("39","119","39","1314715138","113.219.166.91","1315651533","113.218.125.86");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("40","80","1","1314717871","113.219.166.91","1315611209","113.218.120.128");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("41","81","1","1314720674","113.219.166.91","1315629496","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("42","61","1","1314753123","58.46.178.119","1315611157","113.218.120.128");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("0","0","1","1314753885","58.46.178.119","1314855748","58.46.183.83");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("43","196","1","1314754452","58.46.178.119","1315629496","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("44","85","44","1314758449","58.46.178.119","1315611657","113.218.120.128");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("45","179","1","1314761355","180.110.4.119","1315629496","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("46","164","1","1314761917","180.110.4.119","1315629496","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("47","10","0","1314788873","183.62.126.193","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("49","110","1","1314865744","119.147.32.16","1315612523","113.218.120.128");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("50","84","50","1314865979","113.219.247.72","1315614386","113.218.120.128");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("52","10","0","1315287273","172.16.135.1","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("53","20","1","1315310613","172.16.135.1","1315630983","113.218.36.55");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("51","10","0","1315316889","117.136.22.78","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("55","10","0","1315717369","113.218.4.79","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("54","10","0","1315653661","123.68.11.26","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("60","10","0","1315720719","117.65.22.101","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("57","10","0","1315823163","113.218.198.239","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("58","10","0","1315823685","113.218.198.239","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("56","10","0","1315825708","183.60.61.199","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("61","10","0","1316001134","183.210.195.90","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("62","10","0","1316583582","60.10.40.186","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("63","10","0","1317701229","58.219.249.184","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("64","30","1","1318591387","117.93.16.227","1318663597","58.219.248.170");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("65","70","1","1318597319","49.83.107.34","1318814706","117.93.22.200");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("66","10","0","1318642409","221.231.116.22","","");

insert into `dw_credit` ( `user_id`,`value`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("67","10","0","1318759810","183.62.126.30","","");

