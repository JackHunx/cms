insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("1","4","24","","1","data/upfiles/images/2011-08/23/4_attestation_13140844817.jpg","","2","","","","1314084631","1","��ʻ֤(����С�γ���","1314084481","58.46.172.103");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("2","25","10","6","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314271939950.jpg","","1","","","","1314286300","1","���ڱ�","1314271939","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("3","25","10","1","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314271941411.jpg","","0","","","","1314286534","1","ͨ��","1314271941","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("4","25","10","","1","data/upfiles/images/2011-08/25/25_attestation_13142720046.jpg","","0","","","","1314286584","1","ͨ��","1314272004","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("5","25","10","","1","data/upfiles/images/2011-08/25/25_attestation_13142720295.jpg","","0","","","","1314287140","1","ͨ��","1314272029","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("6","25","10","","1","data/upfiles/images/2011-08/25/25_attestation_13142720567.jpg","","0","","","","1314287129","1","ͨ��","1314272056","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("7","25","27","","1","data/upfiles/images/2011-08/25/25_attestation_13142720883.jpg","","0","","","","1314287156","1","ͨ��","1314272089","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("8","25","10","","1","data/upfiles/images/2011-08/25/25_attestation_13142721175.jpg","","0","","","","1314287113","1","ͨ��","1314272117","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("9","25","18","","1","data/upfiles/images/2011-08/25/25_attestation_13142721855.jpg","","1","","","","1314287184","1","��ס�����޺�ͬ","1314272185","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("10","25","19","","1","data/upfiles/images/2011-08/25/25_attestation_13142722283.jpg","","2","","","","1314287096","1","����֤ ","1314272228","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("11","25","16","","1","data/upfiles/images/2011-08/25/25_attestation_13142722878.JPG","","0","","","","1314287065","1","ͨ��","1314272287","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("12","25","16","","1","data/upfiles/images/2011-08/25/25_attestation_13142723135.JPG","","2","","","","1314287050","1","Ӫҵִ��","1314272313","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("13","25","11","","1","data/upfiles/images/2011-08/25/25_attestation_13142724216.JPG","","1","","","","1314287010","1","��ҵ֤��","1314272422","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("14","25","9","P1040163","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314272477700.JPG","","2","","","","1314286954","1","ͨ��","1314272478","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("15","25","9","P1040161","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314272482828.JPG","","0","","","","1314286983","1","ͨ��","1314272482","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("16","25","9","","1","data/upfiles/images/2011-08/25/25_attestation_13142725363.JPG","","0","","","","1314286966","1","ͨ��","1314272536","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("17","25","8","","1","data/upfiles/images/2011-08/25/25_attestation_13142725722.JPG","","1","","","","1314286413","1","��������֤","1314272573","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("18","25","7","","1","data/upfiles/images/2011-08/25/25_attestation_13142726052.JPG","","0","","","","1314286837","1","ͨ��","1314272606","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("19","25","22","","1","data/upfiles/images/2011-08/25/25_attestation_13142732397.jpg","","2","","","","1314286904","1","˰��Ǽ�֤","1314273240","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("20","25","3","","1","data/upfiles/images/2011-08/25/25_attestation_13142733849.JPG","","1","","","","1314286819","1","���ñ���","1314273390","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("21","25","3","","1","data/upfiles/images/2011-08/25/25_attestation_13142734822.jpg","","0","","","","1314286858","1","ͨ��","1314273483","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("22","25","14","������ˮ8","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314273648793.JPG","","0","","","","1314286737","1","ͨ��","1314273648","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("23","25","14","0","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314273651429.jpg","","0","","","","1314286697","1","ͨ��","1314273651","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("24","25","14","","1","data/upfiles/images/2011-08/25/25_attestation_13142737894.JPG","","0","","","","1314286681","1","ͨ��","1314273790","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("25","25","14","","1","data/upfiles/images/2011-08/25/25_attestation_13142738144.JPG","","0","","","","1314286666","1","ͨ��","1314273815","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("26","25","14","","1","data/upfiles/images/2011-08/25/25_attestation_13142738941.JPG","","0","","","","1314286645","1","ͨ��","1314273895","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("27","25","14","","1","data/upfiles/images/2011-08/25/25_attestation_13142739226.JPG","","0","","","","1314286630","1","ͨ��","1314273922","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("28","25","14","","1","data/upfiles/images/2011-08/25/25_attestation_13142739522.JPG","","0","","","","1314286615","1","ͨ��","1314273953","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("29","25","14","","1","data/upfiles/images/2011-08/25/25_attestation_13142739967.JPG","","0","","","","1314286565","1","ͨ��","1314273996","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("30","25","14","","1","data/upfiles/images/2011-08/25/25_attestation_13142740343.JPG","","0","","","","1314286549","1","ͨ��","1314274035","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("31","25","14","","1","data/upfiles/images/2011-08/25/25_attestation_13142740712.JPG","","2","","","","1314286379","1","����������ˮ","1314274071","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("32","25","14","��Ƭ0058","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314274111632.jpg","","0","","","","1314286723","1","ͨ��","1314274114","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("33","25","14","��Ƭ0057","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314274128844.jpg","","0","","","","1314286711","1","ͨ��","1314274132","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("34","25","20","P1040226","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314274214141.JPG","","1","","","","1314286330","1","������","1314274214","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("35","25","20","P1040224","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314274219881.JPG","","0","","","","1314286762","1","ͨ��","1314274220","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("36","25","20","P1040226","1","data/upfiles/images/2011-08/25/25_attestation_litpic_1314274263837.JPG","","0","","","","1314286749","1","ͨ��","1314274263","113.142.216.204");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("37","28","25","DSC_9497","1","data/upfiles/images/2011-08/25/28_attestation_litpic_1314284881377.jpg","","0","","","","1314754048","1","�����","1314284883","123.87.181.158");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("38","28","25","fan","1","data/upfiles/images/2011-08/25/28_attestation_litpic_1314284893911.jpg","","0","","","","1314754038","1","�����","1314284895","123.87.181.158");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("39","28","25","zhen","1","data/upfiles/images/2011-08/25/28_attestation_litpic_1314284978465.jpg","","1","","","","1314754026","1","�籣","1314284979","123.87.181.158");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("40","28","3","����","1","data/upfiles/images/2011-08/25/28_attestation_litpic_1314285057892.jpg","","2","","","","1314754011","1","���ñ���","1314285059","123.87.181.158");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("41","28","3","����2","1","data/upfiles/images/2011-08/25/28_attestation_litpic_1314285077632.jpg","","0","","","","1314753995","1","�����","1314285079","123.87.181.158");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("42","28","3","����3","1","data/upfiles/images/2011-08/25/28_attestation_litpic_1314285162939.jpg","","0","","","","1314753984","1","�����","1314285164","123.87.181.158");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("43","33","24","","1","data/upfiles/images/2011-08/30/33_attestation_13146812389.jpg","","1","","","","1314753969","1","��ʻ֤","1314681238","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("44","33","23","","1","data/upfiles/images/2011-08/30/33_attestation_13146812934.jpg","","0","","","","1314753950","1","�����","1314681294","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("45","33","20","","1","data/upfiles/images/2011-08/30/33_attestation_13146813796.jpg","","1","","","","1314753939","1","������","1314681381","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("46","33","19","","1","data/upfiles/images/2011-08/30/33_attestation_13146814232.jpg","","2","","","","1314753924","1","����֤","1314681424","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("47","33","19","","1","data/upfiles/images/2011-08/30/33_attestation_13146814444.jpg","","0","","","","1314753908","1","�����","1314681444","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("48","33","19","","1","data/upfiles/images/2011-08/30/33_attestation_13146814664.jpg","","0","","","","1314753897","1","�����","1314681468","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("49","0","18","","1","data/upfiles/images/2011-08/30/_attestation_13146816132.jpg","","0","","","","1314753885","1","�����","1314681614","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("50","33","18","","1","data/upfiles/images/2011-08/30/33_attestation_13146816866.jpg","","1","","","","1314753873","1","��ƾ��ͬ","1314681687","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("51","33","17","","1","data/upfiles/images/2011-08/30/33_attestation_13146817265.jpg","","1","","","","1314753857","1","ˮ�緢Ʊ","1314681727","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("52","33","13","","1","data/upfiles/images/2011-08/30/33_attestation_13146827151.jpg","","1","","","","1314753838","1","����֤��","1314682717","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("53","33","12","","1","data/upfiles/images/2011-08/30/33_attestation_13146828609.jpg","","0","","","","1314753816","1","�����","1314682860","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("54","33","12","","1","data/upfiles/images/2011-08/30/33_attestation_13146828981.jpg","","0","","","","1314753805","1","�����","1314682898","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("55","33","12","","1","data/upfiles/images/2011-08/30/33_attestation_13146831210.jpg","","1","","","","1314753793","1","���д���������ˮ","1314683121","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("56","33","10","","1","data/upfiles/images/2011-08/30/33_attestation_13146831577.jpg","","0","","","","1314753766","1","�����","1314683157","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("57","33","10","","1","data/upfiles/images/2011-08/30/33_attestation_13146832414.jpg","","0","","","","1314753755","1","�����","1314683241","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("58","33","10","","1","data/upfiles/images/2011-08/30/33_attestation_13146832684.jpg","","2","","","","1314753744","1","���ڱ�","1314683269","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("59","33","3","","1","data/upfiles/images/2011-08/30/33_attestation_13146834757.jpg","","2","","","","1314753721","1","�������ñ���","1314683476","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("60","33","3","","1","data/upfiles/images/2011-08/30/33_attestation_13146834969.jpg","","0","","","","1314753705","1","�����","1314683497","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("61","33","5","t1","1","data/upfiles/images/2011-08/30/33_attestation_litpic_1314683963866.jpg","","0","","","","1314753694","1","�����","1314683964","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("62","33","5","t2","1","data/upfiles/images/2011-08/30/33_attestation_litpic_1314683968621.jpg","","0","","","","1314753682","1","�����","1314683969","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("63","33","5","t3","1","data/upfiles/images/2011-08/30/33_attestation_litpic_1314684022718.jpg","","0","","","","1314753670","1","�����","1314684022","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("64","33","5","t4","1","data/upfiles/images/2011-08/30/33_attestation_litpic_1314684026901.jpg","","0","","","","1314753659","1","�����","1314684027","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("65","33","5","t5","1","data/upfiles/images/2011-08/30/33_attestation_litpic_1314684054923.jpg","","0","","","","1314753646","1","�����","1314684055","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("66","33","5","t6","1","data/upfiles/images/2011-08/30/33_attestation_litpic_1314684059612.jpg","","0","","","","1314753630","1","�����","1314684060","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("67","33","5","t7","1","data/upfiles/images/2011-08/30/33_attestation_litpic_1314684089112.jpg","","0","","","","1314753615","1","�����","1314684090","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("68","33","5","t8","1","data/upfiles/images/2011-08/30/33_attestation_litpic_1314684095900.jpg","","1","","","","1314753597","1","�ֻ�ͨ����¼�嵥","1314684096","113.246.41.133");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("69","28","11","��ҵ֤","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766070197.jpg","","0","","","","","","","1314766071","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("70","28","11","ѧλ","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766080576.jpg","","0","","","","","","","1314766082","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("71","28","1","ְ��","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766139796.jpg","","0","","","","","","","1314766140","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("72","28","1","�ʸ�","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766145865.jpg","","0","","","","","","","1314766146","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("73","28","5","1","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766259247.jpg","","0","","","","","","","1314766259","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("74","28","5","2","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766262374.jpg","","0","","","","","","","1314766263","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("75","28","5","3","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766541989.jpg","","0","","","","","","","1314766541","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("76","28","5","4","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766544456.jpg","","0","","","","","","","1314766545","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("77","28","5","5","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766660780.jpg","","0","","","","","","","1314766661","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("78","28","5","6","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766664719.jpg","","0","","","","","","","1314766664","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("79","28","5","7","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766697656.jpg","","0","","","","","","","1314766697","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("80","28","5","8","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766700320.jpg","","0","","","","","","","1314766701","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("81","28","5","7","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766752389.jpg","","0","","","","","","","1314766752","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("82","28","5","8","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766755409.jpg","","0","","","","","","","1314766756","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("83","28","5","9","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766790861.jpg","","0","","","","","","","1314766790","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("84","28","5","10","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766793257.jpg","","0","","","","","","","1314766794","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("85","28","5","9","0","data/upfiles/images/2011-08/31/28_attestation_13147668356.jpg","","0","","","","","","","1314766835","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("86","28","5","13","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766877349.jpg","","0","","","","","","","1314766878","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("87","28","5","14","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766881477.jpg","","0","","","","","","","1314766881","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("88","28","5","17","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766901788.jpg","","0","","","","","","","1314766901","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("89","28","5","18","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766904757.jpg","","0","","","","","","","1314766904","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("90","28","5","19","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766953501.jpg","","0","","","","","","","1314766954","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("91","28","5","20","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314766956845.jpg","","0","","","","","","","1314766957","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("92","28","5","21","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767184169.jpg","","0","","","","","","","1314767184","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("93","28","5","22","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767187849.jpg","","0","","","","","","","1314767188","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("94","28","5","26","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767265412.jpg","","0","","","","","","","1314767266","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("95","28","5","27","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767268818.jpg","","0","","","","","","","1314767268","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("96","28","5","29","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767290975.jpg","","0","","","","","","","1314767291","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("97","28","5","30","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767293508.jpg","","0","","","","","","","1314767294","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("98","28","5","31","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767340336.jpg","","0","","","","","","","1314767340","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("99","28","5","32","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767343726.jpg","","0","","","","","","","1314767344","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("100","28","5","33","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767425939.jpg","","0","","","","","","","1314767425","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("101","28","5","34","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767428814.jpg","","0","","","","","","","1314767429","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("102","28","5","35","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767457915.jpg","","0","","","","","","","1314767457","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("103","28","5","36","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767460279.jpg","","0","","","","","","","1314767460","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("104","28","9","13","1","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767745824.jpg","","2","","","","1314856010","1","���֤","1314767746","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("105","28","10","13","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767783917.jpg","","0","","","","","","","1314767784","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("106","28","10","14","2","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767794390.jpg","","0","","","","1314855988","1","���ڱ�","1314767795","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("107","28","13","1","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767830479.jpg","","0","","","","","","","1314767832","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("108","28","13","2","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767846831.jpg","","0","","","","","","","1314767848","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("109","28","13","3","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767884840.jpg","","0","","","","","","","1314767886","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("110","28","13","4","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767898313.jpg","","0","","","","","","","1314767900","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("111","28","13","5","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767939178.jpg","","0","","","","","","","1314767941","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("112","28","13","6","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314767960560.jpg","","0","","","","","","","1314767962","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("113","28","13","7","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314768044133.jpg","","0","","","","","","","1314768046","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("114","28","13","8","0","","","0","","","","","","","1314768048","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("115","28","13","9","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314768089410.jpg","","0","","","","","","","1314768091","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("116","28","13","10","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314768107664.jpg","","0","","","","","","","1314768109","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("117","28","13","11","0","data/upfiles/images/2011-08/31/28_attestation_litpic_1314768276888.jpg","","0","","","","","","","1314768278","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("118","28","13","12","1","data/upfiles/images/2011-08/31/28_attestation_litpic_1314768285522.jpg","","2","","","","1314855960","1","��λ֤��","1314768287","123.87.183.142");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("119","28","12","1","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837112618.jpg","","0","","","","","","","1314837113","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("120","28","12","2","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837116486.jpg","","0","","","","","","","1314837116","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("121","28","12","3","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837158469.jpg","","0","","","","","","","1314837159","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("122","28","12","4","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837162583.jpg","","0","","","","","","","1314837162","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("123","28","12","5","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837234755.jpg","","0","","","","","","","1314837235","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("124","28","12","6","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837238199.jpg","","0","","","","","","","1314837239","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("125","28","12","7","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837263787.jpg","","0","","","","","","","1314837263","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("126","28","12","8","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837266348.jpg","","0","","","","","","","1314837267","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("127","28","12","9","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837289351.jpg","","0","","","","","","","1314837289","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("128","28","12","10","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837293349.jpg","","0","","","","","","","1314837293","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("129","28","12","11","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837352421.jpg","","0","","","","","","","1314837353","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("130","28","12","12","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837356953.jpg","","0","","","","1314856026","1","�����","1314837357","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("131","28","12","13","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837415635.jpg","","0","","","","1314855936","1","�����","1314837416","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("132","28","12","14","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837419687.jpg","","0","","","","1314855922","1","�����","1314837419","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("133","28","12","15","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837459735.jpg","","0","","","","1314855912","1","�����","1314837460","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("134","28","12","16","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837463184.jpg","","0","","","","1314855898","1","�����","1314837464","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("135","28","12","17","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837482187.jpg","","2","","","","1314855886","1","���д������ʼ�¼�����ת�˴���¼","1314837482","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("136","28","7","���� ����","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837589398.JPG","","1","","","","1314855866","1","��������֤","1314837590","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("137","28","7","���� ����","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837613855.JPG","","0","","","","1314855846","1","�����","1314837614","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("138","28","17","fei","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837705741.jpg","","1","","","","1314855830","1","ˮ�緢Ʊ","1314837707","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("139","28","17","��","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837709123.jpg","","0","","","","1314855814","1","�����","1314837709","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("140","28","2","1","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837810596.png","","0","","","","","","","1314837810","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("141","28","2","2","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837813613.png","","0","","","","","","","1314837814","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("142","28","2","3","0","data/upfiles/images/2011-09/01/28_attestation_litpic_1314837838602.png","","0","","","","","","","1314837838","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("143","28","2","4","1","data/upfiles/images/2011-09/01/28_attestation_litpic_1314842944533.jpg","","0","","","","1314855793","1","�����","1314842945","123.87.177.13");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("144","38","10","����ҳ","1","data/upfiles/images/2011-09/01/38_attestation_13148462727.jpg","","0","","","","1314855763","1","�����","1314846273","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("145","0","10","����ҳ","1","data/upfiles/images/2011-09/01/_attestation_13148463529.jpg","","0","","","","1314855748","1","�����","1314846353","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("146","38","10","����ҳ","1","data/upfiles/images/2011-09/01/38_attestation_13148464172.jpg","","2","","","","1314855736","1","���ڱ�","1314846417","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("147","38","8","�Ϲ�","1","data/upfiles/images/2011-09/01/38_attestation_13148464889.jpg","","0","","","","1314855717","1","�����","1314846488","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("148","38","7","","1","data/upfiles/images/2011-09/01/38_attestation_13148465378.jpg","","1","","","","1314855703","1","��������֤","1314846537","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("149","38","9","���֤","1","data/upfiles/images/2011-09/01/38_attestation_13148465819.jpg","","2","","","","1314855685","1","���֤","1314846581","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("150","38","20","","1","data/upfiles/images/2011-09/01/38_attestation_13148466402.jpg","","1","","","","1314855665","1","������","1314846640","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("151","38","19","http_imgloadCA8WDIL8","1","data/upfiles/images/2011-09/01/38_attestation_litpic_1314846831528.jpg","","0","","","","1314855645","1","�����","1314846831","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("152","38","19","http_imgloadCAIJNWFH","1","data/upfiles/images/2011-09/01/38_attestation_litpic_1314846833347.jpg","","0","","","","1314855634","1","�����","1314846833","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("153","38","19","http_imgloadCATZX0KX","1","data/upfiles/images/2011-09/01/38_attestation_litpic_1314846902888.jpg","","0","","","","1314855615","1","�����","1314846903","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("154","38","19","http_imgloadCA8W3HK4","1","data/upfiles/images/2011-09/01/38_attestation_litpic_1314846904550.jpg","","2","","","","1314855594","1","����֤ ","1314846905","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("155","38","5","shouye","1","data/upfiles/images/2011-09/01/38_attestation_litpic_1314847879352.JPG","","1","","","","1314855571","1","�ֻ�ͨ����¼�嵥","1314847880","113.117.117.22");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("156","38","5","QQ��ͼ20110902075844A","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314921752582.jpg","","0","","","","","","","1314921752","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("157","38","5","QQ��ͼ20110902075939B","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314921756354.jpg","","0","","","","","","","1314921756","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("158","38","5","QQ��ͼ20110902080042C","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314921783418.jpg","","0","","","","","","","1314921784","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("159","38","5","QQ��ͼ20110902080116D","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314921786616.jpg","","0","","","","","","","1314921787","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("160","38","5","QQ��ͼ20110902080210E","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314921812543.jpg","","0","","","","","","","1314921812","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("161","38","1","3���µ�֧����������ˮ","0","data/upfiles/images/2011-09/02/38_attestation_13149228307.JPG","","0","","","","","","","1314922830","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("162","38","1","֧����3����������ˮ","0","data/upfiles/images/2011-09/02/38_attestation_13149233921.JPG","","0","","","","","","","1314923392","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("163","38","12","��ҳ","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314923549709.JPG","","0","","","","","","","1314923549","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("164","38","12","61","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314923552441.JPG","","0","","","","","","","1314923553","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("165","38","12","62","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314923609220.JPG","","0","","","","","","","1314923609","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("166","38","12","63","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314923613392.JPG","","0","","","","","","","1314923613","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("167","38","12","","0","data/upfiles/images/2011-09/02/38_attestation_13149239941.JPG","","0","","","","","","","1314923994","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("168","38","12","","0","data/upfiles/images/2011-09/02/38_attestation_13149240305.JPG","","0","","","","","","","1314924031","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("169","38","12","65","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314924076480.JPG","","0","","","","","","","1314924077","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("170","38","12","66","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314924080279.JPG","","0","","","","","","","1314924081","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("171","38","12","67","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314924151720.JPG","","0","","","","","","","1314924151","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("172","38","12","68","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314924154758.JPG","","0","","","","","","","1314924155","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("173","38","12","69","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314924176267.JPG","","0","","","","","","","1314924177","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("174","38","12","70","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314924180982.JPG","","0","","","","","","","1314924181","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("175","38","12","72","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314924200828.JPG","","0","","","","","","","1314924201","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("176","38","12","73","0","data/upfiles/images/2011-09/02/38_attestation_litpic_1314924204815.JPG","","0","","","","","","","1314924205","113.117.116.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("177","36","20","","0","data/upfiles/images/2011-09/08/36_attestation_13154733271.jpg","","0","","","","","","","1315473327","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("178","36","17","shui1","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473449388.jpg","","0","","","","","","","1315473449","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("179","36","17","shui2","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473451678.jpg","","0","","","","","","","1315473452","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("180","36","17","shui3","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473463855.jpg","","0","","","","","","","1315473464","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("181","36","12","yianhang2","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473500473.JPG","","0","","","","","","","1315473500","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("182","36","12","yinhang3","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473508227.JPG","","0","","","","","","","1315473509","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("183","36","12","yinhang4","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473580442.JPG","","0","","","","","","","1315473580","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("184","36","12","yinhang5","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473590290.JPG","","0","","","","","","","1315473591","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("185","36","12","yinhang6","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473625996.JPG","","0","","","","","","","1315473626","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("186","36","12","yinhang7","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473633819.JPG","","0","","","","","","","1315473634","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("187","36","12","yinhang8","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473706214.JPG","","0","","","","","","","1315473707","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("188","36","5","shouji1","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473775721.JPG","","0","","","","","","","1315473776","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("189","36","5","shouji2","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473780292.JPG","","0","","","","","","","1315473780","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("190","36","5","shouji3","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473896532.JPG","","0","","","","","","","1315473897","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("191","36","5","shouji4","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473904585.JPG","","0","","","","","","","1315473904","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("192","36","8","jiazheng","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473936889.jpg","","0","","","","","","","1315473936","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("193","36","7","jiafan","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473967691.jpg","","0","","","","","","","1315473967","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("194","36","10","hu1","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473992876.jpg","","0","","","","","","","1315473992","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("195","36","10","hu2","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315473995191.jpg","","0","","","","","","","1315473995","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("196","36","10","hu3","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315474008442.jpg","","0","","","","","","","1315474008","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("197","36","10","hu4","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315474009586.jpg","","0","","","","","","","1315474009","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("198","36","10","hu5","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315474035354.jpg","","0","","","","","","","1315474035","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("199","36","12","yinhang1","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315474109502.JPG","","0","","","","","","","1315474110","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("200","36","3","xinyong","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315474132519.jpg","","0","","","","","","","1315474133","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("201","36","13","shouru","0","data/upfiles/images/2011-09/08/36_attestation_litpic_1315474153819.jpg","","0","","","","","","","1315474153","222.190.123.194");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("202","38","3","���ñ��棬�Ͱ���","0","data/upfiles/images/2011-09/09/38_attestation_13155197684.JPG","","0","","","","","","","1315519768","113.117.119.9");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("203","44","23","","0","data/upfiles/images/2011-09/10/44_attestation_13156117620.jpg","","0","","","","","","","1315611762","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("204","44","10","","0","data/upfiles/images/2011-09/10/44_attestation_13156118411.jpg","","0","","","","","","","1315611841","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("205","44","6","","0","data/upfiles/images/2011-09/10/44_attestation_13156120781.jpg","","0","","","","","","","1315612078","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("206","44","12","","0","data/upfiles/images/2011-09/10/44_attestation_13156121059.jpg","","0","","","","","","","1315612105","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("207","44","3","","0","data/upfiles/images/2011-09/10/44_attestation_13156121394.jpg","","0","","","","","","","1315612140","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("208","44","8","","0","data/upfiles/images/2011-09/10/44_attestation_13156122054.jpg","","0","","","","","","","1315612206","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("209","44","9","","0","data/upfiles/images/2011-09/10/44_attestation_13156122256.jpg","","0","","","","","","","1315612225","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("210","49","18","","0","data/upfiles/images/2011-09/10/49_attestation_13156123581.jpg","","0","","","","","","","1315612358","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("211","49","5","","0","data/upfiles/images/2011-09/10/49_attestation_13156123773.jpg","","0","","","","","","","1315612378","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("212","49","12","","0","data/upfiles/images/2011-09/10/49_attestation_13156123945.jpg","","0","","","","","","","1315612394","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("213","49","10","","0","data/upfiles/images/2011-09/10/49_attestation_13156124136.jpg","","0","","","","","","","1315612413","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("214","49","9","","0","data/upfiles/images/2011-09/10/49_attestation_13156124316.jpg","","0","","","","","","","1315612432","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("215","49","13","","0","data/upfiles/images/2011-09/10/49_attestation_13156124548.jpg","","0","","","","","","","1315612454","113.218.120.128");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("216","28","27","����֤��","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315631925608.jpg","","0","","","","","","","1315631927","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("217","28","26","δ����-1","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315631999111.jpg","","0","","","","","","","1315632001","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("218","28","26","δ����-2","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632017397.jpg","","0","","","","","","","1315632020","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("219","28","26","δ����-3","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632063364.jpg","","0","","","","","","","1315632065","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("220","28","26","δ����-4","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632076877.jpg","","0","","","","","","","1315632079","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("221","28","26","δ����-5","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632130910.jpg","","0","","","","","","","1315632133","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("222","28","26","δ����-6","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632143140.jpg","","0","","","","","","","1315632145","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("223","28","26","δ����-7","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632244630.jpg","","0","","","","","","","1315632246","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("224","28","26","δ����-8","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632257111.jpg","","0","","","","","","","1315632259","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("225","28","26","δ����-9","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632296218.jpg","","0","","","","","","","1315632298","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("226","28","26","δ����-10","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632305987.jpg","","0","","","","","","","1315632307","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("227","28","20","http_imgload[10]","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632349576.jpg","","0","","","","","","","1315632349","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("228","28","20","http_imgload[16]","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632353838.jpg","","0","","","","","","","1315632353","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("229","28","20","http_imgload[21]","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632441260.jpg","","0","","","","","","","1315632441","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("230","28","12","��ѯ��1","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632579131.jpg","","0","","","","","","","1315632581","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("231","28","12","��ѯ��2","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632614549.jpg","","0","","","","","","","1315632616","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("232","28","10","����1","0","data/upfiles/images/2011-09/10/28_attestation_litpic_1315632825602.JPG","","0","","","","","","","1315632826","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("233","28","10","����2","0","","","0","","","","","","","1315632831","123.87.177.3");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("234","28","4","ɨ��","0","","","0","","","","","","","1315706120","123.87.178.188");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("235","37","8","","0","data/upfiles/images/2011-09/18/37_attestation_13162755627.jpg","","0","","","","","","","1316275562","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("236","37","7","����","0","data/upfiles/images/2011-09/18/37_attestation_13162755930.jpg","","0","","","","","","","1316275593","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("237","37","18","","0","data/upfiles/images/2011-09/18/37_attestation_13162757850.jpg","","0","","","","","","","1316275785","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("238","37","10","2","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316276015988.jpg","","0","","","","","","","1316276016","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("239","37","10","psu","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316276016810.jpg","","0","","","","","","","1316276016","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("240","37","10","1","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316276029290.jpg","","0","","","","","","","1316276029","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("241","37","13","1","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316276144353.jpg","","0","","","","","","","1316276144","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("242","37","13","psu","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316276145192.jpg","","0","","","","","","","1316276145","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("243","37","1","","0","data/upfiles/images/2011-09/18/37_attestation_13162762200.jpg","","0","","","","","","","1316276220","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("244","37","20","2","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316276292219.jpg","","0","","","","","","","1316276292","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("245","37","20","psu","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316276292689.jpg","","0","","","","","","","1316276293","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("246","37","5","8�·�","0","data/upfiles/images/2011-09/18/37_attestation_13162764122.jpg","","0","","","","","","","1316276412","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("247","37","5","8�·�","0","data/upfiles/images/2011-09/18/37_attestation_13162764339.jpg","","0","","","","","","","1316276433","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("248","37","5","8�·�","0","data/upfiles/images/2011-09/18/37_attestation_13162764541.jpg","","0","","","","","","","1316276454","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("249","37","5","7�·�","0","data/upfiles/images/2011-09/18/37_attestation_13162765628.jpg","","0","","","","","","","1316276562","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("250","37","5","7�·�","0","data/upfiles/images/2011-09/18/37_attestation_13162766014.jpg","","0","","","","","","","1316276601","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("251","37","5","7�·�","0","data/upfiles/images/2011-09/18/37_attestation_13162766262.jpg","","0","","","","","","","1316276626","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("252","37","12","6","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277268922.jpg","","0","","","","","","","1316277268","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("253","37","12","δ����","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277269938.jpg","","0","","","","","","","1316277269","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("254","37","12","4","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277286686.jpg","","0","","","","","","","1316277286","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("255","37","12","5","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277287541.jpg","","0","","","","","","","1316277287","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("256","37","12","2","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277305508.jpg","","0","","","","","","","1316277306","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("257","37","12","3","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277307501.jpg","","0","","","","","","","1316277307","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("258","37","12","1","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277320294.jpg","","0","","","","","","","1316277321","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("259","37","1","1","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277673920.jpg","","0","","","","","","","1316277673","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("260","37","1","2","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277673148.jpg","","0","","","","","","","1316277674","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("261","37","3","2","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277783622.jpg","","0","","","","","","","1316277783","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("262","37","3","3","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277783865.jpg","","0","","","","","","","1316277783","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("263","37","3","1","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277797188.jpg","","0","","","","","","","1316277797","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("264","37","2","2","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277914794.jpg","","0","","","","","","","1316277915","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("265","37","2","δ����","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277915131.jpg","","0","","","","","","","1316277916","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("266","37","2","1","0","data/upfiles/images/2011-09/18/37_attestation_litpic_1316277927534.jpg","","0","","","","","","","1316277928","124.165.237.94");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("267","52","20","ͼƬ 002","0","data/upfiles/images/2011-09/18/52_attestation_litpic_1316336066876.jpg","","0","","","","","","","1316336066","117.65.27.112");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("268","52","18","12","0","data/upfiles/images/2011-09/18/52_attestation_litpic_1316336138549.jpg","","0","","","","","","","1316336140","117.65.27.112");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("269","52","17","�ʵ�����","0","data/upfiles/images/2011-09/18/52_attestation_litpic_1316336176446.jpg","","0","","","","","","","1316336176","117.65.27.112");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("270","52","17","�ʵ���","0","data/upfiles/images/2011-09/18/52_attestation_litpic_1316336181301.JPG","","0","","","","","","","1316336181","117.65.27.112");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("271","52","12","����1","0","data/upfiles/images/2011-09/18/52_attestation_litpic_1316336270848.jpg","","0","","","","","","","1316336270","117.65.27.112");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("272","52","12","����2","0","data/upfiles/images/2011-09/18/52_attestation_litpic_1316336278789.jpg","","0","","","","","","","1316336279","117.65.27.112");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("273","1","27","","0","data/upfiles/images/2011-10/16/1_attestation_13187599282.JPG","","0","","","","","","","1318759929","49.83.110.119");

insert into `dw_attestation` ( `id`,`user_id`,`type_id`,`name`,`status`,`litpic`,`content`,`jifen`,`pic`,`pic2`,`pic3`,`verify_time`,`verify_user`,`verify_remark`,`addtime`,`addip`) values ("274","0","27","","0","","","0","","","","","","","1318822285","117.93.22.200");

