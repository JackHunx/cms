insert into `dw_scrollpic` ( `id`,`site_id`,`status`,`order`,`flag`,`type_id`,`url`,`name`,`pic`,`summary`,`hits`,`addtime`,`addip`) values ("13","0","1","10","","1","","3","data/upfiles/images/2012-03/15/1_scrollpic_13317961379.jpg","","0","1314409718","58.46.179.32");

insert into `dw_scrollpic` ( `id`,`site_id`,`status`,`order`,`flag`,`type_id`,`url`,`name`,`pic`,`summary`,`hits`,`addtime`,`addip`) values ("17","0","1","10","","1","themes/ruizhict/images/banner3.jpg","1","data/upfiles/images/2012-03/14/1_scrollpic_13317064714.jpg","","0","1314683971","58.46.184.119");

insert into `dw_scrollpic` ( `id`,`site_id`,`status`,`order`,`flag`,`type_id`,`url`,`name`,`pic`,`summary`,`hits`,`addtime`,`addip`) values ("15","0","1","10","","1","","2","data/upfiles/images/2012-03/15/1_scrollpic_13317956935.jpg","","0","1314595855","58.46.162.87");

