insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("1","10","����״��","user_marry","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("2","10","�û�-��Ů","user_child","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("3","10","�û�-ѧ��","user_education","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("4","10","�û�-����","user_income","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("5","10","�û�-�籣","user_shebao","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("6","10","�û�-ס������","user_housing","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("7","10","�û�-�Ƿ��г�","user_car","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("8","10","�û�-�Ƿ�����","user_late","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("9","10","�û�-����״��","user_status","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("10","10","�û�-��˾����","user_company_type","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("11","10","�û�-��˾��ҵ","user_company_industry","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("12","10","�û�-��������","user_company_jibie","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("13","10","�û�-ְ λ","user_company_office","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("14","10","�û�-��������","user_company_workyear","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("15","10","�û�-��Ӫ����","user_private_place","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("16","10","�û�-���з���","user_finance_property","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("17","10","�û�-��������","user_finance_car","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("18","10","�û�-��ϵ�˹�ϵ","user_relation","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("19","10","�����;","borrow_use","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("20","10","�������","borrow_time_limit","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("21","10","���ʽ","borrow_style","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("22","10","���Ͷ����","borrow_lowest_account","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("23","10","���Ͷ���ܶ�","borrow_most_account","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("24","10","��Чʱ��","borrow_valid_time","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("25","10","�ʻ�����","account_bank","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("26","10","����Ϣ����","message_type","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("27","10","��˽��������","yinsi","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("28","10","���뱣������","pwd_protection","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("29","10","��������","friends_type","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("30","10","�û��ʽ����","account_type","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("31","10","56������","nation","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("32","10","֤�����","card_type","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("33","10","�б��״̬","borrow_type","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("34","10","������;","borrow_yongtu","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("35","10","��������","borrow_qixian","0","");

insert into `dw_linkage_type` ( `id`,`order`,`name`,`nid`,`addtime`,`addip`) values ("36","10","��Χ","account_amange","0","");

