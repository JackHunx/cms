insert into `dw_friends_request` ( `id`,`user_id`,`friends_userid`,`status`,`type`,`content`,`addtime`,`addip`) values ("2","4","28","0","0","","1315631340","123.87.177.3");

insert into `dw_friends_request` ( `id`,`user_id`,`friends_userid`,`status`,`type`,`content`,`addtime`,`addip`) values ("3","13","25","0","0","","1315643622","124.114.177.90");

