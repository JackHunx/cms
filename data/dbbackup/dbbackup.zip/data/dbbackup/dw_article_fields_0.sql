insert into `dw_article_fields` ( `aid`,`files`) values ("70","");

insert into `dw_article_fields` ( `aid`,`files`) values ("71","");

insert into `dw_article_fields` ( `aid`,`files`) values ("72","");

insert into `dw_article_fields` ( `aid`,`files`) values ("73","");

insert into `dw_article_fields` ( `aid`,`files`) values ("74","");

insert into `dw_article_fields` ( `aid`,`files`) values ("75","");

insert into `dw_article_fields` ( `aid`,`files`) values ("76","");

insert into `dw_article_fields` ( `aid`,`files`) values ("77","");

insert into `dw_article_fields` ( `aid`,`files`) values ("78","");

insert into `dw_article_fields` ( `aid`,`files`) values ("79","");

insert into `dw_article_fields` ( `aid`,`files`) values ("80","");

insert into `dw_article_fields` ( `aid`,`files`) values ("81","");

insert into `dw_article_fields` ( `aid`,`files`) values ("85","/data/upfiles/annexs/201108221314024190.doc");

insert into `dw_article_fields` ( `aid`,`files`) values ("86","");

insert into `dw_article_fields` ( `aid`,`files`) values ("87","");

insert into `dw_article_fields` ( `aid`,`files`) values ("88","");

insert into `dw_article_fields` ( `aid`,`files`) values ("89","");

insert into `dw_article_fields` ( `aid`,`files`) values ("90","");

insert into `dw_article_fields` ( `aid`,`files`) values ("93","");

insert into `dw_article_fields` ( `aid`,`files`) values ("94","");

insert into `dw_article_fields` ( `aid`,`files`) values ("95","");

insert into `dw_article_fields` ( `aid`,`files`) values ("96","");

insert into `dw_article_fields` ( `aid`,`files`) values ("97","");

insert into `dw_article_fields` ( `aid`,`files`) values ("98","");

insert into `dw_article_fields` ( `aid`,`files`) values ("99","");

insert into `dw_article_fields` ( `aid`,`files`) values ("100","");

insert into `dw_article_fields` ( `aid`,`files`) values ("101","");

insert into `dw_article_fields` ( `aid`,`files`) values ("102","");

insert into `dw_article_fields` ( `aid`,`files`) values ("103","");

insert into `dw_article_fields` ( `aid`,`files`) values ("104","");

insert into `dw_article_fields` ( `aid`,`files`) values ("108","");

