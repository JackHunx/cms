insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("1","14","2","39660240941","468","��ҵ���й��ݷ��к���֧��","495","484.59","10","1","1314677086","����д��ȷ�����п���Ϣ","1314295580","113.65.152.212");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("2","22","3","622909396311227313","468","��ҵ���й��ݷ��к���֧��","1014","1003.5","10","","","","1314375663","113.65.175.155");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("3","24","3","6222022017005426723","300","�������й㶫����Ƕ�֧��","1014","1003.5","10","","","","1314614261","113.65.186.192");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("4","26","3","6222022017005426731","300","�������й㶫����Ƕ�֧��","1014","1003.5","10","","","","1314614425","113.65.186.192");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("5","25","0","6228480220326456815","303","�����д�����֧��","700","690","10","","","","1315652488","124.114.177.90");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("6","27","3","6226682000370791","473","�Ͼ����н���֧��","11215","11204.81","10","","","","1315709576","183.209.42.217");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("7","26","3","6222022017005426731","300","�������й㶫����Ƕ�֧��","1057","1046.79","10","","","","1315709705","113.65.153.25");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("8","24","3","6222022017005426723","300","�������й㶫����Ƕ�֧��","1057","1047.14","10","","","","1315710712","113.65.173.135");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("9","19","3","622909396154454016","468","��ҵ���й��ݷ�������֧��","1162","1152.22","10","","","","1315710760","113.65.154.216");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("10","23","3","622909396140686614","468","��ҵ���й��ݷ��к���֧��","1061","1051.18","10","","","","1315710806","113.65.185.77");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("11","16","3","622909336540185619","468","��ҵ�������ڷ���Ӫҵ��","2368","2357.93","10","","","","1315710952","113.65.185.133");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("12","13","1","6222021914000106777","300","��������","44980","44970","10","1","1315715794","j","1315715718","113.218.4.79");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("13","46","1","6226622000816807","473","�Ͼ����н���֧��","11058","11048.22","10","1","1315716014","ת�뿨����529861","1315715839","183.209.42.217");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("14","45","1","6226622001181102","473","�Ͼ����н���֧����Ԫ��ַ�����","11218","11207.6","10","1","1315716089","ת�뿨����529861","1315715956","183.209.42.217");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("15","27","0","6226682000370791","473","�Ͼ����н���֧��","33491","33481","10","","","","1315876658","180.111.28.225");

insert into `dw_account_cash` ( `id`,`user_id`,`status`,`account`,`bank`,`branch`,`total`,`credited`,`fee`,`verify_userid`,`verify_time`,`verify_remark`,`addtime`,`addip`) values ("16","28","0","13638810629","300","֧����","320","310","10","","","","1315978096","123.87.177.95");

