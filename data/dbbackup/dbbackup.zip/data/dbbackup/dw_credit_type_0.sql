insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("1","������֤","email","10","1","1","0","","0","1282347586","127.0.0.1","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("2","ʵ����֤","realname","10","1","1","0","","0","1282347805","127.0.0.1","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("3","�ֻ���֤","phone","10","1","1","0","","0","1285002118","127.0.0.1","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("4","��Ƶ��֤","video","5","1","0","0","","0","1285002132","127.0.0.1","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("5","�ֳ���֤","scene","20","1","0","0","","0","1285002198","127.0.0.1","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("6","֤������","zhengjian","0","4","0","0","","0","1285002255","127.0.0.1","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("7","Ͷ��ɹ�","invest_success","2","4","0","0","","0","1287675813","119.233.164.154","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("8","���ɹ�","borrow_success","1","4","0","0","","0","1287675904","119.233.164.154","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("9","��̳����","bbs_topics","1","4","0","0","","0","1287676784","119.233.164.154","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("10","��ǰ��ʱ����","borrow_paymengt","2","4","0","0","","0","1287676875","119.233.164.154","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("11","���ڻ���","borrow_paymentover","-5","4","0","0","","0","1287677063","119.233.164.154","0","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("12","��ǰ3�����ϻ���","advance_3day","5","4","","","","","1291940289","221.175.17.200","","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("13","��ǰ1��3�컹��","advance_1day","2","4","","","","","1291940336","221.175.17.200","","");

insert into `dw_credit_type` ( `id`,`name`,`nid`,`value`,`cycle`,`award_times`,`interval`,`remark`,`op_user`,`addtime`,`addip`,`updatetime`,`updateip`) values ("14","��������","advance_day","1","4","","","","","1291940391","221.175.17.200","","");

