insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("1","0","1","0","1","1316777201","1314098900","1015","1015","15","1000","0","0","1314097403","118.253.4.77");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("2","0","1","0","2","1316777201","1314098900","1015","1015","15","1000","0","0","1314098111","118.253.4.77");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("3","0","1","0","3","1316777201","1314098900","1015","1015","15","1000","0","0","1314098179","118.253.4.77");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("4","0","1","0","4","1316941091","1314262797","1007.4","1007.4","7.4","1000","0","0","1314176561","58.46.172.103");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("5","0","1","0","5","1316941091","1314262797","1007.4","1007.4","7.4","1000","0","0","1314188171","222.243.13.108");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("6","0","1","0","6","1316941091","1314262797","1007.4","1007.4","7.4","1000","0","0","1314245199","58.46.193.18");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("7","0","1","0","7","1316941091","1314262797","45.33","45.33","0.33","45","0","0","1314249273","58.46.193.18");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("8","0","1","0","8","1316950538","1314272399","203","203","3","200","0","0","1314251721","58.46.193.18");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("9","0","1","0","9","1317004144","1314596258","101","101","1","100","0","0","1314257328","58.46.193.18");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("10","0","1","0","10","1316941349","1314326175","505","505","5","500","0","0","1314257358","58.46.193.18");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("11","0","1","0","11","1316950538","1314272399","203","203","3","200","0","0","1314257822","58.46.193.18");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("12","0","1","0","12","1316950539","1314272399","495.32","495.32","7.32","488","0","0","1314258383","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("13","0","1","0","13","1316941351","1314326175","505","505","5","500","0","0","1314258415","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("14","0","1","0","14","1316941353","1314326176","1010","1010","10","1000","0","0","1314259420","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("15","0","1","0","15","1317004145","1314596258","101","101","1","100","0","0","1314259440","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("16","0","1","0","16","1317004146","1314596260","101","101","1","100","0","0","1314261504","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("17","0","1","0","17","1317004146","1314596260","101","101","1","100","0","0","1314263481","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("18","0","1","0","18","1317004147","1314596261","101","101","1","100","0","0","1314263522","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("19","0","1","0","19","1317004166","1314325819","304.5","304.5","4.5","300","0","0","1314263594","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("20","0","1","0","20","1317004167","1314325820","1015","1015","15","1000","0","0","1314268849","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("21","0","1","0","21","1317343693","1314717525","503.7","503.7","3.7","500","0","0","1314269144","118.253.11.171");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("22","0","1","0","22","1317343636","1314680942","506.67","506.67","6.67","500","0","0","1314269170","118.253.11.171");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("23","0","1","0","23","1317004166","1314325820","1015","1015","15","1000","0","0","1314269201","118.253.11.171");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("24","0","1","0","24","1317004167","1314325820","1015","1015","15","1000","0","0","1314270173","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("25","0","1","0","25","1317004167","1314325821","1015","1015","15","1000","0","0","1314270219","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("26","0","1","0","26","1317004168","1314325821","1015","1015","15","1000","0","0","1314270755","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("27","0","1","0","27","1317004168","1314325822","1015","1015","15","1000","0","0","1314271764","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("28","0","1","0","28","1317343693","1314717525","1007.4","1007.4","7.4","1000","0","0","1314272031","118.253.11.171");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("29","0","1","0","29","1317343636","1314680942","506.67","506.67","6.67","500","0","0","1314272062","118.253.11.171");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("30","0","1","0","30","1317004168","1314325822","1015","1015","15","1000","0","0","1314272092","118.253.11.171");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("31","0","1","0","31","1317004169","1314325822","1015","1015","15","1000","0","0","1314272449","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("32","0","1","0","32","1317004169","1314325823","596.82","596.82","8.82","588","0","0","1314273004","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("33","0","1","0","33","1317343671","1314677262","1540.39","1540.39","22.76","1517.63","0","0","1314273899","113.65.155.250");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("34","0","1","0","34","1317343693","1314717525","1007.4","1007.4","7.4","1000","0","0","1314275439","58.46.219.35");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("35","0","1","0","35","1317343671","1314677263","1015","1015","15","1000","0","0","1314275464","58.46.219.35");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("36","0","1","0","36","1317468082","1314798827","2030","2030","30","2000","0","0","1314326556","58.46.179.32");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("37","0","1","0","37","1317468082","1314798827","2030","2030","30","2000","0","0","1314327761","58.46.179.32");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("38","0","1","0","38","1317468082","1314798828","2030","2030","30","2000","0","0","1314409789","58.46.179.32");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("39","0","1","0","39","1317468082","1314798828","2030","2030","30","2000","0","0","1314527473","113.219.24.38");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("40","0","1","0","40","1317343671","1314677263","1522.5","1522.5","22.5","1500","0","0","1314527512","113.219.24.38");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("41","0","1","0","41","1317343636","1314680942","506.67","506.67","6.67","500","0","0","1314527533","113.219.24.38");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("42","0","1","0","42","1317343693","1314717525","1007.4","1007.4","7.4","1000","0","0","1314527606","113.219.24.38");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("43","0","1","0","43","1317343673","1314677263","997.11","997.11","14.74","982.37","0","0","1314538735","113.65.172.88");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("44","0","1","0","44","1317343694","1314717525","1007.4","1007.4","7.4","1000","0","0","1314538839","113.65.172.88");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("45","0","1","0","45","1317343694","1314717526","503.7","503.7","3.7","500","0","0","1314538916","113.65.172.88");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("46","0","1","0","46","1317343642","1314680942","506.67","506.67","6.67","500","0","0","1314538946","113.65.172.88");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("47","0","1","0","47","1317343643","1314680943","506.67","506.67","6.67","500","0","0","1314539024","113.65.172.88");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("48","0","1","0","48","1317343643","1314680943","506.67","506.67","6.67","500","0","0","1314539094","113.65.172.88");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("49","0","1","0","49","1317468082","1314798828","2030","2030","30","2000","0","0","1314543711","113.219.77.148");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("50","0","0","0","50","1317274950","","346.19","0","19.17","327.02","0","0","1314596550","58.46.162.87");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("51","0","0","1","50","1319866950","","346.19","0","12.9","333.29","0","0","1314596550","58.46.162.87");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("52","0","0","2","50","1322545350","","346.19","0","6.51","339.68","0","0","1314596550","58.46.162.87");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("53","0","0","0","51","1317343720","","203.04","0","3.04","200","0","0","1314597188","58.46.162.87");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("54","0","0","0","52","1317276141","","276.95","0","15.33","261.62","0","0","1314597741","58.46.162.87");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("55","0","0","1","52","1319868141","","276.95","0","10.32","266.63","0","0","1314597741","58.46.162.87");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("56","0","0","2","52","1322546541","","276.95","0","5.21","271.74","0","0","1314597741","58.46.162.87");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("57","0","0","0","53","1317343720","","203.04","0","3.04","200","0","0","1314597766","58.46.162.87");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("58","0","0","0","54","1317343720","","609.11","0","9.11","600","0","0","1314617566","113.219.1.152");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("59","0","0","0","55","1317296018","","415.43","0","23","392.43","0","0","1314617618","113.219.1.152");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("60","0","0","1","55","1319888018","","415.43","0","15.48","399.95","0","0","1314617618","113.219.1.152");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("61","0","0","2","55","1322566418","","415.43","0","7.81","407.62","0","0","1314617618","113.219.1.152");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("62","0","1","0","56","1317468082","1314798828","3045","3045","45","3000","0","0","1314677371","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("63","0","0","0","57","1318289609","","177.52","0","18.33","159.19","0","0","1314682959","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("64","0","0","1","57","1320881609","","177.52","0","15.41","162.11","0","0","1314682959","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("65","0","0","2","57","1323560009","","177.52","0","12.44","165.08","0","0","1314682959","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("66","0","0","3","57","1326152009","","177.52","0","9.42","168.1","0","0","1314682959","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("67","0","0","4","57","1328830409","","177.52","0","6.33","171.19","0","0","1314682959","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("68","0","0","5","57","1331373050","","177.52","0","3.2","174.32","0","0","1314682959","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("69","0","0","0","58","1317361381","","283.88","0","15.72","268.16","0","0","1314682981","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("70","0","0","1","58","1319953381","","283.88","0","10.58","273.3","0","0","1314682981","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("71","0","0","2","58","1322631781","","283.88","0","5.34","278.54","0","0","1314682981","58.46.184.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("72","0","1","0","59","1317431725","1314826284","506.25","506.25","6.25","500","0","0","1314685711","113.65.154.14");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("73","0","1","0","60","1317527765","1314872500","505","505","5","500","0","0","1314717349","113.65.174.11");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("74","0","1","0","61","1317527766","1314872501","505","505","5","500","0","0","1314717828","113.65.154.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("75","0","1","0","62","1317527766","1314872501","505","505","5","500","0","0","1314718630","113.65.152.6");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("76","0","1","0","63","1317381458","1314798828","5075","5075","75","5000","0","0","1314720224","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("77","0","0","0","64","1318202877","","355.05","0","36.67","318.38","0","0","1314720332","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("78","0","0","1","64","1320881609","","355.05","0","30.83","324.22","0","0","1314720332","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("79","0","0","2","64","1323473277","","355.05","0","24.89","330.16","0","0","1314720332","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("80","0","0","3","64","1326152009","","355.05","0","18.83","336.22","0","0","1314720332","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("81","0","0","4","64","1328830409","","355.05","0","12.67","342.38","0","0","1314720332","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("82","0","0","5","64","1331335677","","355.05","0","6.39","348.66","0","0","1314720332","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("83","0","0","0","65","1317312000","","408.51","0","22.62","385.89","0","0","1314720377","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("84","0","0","1","65","1319990777","","408.51","0","15.22","393.29","0","0","1314720377","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("85","0","0","2","65","1322582400","","408.51","0","7.68","400.83","0","0","1314720377","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("86","0","1","0","66","1317380881","1314798828","5075","5075","75","5000","0","0","1314720801","113.219.166.91");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("87","0","1","0","67","1317439134","1314872502","505","505","5","500","0","0","1314722232","113.65.154.201");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("88","0","1","0","68","1317438410","1314872502","505","505","5","500","0","0","1314722957","113.65.153.161");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("89","0","1","0","69","1317437947","1314872502","391.88","391.88","3.88","388","0","0","1314723420","113.65.154.174");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("90","0","1","0","70","1317348428","1314798828","5075","5075","75","5000","0","0","1314753254","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("91","0","1","0","71","1317347137","1314798828","5075","5075","75","5000","0","0","1314754545","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("92","0","0","0","72","1318165985","","142.02","0","14.67","127.35","0","0","1314757224","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("93","0","0","1","72","1320881609","","142.02","0","12.33","129.69","0","0","1314757224","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("94","0","0","2","72","1323436385","","142.02","0","9.95","132.07","0","0","1314757224","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("95","0","0","3","72","1326152009","","142.02","0","7.53","134.49","0","0","1314757224","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("96","0","0","4","72","1328830409","","142.02","0","5.07","136.95","0","0","1314757224","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("97","0","0","5","72","1331298785","","142.02","0","2.56","139.46","0","0","1314757224","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("98","0","1","0","73","1317342782","1314928141","640.81","640.81","11.54","629.27","0","0","1314758800","113.65.187.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("99","0","1","0","74","1317342653","1314928142","377.53","377.53","6.8","370.73","0","0","1314758929","113.65.186.215");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("100","0","1","0","75","1317994055","1315611657","505","505","5","500","0","0","1314759796","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("101","0","1","0","76","1317341138","1314798828","3045","3045","45","3000","0","0","1314760544","58.46.178.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("102","0","1","0","77","1317340584","1314798828","5075","5075","75","5000","0","0","1314761098","180.110.4.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("103","0","1","0","78","1317340261","1314798828","1380.62","1380.62","20.4","1360.22","0","0","1314761421","113.65.186.215");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("104","0","1","0","79","1317339935","1314798829","5075","5075","75","5000","0","0","1314761747","180.110.4.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("105","0","1","0","80","1317337668","1314798829","1944.85","1944.85","28.74","1916.11","0","0","1314764015","113.65.172.7");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("106","0","1","0","81","1317337617","1314798829","734.53","734.53","10.86","723.67","0","0","1314764066","113.65.185.211");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("107","0","1","0","82","1317989759","1315611657","393.96","393.96","3.9","390.06","0","0","1314764093","113.65.185.211");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("108","0","1","0","83","1317989159","1315611657","505","505","5","500","0","0","1314764693","113.66.243.41");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("109","0","1","0","84","1317989043","1315611658","505","505","5","500","0","0","1314764810","113.65.186.224");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("110","0","1","0","85","1317988990","1315611658","505","505","5","500","0","0","1314764863","113.65.187.184");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("111","0","1","0","86","1317988912","1315611659","505","505","5","500","0","0","1314764941","113.65.185.61");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("112","0","1","0","87","1317986748","1315611659","505","505","5","500","0","0","1314767105","222.94.41.7");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("113","0","1","0","88","1317971543","1315611659","505","505","5","500","0","0","1314782310","180.110.4.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("114","0","1","0","89","1317970806","1315611659","505","505","5","500","0","0","1314783047","180.110.4.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("115","0","1","0","90","1317952624","1315611659","111.04","111.04","1.1","109.94","0","0","1314801230","113.65.172.148");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("116","0","1","0","91","1317952427","1315611659","505","505","5","500","0","0","1314801427","113.65.153.33");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("117","0","0","0","92","1317433482","","2026.67","0","26.67","2000","0","0","1314841482","180.110.4.119");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("118","0","1","0","93","1318203154","1315614386","503.7","503.7","3.7","500","0","0","1314868128","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("119","0","0","0","94","1317460169","","2031.47","0","31.47","2000","0","0","1314868169","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("120","0","1","0","95","1318033818","1315612283","505","505","5","500","0","0","1314868189","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("121","0","0","0","96","1317460215","","532.57","0","55","477.57","0","0","1314868215","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("122","0","0","1","96","1320138615","","532.57","0","46.24","486.33","0","0","1314868215","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("123","0","0","2","96","1322730615","","532.57","0","37.33","495.24","0","0","1314868215","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("124","0","0","3","96","1325409015","","532.57","0","28.25","504.32","0","0","1314868215","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("125","0","0","4","96","1328087415","","532.57","0","19","513.57","0","0","1314868215","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("126","0","0","5","96","1330593015","","532.57","0","9.59","522.98","0","0","1314868215","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("127","0","0","0","97","1317464031","","2031.47","0","31.47","2000","0","0","1314872031","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("128","0","0","0","98","1317464131","","355.05","0","36.67","318.38","0","0","1314872131","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("129","0","0","1","98","1320142531","","355.05","0","30.83","324.22","0","0","1314872131","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("130","0","0","2","98","1322734531","","355.05","0","24.89","330.16","0","0","1314872131","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("131","0","0","3","98","1325412931","","355.05","0","18.83","336.22","0","0","1314872131","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("132","0","0","4","98","1328091331","","355.05","0","12.67","342.38","0","0","1314872131","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("133","0","0","5","98","1330596931","","355.05","0","6.39","348.66","0","0","1314872131","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("134","0","1","0","99","1318203154","1315614386","503.7","503.7","3.7","500","0","0","1314872177","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("135","0","1","0","100","1318033818","1315612283","505","505","5","500","0","0","1314872238","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("136","0","0","0","101","1318203209","","205.93","0","21.27","184.66","0","0","1314872454","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("137","0","0","1","101","1320881609","","205.93","0","17.88","188.05","0","0","1314872454","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("138","0","0","2","101","1323473609","","205.93","0","14.43","191.5","0","0","1314872454","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("139","0","0","3","101","1326152009","","205.93","0","10.92","195.01","0","0","1314872454","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("140","0","0","4","101","1328830409","","205.93","0","7.35","198.58","0","0","1314872454","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("141","0","0","5","101","1331336009","","205.93","0","3.71","202.22","0","0","1314872454","113.219.247.72");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("142","0","1","0","102","1318033819","1315612283","505","505","5","500","0","0","1314872632","113.65.154.93");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("143","0","1","0","103","1318033819","1315612283","505","505","5","500","0","0","1314872947","113.65.152.154");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("144","0","1","0","104","1318033819","1315612284","505","505","5","500","0","0","1314872980","113.65.153.207");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("145","0","1","0","105","1318033820","1315612284","505","505","5","500","0","0","1314873018","113.65.175.180");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("146","0","1","0","106","1318033820","1315612284","505","505","5","500","0","0","1314873063","113.65.185.5");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("147","0","1","0","107","1318033820","1315612285","505","505","5","500","0","0","1314873093","113.65.185.5");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("148","0","1","0","108","1318033821","1315612285","395.4","395.4","3.91","391.49","0","0","1314873211","113.65.153.214");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("149","0","1","0","109","1318033821","1315612285","505","505","5","500","0","0","1314873247","113.65.185.19");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("150","0","1","0","110","1318203154","1315614386","503.7","503.7","3.7","500","0","0","1314873770","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("151","0","1","0","111","1318033821","1315612286","109.6","109.6","1.09","108.51","0","0","1314873800","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("152","0","0","0","112","1317465840","","2031.47","0","31.47","2000","0","0","1314873840","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("153","0","1","0","113","1318033757","1315442653","5059.08","5059.08","50.09","5008.99","0","0","1314873875","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("154","0","1","0","114","1318033757","1315442653","3917.8","3917.8","38.79","3879.01","0","0","1314873911","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("155","0","0","0","115","1317465939","","2031.47","0","31.47","2000","0","0","1314873939","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("156","0","1","0","116","1318203154","1315614386","503.7","503.7","3.7","500","0","0","1314873962","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("157","0","1","0","117","1318206183","1315651533","503.7","503.7","3.7","500","0","0","1314873987","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("158","0","1","0","118","1318206183","1315651533","503.7","503.7","3.7","500","0","0","1314874274","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("159","0","1","0","119","1318203154","1315614386","503.7","503.7","3.7","500","0","0","1314874298","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("160","0","0","0","120","1317466318","","2031.47","0","31.47","2000","0","0","1314874318","112.2.85.17");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("161","0","1","0","121","1318203155","1315614386","503.7","503.7","3.7","500","0","0","1314898778","113.65.155.196");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("162","0","1","0","122","1318206184","1315651533","503.7","503.7","3.7","500","0","0","1314898850","113.65.155.196");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("163","0","1","0","123","1318203156","1315614387","131.71","131.71","0.97","130.74","0","0","1314898908","113.65.155.244");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("164","0","1","0","124","1318203156","1315614387","503.7","503.7","3.7","500","0","0","1314898953","113.65.152.15");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("165","0","1","0","125","1318203157","1315614387","503.7","503.7","3.7","500","0","0","1314899045","113.65.152.37");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("166","0","1","0","126","1318203157","1315614388","109.71","109.71","0.81","108.9","0","0","1314899092","113.65.152.69");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("167","0","0","0","127","1317522060","","2031.47","0","31.47","2000","0","0","1314930060","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("168","0","1","0","128","1318033770","1315616967","503.33","503.33","3.33","500","0","0","1314930239","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("169","0","1","0","129","1318206184","1315651535","503.7","503.7","3.7","500","0","0","1314930275","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("170","0","0","0","130","1317522457","","2031.47","0","31.47","2000","0","0","1314930457","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("171","0","0","0","131","1317522484","","532.57","0","55","477.57","0","0","1314930484","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("172","0","0","1","131","1320200884","","532.57","0","46.24","486.33","0","0","1314930484","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("173","0","0","2","131","1322792884","","532.57","0","37.33","495.24","0","0","1314930484","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("174","0","0","3","131","1325471284","","532.57","0","28.25","504.32","0","0","1314930484","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("175","0","0","4","131","1328149684","","532.57","0","19","513.57","0","0","1314930484","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("176","0","0","5","131","1330655284","","532.57","0","9.59","522.98","0","0","1314930484","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("177","0","0","0","132","1317522632","","2031.47","0","31.47","2000","0","0","1314930632","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("178","0","0","0","133","1317522675","","2031.47","0","31.47","2000","0","0","1314930675","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("179","0","0","0","134","1318203209","","894.72","0","92.4","802.32","0","0","1314930739","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("180","0","0","1","134","1320881609","","894.72","0","77.69","817.03","0","0","1314930739","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("181","0","0","2","134","1323473609","","894.72","0","62.71","832.01","0","0","1314930739","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("182","0","0","3","134","1326152009","","894.72","0","47.46","847.26","0","0","1314930739","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("183","0","0","4","134","1328830409","","894.72","0","31.93","862.79","0","0","1314930739","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("184","0","0","5","134","1331336009","","894.72","0","16.11","878.61","0","0","1314930739","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("185","0","1","0","135","1318206184","1315651535","503.7","503.7","3.7","500","0","0","1314930783","113.219.121.221");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("186","0","1","0","136","1318206184","1315651535","307.96","307.96","2.26","305.7","0","0","1314934170","180.110.133.168");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("187","0","0","0","137","1317547229","","2031.47","0","31.47","2000","0","0","1314955229","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("188","0","0","0","138","1317547416","","2031.47","0","31.47","2000","0","0","1314955416","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("189","0","0","0","139","1317547445","","518.44","0","27.5","490.94","0","0","1314955445","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("190","0","0","1","139","1320225845","","518.44","0","18.5","499.94","0","0","1314955445","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("191","0","0","2","139","1322817845","","518.44","0","9.33","509.11","0","0","1314955445","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("192","0","1","0","140","1318203157","1315614388","100.74","100.74","0.74","100","0","0","1314955499","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("193","0","0","0","141","1317547528","","266.28","0","27.5","238.78","0","0","1314955528","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("194","0","0","1","141","1320225928","","266.28","0","23.12","243.16","0","0","1314955528","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("195","0","0","2","141","1322817928","","266.28","0","18.66","247.62","0","0","1314955528","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("196","0","0","3","141","1325496328","","266.28","0","14.12","252.16","0","0","1314955528","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("197","0","0","4","141","1328174728","","266.28","0","9.5","256.78","0","0","1314955528","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("198","0","0","5","141","1330680328","","266.28","0","4.79","261.49","0","0","1314955528","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("199","0","0","0","142","1317547583","","2031.47","0","31.47","2000","0","0","1314955583","113.219.155.27");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("200","0","1","0","143","1318203158","1315614388","503.7","503.7","3.7","500","0","0","1315391742","113.65.185.0");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("201","0","1","0","144","1318206184","1315651535","160.84","160.84","1.18","159.66","0","0","1315391766","113.65.185.0");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("202","0","1","0","145","1318206184","1315651535","503.7","503.7","3.7","500","0","0","1315391911","113.65.185.0");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("203","0","0","0","146","1318034921","","5770.38","0","89.38","5681","0","0","1315442921","113.218.152.110");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("204","0","1","0","147","1318206184","1315651535","503.7","503.7","3.7","500","0","0","1315443026","113.218.152.110");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("205","0","1","0","148","1318221496","1315657360","19285.28","19285.28","397.28","18888","0","0","1315487115","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("206","0","0","0","149","1318079162","","494.23","0","35.24","458.99","0","0","1315487162","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("207","0","0","1","149","1320757562","","494.23","0","26.67","467.56","0","0","1315487162","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("208","0","0","2","149","1323349562","","494.23","0","17.95","476.28","0","0","1315487162","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("209","0","0","3","149","1326027962","","494.23","0","9.06","485.17","0","0","1315487162","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("210","0","0","0","150","1318079222","","652.55","0","34.61","617.94","0","0","1315487222","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("211","0","0","1","150","1320757622","","652.55","0","23.28","629.27","0","0","1315487222","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("212","0","0","2","150","1323349622","","652.55","0","11.75","640.8","0","0","1315487222","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("213","0","0","0","151","1318079304","","652.55","0","34.61","617.94","0","0","1315487304","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("214","0","0","1","151","1320757704","","652.55","0","23.28","629.27","0","0","1315487304","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("215","0","0","2","151","1323349704","","652.55","0","11.75","640.8","0","0","1315487304","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("216","0","0","0","152","1318079339","","335.16","0","34.61","300.55","0","0","1315487339","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("217","0","0","1","152","1320757739","","335.16","0","29.1","306.06","0","0","1315487339","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("218","0","0","2","152","1323349739","","335.16","0","23.49","311.67","0","0","1315487339","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("219","0","0","3","152","1326028139","","335.16","0","17.78","317.38","0","0","1315487339","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("220","0","0","4","152","1328706539","","335.16","0","11.96","323.2","0","0","1315487339","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("221","0","0","5","152","1331212139","","335.16","0","6.03","329.13","0","0","1315487339","113.218.53.251");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("222","0","1","0","153","1318221496","1315657360","9755.02","9755.02","200.95","9554.07","0","0","1315487676","183.209.141.81");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("223","0","1","0","154","1318221496","1315657360","9224.94","9224.94","190.03","9034.91","0","0","1315487735","183.209.141.81");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("224","0","1","0","155","1318221496","1315657360","9621.4","9621.4","198.2","9423.2","0","0","1315487776","183.209.141.81");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("225","0","1","0","156","1318221496","1315657360","4490.5","4490.5","92.5","4398","0","0","1315566865","113.218.177.229");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("226","0","1","0","157","1318203158","1315614389","48.72","48.72","0.36","48.36","0","0","1315566951","113.218.177.229");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("227","0","1","0","158","1318221496","1315657360","7147.23","7147.23","147.23","7000","0","0","1315566974","113.218.177.229");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("228","0","0","0","159","1318158999","","218.44","0","11.59","206.85","0","0","1315566999","113.218.177.229");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("229","0","0","1","159","1320837399","","218.44","0","7.79","210.65","0","0","1315566999","113.218.177.229");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("230","0","0","2","159","1323429399","","218.44","0","3.93","214.51","0","0","1315566999","113.218.177.229");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("231","0","1","0","160","1318206184","1315651535","503.7","503.7","3.7","500","0","0","1315610979","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("232","0","1","0","161","1318221496","1315657360","6649.99","6649.99","136.99","6513","0","0","1315611009","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("233","0","0","0","162","1318203381","","1173.78","0","121.22","1052.56","0","0","1315611381","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("234","0","0","1","162","1320881781","","1173.78","0","101.92","1071.86","0","0","1315611381","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("235","0","0","2","162","1323473781","","1173.78","0","82.27","1091.51","0","0","1315611381","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("236","0","0","3","162","1326152181","","1173.78","0","62.26","1111.52","0","0","1315611381","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("237","0","0","4","162","1328830581","","1173.78","0","41.88","1131.9","0","0","1315611381","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("238","0","0","5","162","1331336181","","1173.78","0","21.13","1152.65","0","0","1315611381","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("239","0","1","0","163","1318221496","1315657360","6924.65","6924.65","142.65","6782","0","0","1315611403","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("240","0","1","0","164","1318206184","1315651535","503.7","503.7","3.7","500","0","0","1315612845","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("241","0","1","0","165","1318221496","1315657360","5133.76","5133.76","105.76","5028","0","0","1315612864","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("242","0","1","0","166","1318206184","1315651535","34.9","34.9","0.26","34.64","0","0","1315612954","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("243","0","0","0","167","1318204975","","138.74","0","9.89","128.85","0","0","1315612975","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("244","0","0","1","167","1320883375","","138.74","0","7.49","131.25","0","0","1315612975","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("245","0","0","2","167","1323475375","","138.74","0","5.04","133.7","0","0","1315612975","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("246","0","0","3","167","1326153775","","138.74","0","2.54","136.2","0","0","1315612975","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("247","0","0","0","168","1318204999","","103.69","0","5.5","98.19","0","0","1315612999","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("248","0","0","1","168","1320883399","","103.69","0","3.7","99.99","0","0","1315612999","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("249","0","0","2","168","1323475399","","103.69","0","1.87","101.82","0","0","1315612999","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("250","0","1","0","169","1318221496","1315657360","2161.53","2161.53","44.53","2117","0","0","1315613349","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("251","0","0","0","170","1318205545","","1714.55","0","188","1526.55","0","0","1315613545","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("252","0","0","1","170","1320883945","","1714.55","0","152.13","1562.42","0","0","1315613545","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("253","0","0","2","170","1323475945","","1714.55","0","115.41","1599.14","0","0","1315613545","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("254","0","0","3","170","1326154345","","1714.55","0","77.83","1636.72","0","0","1315613545","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("255","0","0","4","170","1328832745","","1714.55","0","39.37","1675.18","0","0","1315613545","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("256","0","0","0","171","1318243473","","30525","0","525","30000","0","0","1315613598","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("257","0","1","0","172","1318219021","1315627325","1020.07","1020.07","30","990.07","0","0","1315620827","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("258","0","1","1","172","1320897421","1315627345","1020.07","1020.07","20.1","999.97","0","0","1315620827","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("259","0","1","2","172","1323489421","1315703618","1020.07","1020.07","10.1","1009.97","0","0","1315620827","113.218.120.128");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("260","0","1","0","173","1318221497","1315657360","917.24","917.24","18.9","898.34","0","0","1315621481","113.65.186.11");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("261","0","1","0","174","1318221497","1315657361","2062.72","2062.72","42.49","2020.23","0","0","1315621533","113.65.186.11");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("262","0","1","0","175","1318221498","1315657361","1187.06","1187.06","24.45","1162.61","0","0","1315621576","113.65.186.11");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("263","0","1","0","176","1318221498","1315657362","1868.45","1868.45","38.49","1829.96","0","0","1315621606","113.65.186.11");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("264","0","1","0","177","1318221499","1315657362","1063.37","1063.37","21.91","1041.46","0","0","1315621632","113.65.186.11");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("265","0","1","0","178","1318221499","1315657363","1164.62","1164.62","23.99","1140.63","0","0","1315621660","113.65.186.179");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("266","0","1","0","179","1318221499","1315657363","1059.32","1059.32","21.82","1037.5","0","0","1315621683","113.65.186.179");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("267","0","1","0","180","1318221500","1315657364","1040.52","1040.52","21.43","1019.09","0","0","1315621761","113.65.186.179");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("268","0","0","0","181","1318221338","","193.01","0","46.67","146.34","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("269","0","0","1","181","1320899738","","193.01","0","43.25","149.76","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("270","0","0","2","181","1323491738","","193.01","0","39.76","153.25","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("271","0","0","3","181","1326170138","","193.01","0","36.18","156.83","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("272","0","0","4","181","1328848538","","193.01","0","32.52","160.49","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("273","0","0","5","181","1331354138","","193.01","0","28.78","164.23","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("274","0","0","6","181","1334032538","","193.01","0","24.95","168.06","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("275","0","0","7","181","1336624538","","193.01","0","21.02","171.99","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("276","0","0","8","181","1339302938","","193.01","0","17.01","176","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("277","0","0","9","181","1341894938","","193.01","0","12.9","180.11","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("278","0","0","10","181","1344573338","","193.01","0","8.7","184.31","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("279","0","0","11","181","1347251738","","193.01","0","4.4","188.61","0","0","1315629338","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("280","0","0","0","182","1318221358","","518.89","0","30","488.89","0","0","1315629358","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("281","0","0","1","182","1320899758","","518.89","0","22.67","496.22","0","0","1315629358","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("282","0","0","2","182","1323491758","","518.89","0","15.22","503.67","0","0","1315629358","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("283","0","0","3","182","1326170158","","518.89","0","7.67","511.22","0","0","1315629358","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("284","0","0","0","183","1318243473","","35837.37","0","616.37","35221","0","0","1315629384","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("285","0","0","0","184","1318221646","","1025.12","0","40","985.12","0","0","1315629646","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("286","0","0","1","184","1320900046","","1025.12","0","30.15","994.97","0","0","1315629646","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("287","0","0","2","184","1323492046","","1025.12","0","20.2","1004.92","0","0","1315629646","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("288","0","0","3","184","1326170446","","1025.12","0","10.15","1014.97","0","0","1315629646","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("289","0","0","0","185","1318221678","","123.03","0","8.77","114.26","0","0","1315629678","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("290","0","0","1","185","1320900078","","123.03","0","6.64","116.39","0","0","1315629678","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("291","0","0","2","185","1323492078","","123.03","0","4.47","118.56","0","0","1315629678","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("292","0","0","3","185","1326170478","","123.03","0","2.25","120.78","0","0","1315629678","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("293","0","0","0","186","1318221734","","69.98","0","16.92","53.06","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("294","0","0","1","186","1320900134","","69.98","0","15.68","54.3","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("295","0","0","2","186","1323492134","","69.98","0","14.41","55.57","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("296","0","0","3","186","1326170534","","69.98","0","13.12","56.86","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("297","0","0","4","186","1328848934","","69.98","0","11.79","58.19","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("298","0","0","5","186","1331354534","","69.98","0","10.43","59.55","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("299","0","0","6","186","1334032934","","69.98","0","9.04","60.94","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("300","0","0","7","186","1336624934","","69.98","0","7.62","62.36","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("301","0","0","8","186","1339303334","","69.98","0","6.17","63.81","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("302","0","0","9","186","1341895334","","69.98","0","4.68","65.3","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("303","0","0","10","186","1344573734","","69.98","0","3.15","66.83","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("304","0","0","11","186","1347252134","","69.98","0","1.6","68.38","0","0","1315629734","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("305","0","0","0","187","1318243473","","25212.63","0","433.63","24779","0","0","1315630514","113.218.36.55");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("306","0","0","0","188","1318243735","","9001.37","0","987","8014.37","0","0","1315651735","113.218.125.86");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("307","0","0","1","188","1320922135","","9001.37","0","798.66","8202.71","0","0","1315651735","113.218.125.86");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("308","0","0","2","188","1323514135","","9001.37","0","605.9","8395.47","0","0","1315651735","113.218.125.86");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("309","0","0","3","188","1326192535","","9001.37","0","408.61","8592.76","0","0","1315651735","113.218.125.86");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("310","0","0","4","188","1328870935","","9001.37","0","206.68","8794.69","0","0","1315651735","113.218.125.86");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("311","0","0","0","189","1318249806","","1556.67","0","90","1466.67","0","0","1315657806","113.218.125.86");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("312","0","0","1","189","1320928206","","1556.67","0","68","1488.67","0","0","1315657806","113.218.125.86");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("313","0","0","2","189","1323520206","","1556.67","0","45.67","1511","0","0","1315657806","113.218.125.86");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("314","0","0","3","189","1326198606","","1556.67","0","23","1533.67","0","0","1315657806","113.218.125.86");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("315","0","0","0","190","1318294233","","30472","0","472","30000","0","0","1315702233","113.218.154.44");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("316","0","0","0","191","1318299388","","6086.27","0","94.27","5992","0","0","1315707388","113.218.74.188");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("317","0","0","0","192","1318302641","","22429.42","0","347.42","22082","0","0","1315710641","113.218.44.254");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("318","0","0","0","193","1318302905","","2190.94","0","33.94","2157","0","0","1315710905","113.218.44.254");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("319","0","0","0","194","1318306818","","56962.33","0","882.33","56080","0","0","1315714818","113.218.4.79");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("320","0","0","0","195","1318306948","","21094.69","0","326.75","20767.94","0","0","1315714948","113.218.4.79");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("321","0","0","0","196","1318307851","","41025.47","0","635.47","40390","0","0","1315715851","113.218.4.79");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("322","0","0","0","197","1318308699","","21373.06","0","331.06","21042","0","0","1315716699","113.218.4.79");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("323","0","0","0","198","1318308998","","10157.33","0","157.33","10000","0","0","1315716998","113.218.4.79");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("324","0","0","0","199","1318309945","","20314.67","0","314.67","20000","0","0","1315717945","113.218.4.79");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("325","0","0","0","200","1318318146","","37558.77","0","581.77","36977","0","0","1315726146","113.218.4.79");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("326","0","0","0","201","1318377182","","7229.99","0","111.99","7118","0","0","1315785182","113.218.95.63");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("327","0","0","0","202","1318377326","","15378.2","0","238.2","15140","0","0","1315785326","113.218.95.63");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("328","0","0","0","203","1318415358","","40629.33","0","629.33","40000","0","0","1315823358","113.218.198.239");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("329","0","0","0","204","1318415387","","472.82","0","25.08","447.74","0","0","1315823387","113.218.198.239");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("330","0","0","1","204","1321093787","","472.82","0","16.87","455.95","0","0","1315823387","113.218.198.239");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("331","0","0","2","204","1323685787","","472.82","0","8.51","464.31","0","0","1315823387","113.218.198.239");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("332","0","0","0","205","1318415428","","453.47","0","24.05","429.42","0","0","1315823428","113.218.198.239");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("333","0","0","1","205","1321093828","","453.47","0","16.18","437.29","0","0","1315823428","113.218.198.239");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("334","0","0","2","205","1323685828","","453.47","0","8.16","445.31","0","0","1315823428","113.218.198.239");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("335","0","0","0","206","1318415831","","50786.67","0","786.67","50000","0","0","1315823831","113.218.198.239");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("336","0","0","0","207","1318528171","","1093","0","16.93","1076.07","0","0","1315936171","113.65.153.19");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("337","0","0","0","208","1318528200","","2602.11","0","40.31","2561.8","0","0","1315936200","113.65.153.19");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("338","0","0","0","209","1318528252","","1203.26","0","18.64","1184.62","0","0","1315936252","113.65.153.19");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("339","0","0","0","210","1318528337","","2405.26","0","37.26","2368","0","0","1315936337","113.65.153.19");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("340","0","0","0","211","1318528420","","1073.63","0","16.63","1057","0","0","1315936420","113.65.153.19");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("341","0","0","0","212","1318528455","","1180.28","0","18.28","1162","0","0","1315936455","113.65.153.19");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("342","0","0","0","213","1318528505","","1077.69","0","16.69","1061","0","0","1315936505","113.65.153.19");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("343","0","0","0","214","1318528575","","1073.63","0","16.63","1057","0","0","1315936575","113.65.153.19");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("344","0","0","0","215","1321455598","","34.68","0","2","32.68","0","0","1318777198","117.93.29.70");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("345","0","0","1","215","1324047598","","34.68","0","1.35","33.33","0","0","1318777198","117.93.29.70");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("346","0","0","2","215","1326725998","","34.68","0","0.68","34","0","0","1318777198","117.93.29.70");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("347","0","0","0","216","1321455674","","102.81","0","3.73","99.08","0","0","1318777274","117.93.29.70");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("348","0","0","1","216","1324047674","","102.81","0","1.88","100.93","0","0","1318777274","117.93.29.70");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("349","0","0","0","217","1321493106","","890.72","0","96.83","793.89","0","0","1318814536","117.93.22.200");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("350","0","0","1","217","1324085106","","890.72","0","81.46","809.26","0","0","1318814536","117.93.22.200");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("351","0","0","2","217","1326763506","","890.72","0","65.79","824.93","0","0","1318814536","117.93.22.200");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("352","0","0","3","217","1329441906","","890.72","0","49.81","840.91","0","0","1318814536","117.93.22.200");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("353","0","0","4","217","1331947506","","890.72","0","33.52","857.2","0","0","1318814536","117.93.22.200");

insert into `dw_borrow_collection` ( `id`,`site_id`,`status`,`order`,`tender_id`,`repay_time`,`repay_yestime`,`repay_account`,`repay_yesaccount`,`interest`,`capital`,`late_days`,`late_interest`,`addtime`,`addip`) values ("354","0","0","5","217","1334625906","","890.72","0","16.92","873.8","0","0","1318814536","117.93.22.200");

