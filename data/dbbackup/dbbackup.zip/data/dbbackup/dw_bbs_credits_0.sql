insert into `dw_bbs_credits` ( `id`,`creditscode`,`creditsname`,`postvar`,`replyvar`,`goodvar`,`uploadvar`,`downvar`,`votevar`,`isuse`) values ("1","credits1","��Ǯ","5","1","10","1","0","1","1");

insert into `dw_bbs_credits` ( `id`,`creditscode`,`creditsname`,`postvar`,`replyvar`,`goodvar`,`uploadvar`,`downvar`,`votevar`,`isuse`) values ("2","credits2","����","3","1","10","112","21","1","1");

insert into `dw_bbs_credits` ( `id`,`creditscode`,`creditsname`,`postvar`,`replyvar`,`goodvar`,`uploadvar`,`downvar`,`votevar`,`isuse`) values ("3","credits3","����","223","23","1012","312","2","1","1");

insert into `dw_bbs_credits` ( `id`,`creditscode`,`creditsname`,`postvar`,`replyvar`,`goodvar`,`uploadvar`,`downvar`,`votevar`,`isuse`) values ("4","credits4","1231","0","0","0","0","0","0","0");

insert into `dw_bbs_credits` ( `id`,`creditscode`,`creditsname`,`postvar`,`replyvar`,`goodvar`,`uploadvar`,`downvar`,`votevar`,`isuse`) values ("5","credits5","","0","0","0","0","0","0","0");

insert into `dw_bbs_credits` ( `id`,`creditscode`,`creditsname`,`postvar`,`replyvar`,`goodvar`,`uploadvar`,`downvar`,`votevar`,`isuse`) values ("6","credits6","","0","0","0","0","0","0","0");

insert into `dw_bbs_credits` ( `id`,`creditscode`,`creditsname`,`postvar`,`replyvar`,`goodvar`,`uploadvar`,`downvar`,`votevar`,`isuse`) values ("7","credits7","","0","0","0","0","0","0","1");

insert into `dw_bbs_credits` ( `id`,`creditscode`,`creditsname`,`postvar`,`replyvar`,`goodvar`,`uploadvar`,`downvar`,`votevar`,`isuse`) values ("8","credits8","","0","0","0","0","0","0","0");

