insert into `dw_fields` ( `fields_id`,`code`,`name`,`nid`,`type`,`size`,`input`,`description`,`default`,`select`,`order`) values ("1","article","�ϴ��ļ�","files","varchar","","annex","","","","10");

